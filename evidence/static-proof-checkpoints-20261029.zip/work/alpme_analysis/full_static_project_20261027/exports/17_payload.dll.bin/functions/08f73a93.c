/* address=08f73a93 rva=0x3a93 */

void FUN_08f73a93(undefined8 *param_1)

{
  longlong *plVar1;
  
  CloseHandle((HANDLE)param_1[1]);
  plVar1 = (longlong *)param_1[2];
  LOCK();
  *plVar1 = *plVar1 + -1;
  UNLOCK();
  if (*plVar1 == 0) {
    FUN_08f91621(plVar1);
  }
  plVar1 = (longlong *)*param_1;
  LOCK();
  *plVar1 = *plVar1 + -1;
  UNLOCK();
  if (*plVar1 == 0) {
    FUN_08f8bd55(plVar1);
    return;
  }
  return;
}

