/* address=08f730e2 rva=0x30e2 */

void FUN_08f730e2(int *param_1)

{
  if ((*(longlong *)(param_1 + 0x138) != -1) && ((int)*(longlong *)(param_1 + 0x138) != 2)) {
    FUN_08f75ac0((char *)(param_1 + 0x138));
  }
  if (param_1[0x9c] != 2) {
    FUN_08f75ac0((char *)(param_1 + 0x9c));
  }
  if (*param_1 == 2) {
    return;
  }
  FUN_08f75ac0((char *)param_1);
  return;
}

