/* address=08f73135 rva=0x3135 */

longlong FUN_08f73135(byte *param_1,byte *param_2)

{
  longlong lVar1;
  byte local_90 [72];
  undefined8 local_48 [2];
  char local_38;
  
  FUN_08faad9c(local_90,param_1,param_2);
  FUN_08f91985(local_48,local_90);
  if ((byte)(local_38 - 7U) < 0xf8) {
    lVar1 = FUN_08fba322(local_90);
  }
  else {
    lVar1 = 0;
  }
  return lVar1;
}

