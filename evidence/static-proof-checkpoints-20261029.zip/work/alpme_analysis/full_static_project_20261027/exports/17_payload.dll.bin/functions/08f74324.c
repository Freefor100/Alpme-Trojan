/* address=08f74324 rva=0x4324 */

void FUN_08f74324(void)

{
  int *piVar1;
  bool bVar2;
  
  ANALYST_constant_init();
  LOCK();
  bVar2 = DAT_0900ce78 == '\0';
  if (bVar2) {
    DAT_0900ce78 = '\x01';
  }
  UNLOCK();
  piVar1 = &DAT_08ffb494;
  if (bVar2) {
    piVar1 = &DAT_08ffb4e4;
  }
                    /* WARNING: Could not recover jumptable at 0x08f743a9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(&LAB_08f749b5 + *piVar1))();
  return;
}

