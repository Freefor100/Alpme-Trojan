/* address=08f73182 rva=0x3182 */

void FUN_08f73182(void)

{
  GetLastError();
  if ((undefined **)PTR_PTR_0900af90 != &PTR_LAB_08ff19c8) {
    PTR_PTR_0900af90 = (undefined *)&PTR_LAB_08ff19c8;
  }
  return;
}

