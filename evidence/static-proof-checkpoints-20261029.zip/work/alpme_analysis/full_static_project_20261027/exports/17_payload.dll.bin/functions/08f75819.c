/* address=08f75819 rva=0x5819 */

void FUN_08f75819(undefined8 *param_1)

{
  LPVOID pvVar1;
  longlong lVar2;
  longlong *plVar3;
  
  pvVar1 = (LPVOID)*param_1;
  lVar2 = param_1[2];
  if (lVar2 != 0) {
    plVar3 = (longlong *)((longlong)pvVar1 + 8);
    do {
      FUN_08fba6b1((LPVOID)plVar3[-1],*plVar3,1,1);
      plVar3 = plVar3 + 5;
      lVar2 = lVar2 + -1;
    } while (lVar2 != 0);
  }
  FUN_08fba6b1(pvVar1,param_1[1],8,0x28);
  return;
}

