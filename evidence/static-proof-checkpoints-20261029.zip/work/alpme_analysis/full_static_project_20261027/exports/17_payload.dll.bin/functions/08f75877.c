/* address=08f75877 rva=0x5877 */

void FUN_08f75877(longlong *param_1)

{
  LPVOID pvVar1;
  uint *puVar2;
  longlong lVar3;
  undefined4 uVar4;
  LPVOID pvVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  undefined8 local_1d8;
  longlong lStack_1d0;
  undefined8 local_1c8;
  LPVOID local_1c0;
  longlong local_1b8;
  longlong local_1b0;
  char *local_1a8;
  undefined8 local_1a0;
  undefined8 uStack_198;
  undefined8 local_190;
  undefined8 local_188;
  undefined8 uStack_180;
  undefined8 local_178;
  undefined8 local_170;
  longlong lStack_168;
  undefined8 local_160;
  ulonglong local_158 [3];
  char local_140;
  longlong local_138;
  longlong lStack_130;
  longlong local_128;
  undefined8 local_120;
  undefined8 uStack_118;
  undefined8 local_110;
  undefined8 local_108;
  longlong local_100;
  undefined8 local_f8;
  undefined8 local_f0;
  undefined8 uStack_e8;
  undefined8 local_e0;
  longlong local_d8;
  char *local_d0;
  undefined8 local_90;
  undefined8 local_88;
  longlong local_60;
  longlong lStack_58;
  longlong local_50;
  longlong lStack_48;
  
  local_60 = param_1[0xf];
  lStack_58 = param_1[0x10];
  local_50 = param_1[0x11];
  lStack_48 = param_1[0x12];
  plVar7 = param_1;
  plVar8 = &local_d8;
  for (lVar6 = 0xf; lVar6 != 0; lVar6 = lVar6 + -1) {
    *plVar8 = *plVar7;
    plVar7 = plVar7 + 1;
    plVar8 = plVar8 + 1;
  }
  FUN_08f76c21(&local_60);
  pvVar1 = (LPVOID)param_1[5];
  lVar6 = param_1[6];
  puVar2 = (uint *)param_1[7];
  local_1c0 = (LPVOID)param_1[0xc];
  lVar3 = param_1[0xd];
  local_1b8 = local_d8;
  local_1b0 = local_d8;
  local_1a8 = local_d0;
  pvVar5 = (LPVOID)0x0;
  if (lVar3 != -1) {
    pvVar5 = local_1c0;
  }
  uVar4 = SUB84(pvVar5,0);
  ANALYST_browser_helper(&local_1a0,local_90,local_88);
  if (lStack_168 == -1) {
    if (lVar6 == -1) {
      lStack_1d0 = -1;
      goto LAB_08f759a8;
    }
    FUN_08fd3f30(&local_1d8,pvVar1,puVar2,(ulonglong **)0x0,uVar4,0);
  }
  else {
    local_1c8 = local_160;
    local_1d8 = local_170;
    lStack_1d0 = lStack_168;
    if (lVar6 == -1) goto LAB_08f759a8;
  }
  FUN_08fba6b1(pvVar1,lVar6,1,1);
LAB_08f759a8:
  local_e0 = local_190;
  local_f0 = local_1a0;
  uStack_e8 = uStack_198;
  local_120 = local_188;
  uStack_118 = uStack_180;
  local_110 = local_178;
  local_108 = local_1d8;
  local_100 = lStack_1d0;
  local_f8 = local_1c8;
  local_138 = param_1[2];
  lStack_130 = param_1[3];
  local_128 = param_1[4];
  FUN_08fc0d72();
  if (local_140 != '\x02') {
    FUN_08f71005(local_158);
  }
  FUN_08fbcf92(&local_138);
  FUN_08f8dc19(local_1b8,local_d0);
  if (lVar3 != -1) {
    FUN_08fba6b1(local_1c0,lVar3,2,2);
  }
  plVar7 = (longlong *)param_1[0x13];
  if ((char)plVar7[3] != '\0') {
    FUN_08fc683e((LPVOID)plVar7[4],(undefined8 *)plVar7[5]);
  }
  plVar7[3] = 1;
  plVar7[4] = 0;
  LOCK();
  *plVar7 = *plVar7 + -1;
  UNLOCK();
  if (*plVar7 == 0) {
    FUN_08f8bd55(plVar7);
    return;
  }
  return;
}

