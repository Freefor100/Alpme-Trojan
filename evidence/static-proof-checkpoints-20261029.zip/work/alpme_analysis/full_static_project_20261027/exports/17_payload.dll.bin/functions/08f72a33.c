/* address=08f72a33 rva=0x2a33 */

longlong FUN_08f72a33(byte *param_1)

{
  ushort *puVar1;
  code *pcVar2;
  longlong lVar3;
  longlong lVar4;
  ulonglong uVar5;
  longlong lVar6;
  longlong lVar7;
  
  if (*(longlong *)(param_1 + 0x40) == 0) {
    return 0;
  }
  *(longlong *)(param_1 + 0x40) = *(longlong *)(param_1 + 0x40) + -1;
  lVar3 = *(longlong *)(param_1 + 0x18);
  if ((*param_1 & lVar3 == 0) == 0) {
    if (*param_1 == 0) {
LAB_08f72ab0:
                    /* WARNING: Does not return */
      pcVar2 = (code *)invalidInstructionException();
      (*pcVar2)();
    }
    uVar5 = *(ulonglong *)(param_1 + 8);
    lVar6 = *(longlong *)(param_1 + 0x10);
  }
  else {
    lVar3 = *(longlong *)(param_1 + 0x10);
    for (lVar6 = *(longlong *)(param_1 + 8); lVar6 != 0; lVar6 = lVar6 + -1) {
      lVar3 = *(longlong *)(lVar3 + 0x228);
    }
    param_1[0] = 1;
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
    param_1[6] = 0;
    param_1[7] = 0;
    lVar6 = 0;
    uVar5 = 0;
  }
  lVar4 = lVar3;
  if (*(ushort *)(lVar3 + 0x220) <= uVar5) {
    do {
      lVar3 = *(longlong *)(lVar4 + 0x218);
      if (lVar3 == 0) goto LAB_08f72ab0;
      lVar6 = lVar6 + 1;
      puVar1 = (ushort *)(lVar4 + 0x210);
      uVar5 = (ulonglong)*puVar1;
      lVar4 = lVar3;
    } while (*(ushort *)(lVar3 + 0x220) <= *puVar1);
  }
  if (lVar6 == 0) {
    lVar4 = uVar5 + 1;
    lVar7 = lVar3;
  }
  else {
    lVar7 = *(longlong *)(lVar3 + 0x230 + uVar5 * 8);
    lVar4 = 0;
    while( true ) {
      lVar6 = lVar6 + -1;
      if (lVar6 == 0) break;
      lVar7 = *(longlong *)(lVar7 + 0x228);
    }
  }
  *(longlong *)(param_1 + 8) = lVar4;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  *(longlong *)(param_1 + 0x18) = lVar7;
  return lVar3 + uVar5 * 0x18;
}

