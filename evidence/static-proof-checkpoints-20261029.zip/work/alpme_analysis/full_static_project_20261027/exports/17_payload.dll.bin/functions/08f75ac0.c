/* address=08f75ac0 rva=0x5ac0 */

void FUN_08f75ac0(char *param_1)

{
  longlong *plVar1;
  
  if (*param_1 != '\0') {
    FindClose(*(HANDLE *)(param_1 + 8));
  }
  plVar1 = *(longlong **)(param_1 + 0x268);
  LOCK();
  *plVar1 = *plVar1 + -1;
  UNLOCK();
  if (*plVar1 == 0) {
    FUN_08f73b02(plVar1);
    return;
  }
  return;
}

