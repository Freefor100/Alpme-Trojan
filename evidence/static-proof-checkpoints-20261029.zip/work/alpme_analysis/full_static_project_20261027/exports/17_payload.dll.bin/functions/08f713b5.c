/* address=08f713b5 rva=0x13b5 */

longlong FUN_08f713b5(uint param_1,longlong param_2)

{
  bool bVar1;
  longlong lVar2;
  uint uVar3;
  uint uVar4;
  
  lVar2 = 10;
  uVar3 = param_1;
  if (999 < param_1) {
    uVar4 = param_1;
    do {
      uVar3 = uVar4 / 10000;
      *(undefined2 *)(param_2 + -4 + lVar2) =
           *(undefined2 *)(&DAT_08ff6b4c + (ulonglong)((uVar4 % 10000) / 100) * 2);
      *(undefined2 *)(param_2 + -2 + lVar2) =
           *(undefined2 *)(&DAT_08ff6b4c + (ulonglong)((uVar4 % 10000) % 100) * 2);
      lVar2 = lVar2 + -4;
      bVar1 = 9999999 < uVar4;
      uVar4 = uVar4 / 10000;
    } while (bVar1);
  }
  uVar4 = uVar3;
  if (9 < uVar3) {
    uVar4 = (uVar3 & 0xffff) / 100;
    *(undefined2 *)(param_2 + -2 + lVar2) =
         *(undefined2 *)(&DAT_08ff6b4c + (ulonglong)(uVar3 + uVar4 * -100 & 0xffff) * 2);
    lVar2 = lVar2 + -2;
  }
  if ((param_1 == 0) || (uVar4 != 0)) {
    *(undefined *)(param_2 + -1 + lVar2) = (&DAT_08ff6b4d)[(ulonglong)(uVar4 & 0xf) * 2];
    lVar2 = lVar2 + -1;
  }
  return lVar2;
}

