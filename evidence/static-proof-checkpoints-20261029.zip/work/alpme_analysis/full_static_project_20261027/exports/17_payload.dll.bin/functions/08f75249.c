/* address=08f75249 rva=0x5249 */

void FUN_08f75249(longlong *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  ushort uVar2;
  ushort uVar3;
  void *_Buf1;
  ulonglong uVar4;
  longlong lVar5;
  code *pcVar6;
  int iVar7;
  undefined8 *puVar8;
  longlong lVar9;
  undefined8 *puVar10;
  LPVOID pvVar11;
  short sVar12;
  undefined8 *puVar13;
  undefined8 uVar14;
  longlong lVar15;
  ulonglong _Size;
  ulonglong uVar16;
  undefined8 uVar17;
  ulonglong uVar18;
  undefined8 uVar19;
  ulonglong uVar20;
  undefined8 *puVar21;
  longlong lVar22;
  bool bVar23;
  undefined8 local_80;
  longlong local_70;
  undefined8 local_58;
  longlong local_50;
  undefined8 local_48;
  
  puVar10 = (undefined8 *)param_1[2];
  if (puVar10 != (undefined8 *)0x0) {
    lVar22 = param_1[1];
    _Buf1 = (void *)*param_2;
    uVar16 = param_2[2];
    do {
      uVar18 = (ulonglong)*(ushort *)(puVar10 + 0x23);
      uVar20 = 0xffffffffffffffff;
      lVar15 = (ulonglong)((uint)*(ushort *)(puVar10 + 0x23) * 8) * 3;
      puVar8 = puVar10;
      do {
        if (lVar15 == 0) goto LAB_08f75623;
        uVar4 = puVar8[2];
        _Size = uVar4;
        if (uVar16 < uVar4) {
          _Size = uVar16;
        }
        iVar7 = memcmp(_Buf1,(void *)*puVar8,_Size);
        lVar9 = uVar16 - uVar4;
        if (iVar7 != 0) {
          lVar9 = (longlong)iVar7;
        }
        uVar20 = uVar20 + 1;
        lVar15 = lVar15 + -0x18;
        puVar8 = puVar8 + 3;
      } while ((char)((0 < lVar9) - (lVar9 < 0)) == '\x01');
      uVar18 = uVar20;
      if (0 < lVar9 == lVar9 < 0) {
        FUN_08fba6b1(_Buf1,param_2[1],1,1);
        return;
      }
LAB_08f75623:
      bVar23 = lVar22 == 0;
      lVar22 = lVar22 + -1;
      if (bVar23) goto LAB_08f7563b;
      puVar10 = (undefined8 *)puVar10[uVar18 + 0x24];
    } while( true );
  }
  lVar22 = param_2[1];
  if (lVar22 == -1) {
    return;
  }
  uVar14 = *param_2;
  uVar19 = param_2[2];
LAB_08f756d4:
  puVar10 = FUN_08fc693d(0,0x120);
  if (puVar10 == (undefined8 *)0x0) {
LAB_08f75727:
                    /* WARNING: Does not return */
    pcVar6 = (code *)invalidInstructionException();
    (*pcVar6)();
  }
  puVar10[0x22] = 0;
  *(undefined2 *)(puVar10 + 0x23) = 0;
  param_1[1] = 0;
  param_1[2] = (longlong)puVar10;
  *(undefined2 *)(puVar10 + 0x23) = 1;
  *puVar10 = uVar14;
  puVar10[1] = lVar22;
  puVar10[2] = uVar19;
LAB_08f75713:
  *param_1 = *param_1 + 1;
  return;
LAB_08f7563b:
  lVar22 = param_2[1];
  if (lVar22 == -1) {
    return;
  }
  uVar14 = *param_2;
  uVar19 = param_2[2];
  if (puVar10 != (undefined8 *)0x0) {
    uVar3 = *(ushort *)(puVar10 + 0x23);
    uVar16 = (ulonglong)uVar3;
    if (10 < uVar16) {
      if (uVar18 < 5) {
        uVar16 = 4;
        bVar23 = false;
      }
      else if (uVar18 == 5) {
        bVar23 = false;
        uVar16 = 5;
      }
      else if (uVar18 == 6) {
        bVar23 = true;
        uVar18 = 0;
        uVar16 = 5;
      }
      else {
        uVar16 = 6;
        bVar23 = true;
        uVar18 = uVar18 - 7;
      }
      puVar8 = FUN_08fc693d(0,0x120);
      if (puVar8 != (undefined8 *)0x0) {
        puVar8[0x22] = 0;
        *(undefined2 *)(puVar8 + 0x23) = 0;
        uVar20 = ~uVar16 + (ulonglong)*(ushort *)(puVar10 + 0x23);
        *(short *)(puVar8 + 0x23) = (short)uVar20;
        if (uVar20 < 0xc) {
          puVar13 = puVar10 + uVar16 * 3;
          uVar17 = *puVar13;
          lVar15 = puVar13[1];
          local_80 = puVar13[2];
          FUN_08fee630(puVar8,puVar13 + 3,uVar20 * 0x18);
          *(short *)(puVar10 + 0x23) = (short)uVar16;
          puVar13 = puVar8;
          if (!bVar23) {
            puVar13 = puVar10;
          }
          uVar3 = *(ushort *)(puVar13 + 0x23);
          if (uVar18 + 1 <= (ulonglong)uVar3) {
            FUN_08fee630(puVar13 + (uVar18 + 1) * 3,puVar13 + uVar18 * 3,(uVar3 - uVar18) * 0x18);
          }
          puVar13[uVar18 * 3] = uVar14;
          puVar13[uVar18 * 3 + 1] = lVar22;
          puVar13[uVar18 * 3 + 2] = uVar19;
          *(ushort *)(puVar13 + 0x23) = uVar3 + 1;
          if (lVar15 == -1) goto LAB_08f75713;
          if ((undefined8 *)puVar10[0x22] == (undefined8 *)0x0) {
            local_70 = 0;
          }
          else {
            local_70 = 0;
            puVar13 = puVar8;
            puVar21 = (undefined8 *)puVar10[0x22];
            do {
              uVar3 = *(ushort *)(puVar10 + 0x21);
              uVar16 = (ulonglong)uVar3;
              local_48 = local_80;
              uVar2 = *(ushort *)(puVar21 + 0x23);
              local_58 = uVar17;
              local_50 = lVar15;
              if (uVar2 < 0xb) {
                FUN_08fab0e4(uVar16,(longlong)puVar21,&local_58,puVar13);
                goto LAB_08f75713;
              }
              if (uVar3 < 5) {
                bVar23 = false;
                uVar18 = 4;
              }
              else if (uVar16 == 5) {
                bVar23 = false;
                uVar18 = 5;
              }
              else if (uVar3 == 6) {
                bVar23 = true;
                uVar18 = 5;
                uVar16 = 0;
              }
              else {
                bVar23 = true;
                uVar18 = 6;
                uVar16 = uVar16 - 7;
              }
              puVar8 = FUN_08fc693d(0,0x180);
              if (puVar8 == (undefined8 *)0x0) goto LAB_08f75727;
              puVar8[0x22] = 0;
              *(undefined2 *)(puVar8 + 0x23) = 0;
              uVar20 = ~uVar18 + (ulonglong)*(ushort *)(puVar21 + 0x23);
              *(short *)(puVar8 + 0x23) = (short)uVar20;
              if (0xb < uVar20) goto LAB_08f75727;
              puVar10 = puVar21 + uVar18 * 3;
              uVar17 = *puVar10;
              lVar15 = puVar10[1];
              local_80 = puVar10[2];
              FUN_08fee630(puVar8,puVar10 + 3,uVar20 * 0x18);
              *(short *)(puVar21 + 0x23) = (short)uVar18;
              if (0xb < (ulonglong)*(ushort *)(puVar8 + 0x23)) goto LAB_08f75727;
              iVar7 = (uint)uVar2 - (int)uVar18;
              lVar22 = (ulonglong)*(ushort *)(puVar8 + 0x23) + 1;
              if (iVar7 != (int)lVar22) goto LAB_08f75727;
              local_70 = local_70 + 1;
              FUN_08fee630(puVar8 + 0x24,puVar21 + uVar18 + 0x25,(ulonglong)(uint)(iVar7 * 8));
              lVar9 = 0;
              do {
                lVar5 = puVar8[lVar9 + 0x24];
                *(undefined8 **)(lVar5 + 0x110) = puVar8;
                *(short *)(lVar5 + 0x108) = (short)lVar9;
                lVar9 = lVar9 + 1;
              } while (lVar9 != lVar22);
              puVar10 = puVar8;
              if (!bVar23) {
                puVar10 = puVar21;
              }
              FUN_08fab0e4(uVar16,(longlong)puVar10,&local_58,puVar13);
              if (lVar15 == -1) goto LAB_08f75713;
              puVar1 = puVar21 + 0x22;
              puVar10 = puVar21;
              puVar13 = puVar8;
              puVar21 = (undefined8 *)*puVar1;
            } while ((undefined8 *)*puVar1 != (undefined8 *)0x0);
          }
          lVar22 = param_1[2];
          if (lVar22 != 0) {
            lVar9 = param_1[1];
            pvVar11 = FUN_08fc693d(0,0x180);
            if (pvVar11 != (LPVOID)0x0) {
              *(undefined8 *)((longlong)pvVar11 + 0x110) = 0;
              *(undefined2 *)((longlong)pvVar11 + 0x118) = 0;
              *(longlong *)((longlong)pvVar11 + 0x120) = lVar22;
              lVar22 = lVar9 + 1;
              if (lVar22 != 0) {
                lVar5 = *(longlong *)((longlong)pvVar11 + 0x120);
                *(LPVOID *)(lVar5 + 0x110) = pvVar11;
                *(undefined2 *)(lVar5 + 0x108) = 0;
                param_1[1] = lVar22;
                param_1[2] = (longlong)pvVar11;
                if (local_70 == lVar9) {
                  uVar16 = (ulonglong)*(ushort *)((longlong)pvVar11 + 0x118);
                  if (uVar16 < 0xb) {
                    sVar12 = *(ushort *)((longlong)pvVar11 + 0x118) + 1;
                    *(short *)((longlong)pvVar11 + 0x118) = sVar12;
                    *(undefined8 *)((longlong)pvVar11 + uVar16 * 0x18) = uVar17;
                    *(longlong *)((longlong)pvVar11 + uVar16 * 0x18 + 8) = lVar15;
                    *(undefined8 *)((longlong)pvVar11 + uVar16 * 0x18 + 0x10) = local_80;
                    *(undefined8 **)((longlong)pvVar11 + uVar16 * 8 + 0x128) = puVar8;
                    puVar8[0x22] = pvVar11;
                    *(short *)(puVar8 + 0x21) = sVar12;
                    goto LAB_08f75713;
                  }
                }
              }
            }
          }
        }
      }
      goto LAB_08f75727;
    }
    if (uVar18 + 1 <= uVar16) {
      FUN_08fee630(puVar10 + (uVar18 + 1) * 3,puVar10 + uVar18 * 3,(uVar16 - uVar18) * 0x18);
    }
    puVar10[uVar18 * 3] = uVar14;
    puVar10[uVar18 * 3 + 1] = lVar22;
    puVar10[uVar18 * 3 + 2] = uVar19;
    *(ushort *)(puVar10 + 0x23) = uVar3 + 1;
    goto LAB_08f75713;
  }
  goto LAB_08f756d4;
}

