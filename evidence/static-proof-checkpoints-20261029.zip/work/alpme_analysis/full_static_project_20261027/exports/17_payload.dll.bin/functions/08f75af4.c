/* address=08f75af4 rva=0x5af4 */

bool FUN_08f75af4(byte *param_1,longlong param_2)

{
  bool bVar1;
  ulonglong local_60 [3];
  int local_48;
  uint local_38;
  uint local_20;
  
  FUN_08f84076(local_60,param_1,param_2);
  if (local_48 == 2) {
    bVar1 = false;
    if ((1 < ((uint)local_60[0] & 3) - 2) && ((local_60[0] & 3) != 0)) {
      (**(code **)(local_60[0] + 7))(local_60[0] - 1);
      bVar1 = false;
    }
  }
  else {
    bVar1 = (local_20 & 0x10) == 0 && ((local_38 >> 0x1d & 1) == 0 || (local_20 >> 10 & 1) == 0);
  }
  return bVar1;
}

