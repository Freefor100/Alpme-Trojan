/* address=08f73a25 rva=0x3a25 */

undefined8 FUN_08f73a25(byte *param_1,longlong param_2,byte *param_3)

{
  undefined8 uVar1;
  LPCWSTR local_38;
  longlong local_30;
  
  FUN_08fbda35((ulonglong *)&local_38,param_1,param_2);
  if (local_30 == -1) {
    uVar1 = 1;
  }
  else {
    uVar1 = FUN_08f72e85(local_38,param_3);
    FUN_08fba6b1(local_38,local_30,2,2);
  }
  return uVar1;
}

