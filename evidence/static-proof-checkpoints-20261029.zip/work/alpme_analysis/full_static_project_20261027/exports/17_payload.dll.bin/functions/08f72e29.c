/* address=08f72e29 rva=0x2e29 */

void FUN_08f72e29(longlong param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  
  if ((*(ulonglong *)(param_1 + 0x130) & 1) == 0) {
    iVar5 = 1;
    uVar3 = 0;
    uVar4 = 0;
    do {
      uVar2 = uVar3;
      uVar1 = uVar4;
      if (uVar4 < 7) {
        while (uVar1 != 0) {
          uVar2 = uVar2 - 1;
          uVar1 = uVar2;
        }
      }
      else {
        SwitchToThread();
      }
      uVar4 = uVar4 + 1;
      uVar3 = uVar3 + iVar5;
      iVar5 = iVar5 + 2;
    } while ((*(ulonglong *)(param_1 + 0x130) & 1) == 0);
  }
  return;
}

