/* address=08f73f37 rva=0x3f37 */

void FUN_08f73f37(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  int iVar9;
  longlong lVar10;
  longlong lVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  uint uVar16;
  ulonglong uVar17;
  undefined8 *puVar18;
  undefined8 *puVar19;
  
  uVar2 = param_1[8];
  uVar3 = param_1[2];
  uVar15 = uVar2;
  if (uVar3 <= uVar2) {
    uVar15 = uVar3;
  }
  iVar9 = memcmp((void *)param_1[6],(void *)*param_1,uVar15);
  uVar16 = (uint)(uVar2 - uVar3 >> 0x20);
  if (iVar9 != 0) {
    uVar16 = iVar9 >> 0x1f;
  }
  uVar2 = param_1[0x14];
  uVar3 = param_1[0xe];
  uVar15 = uVar2;
  if (uVar3 <= uVar2) {
    uVar15 = uVar3;
  }
  iVar9 = memcmp((void *)param_1[0x12],(void *)param_1[0xc],uVar15);
  uVar15 = (ulonglong)(uint)(((int)uVar16 >> 0x1f) * -0x30);
  lVar10 = (longlong)iVar9;
  if (iVar9 == 0) {
    lVar10 = uVar2 - uVar3;
  }
  puVar19 = param_1 + 0xc;
  if (-1 < lVar10) {
    puVar19 = param_1 + 0x12;
  }
  puVar12 = param_1 + 0x12;
  if (-1 < lVar10) {
    puVar12 = param_1 + 0xc;
  }
  uVar17 = (ulonglong)(uint)(((int)~uVar16 >> 0x1f) * -0x30);
  puVar1 = (undefined8 *)((longlong)param_1 + uVar17);
  uVar2 = puVar12[2];
  uVar3 = *(ulonglong *)((longlong)param_1 + uVar15 + 0x10);
  uVar14 = uVar2;
  if (uVar3 <= uVar2) {
    uVar14 = uVar3;
  }
  iVar9 = memcmp((void *)*puVar12,*(void **)((longlong)param_1 + uVar15),uVar14);
  lVar10 = (longlong)iVar9;
  if (iVar9 == 0) {
    lVar10 = uVar2 - uVar3;
  }
  uVar2 = puVar19[2];
  uVar3 = *(ulonglong *)((longlong)param_1 + uVar17 + 0x10);
  uVar14 = uVar2;
  if (uVar3 <= uVar2) {
    uVar14 = uVar3;
  }
  iVar9 = memcmp((void *)*puVar19,*(void **)((longlong)param_1 + uVar17),uVar14);
  puVar13 = puVar1;
  if (-1 < lVar10) {
    puVar13 = puVar12;
  }
  lVar11 = (longlong)iVar9;
  if (iVar9 == 0) {
    lVar11 = uVar2 - uVar3;
  }
  puVar18 = puVar12;
  if (-1 < lVar11) {
    puVar18 = puVar1;
    puVar1 = puVar19;
    puVar19 = puVar13;
  }
  if (lVar10 < 0) {
    puVar18 = (undefined8 *)((longlong)param_1 + uVar15);
  }
  else {
    puVar12 = (undefined8 *)((longlong)param_1 + uVar15);
  }
  uVar2 = puVar19[2];
  uVar3 = puVar18[2];
  uVar15 = uVar2;
  if (uVar3 <= uVar2) {
    uVar15 = uVar3;
  }
  iVar9 = memcmp((void *)*puVar19,(void *)*puVar18,uVar15);
  lVar10 = uVar2 - uVar3;
  if (iVar9 != 0) {
    lVar10 = (longlong)iVar9;
  }
  puVar13 = puVar18;
  if (lVar10 < 0) {
    puVar13 = puVar19;
    puVar19 = puVar18;
  }
  uVar4 = *puVar12;
  uVar5 = puVar12[1];
  uVar6 = puVar12[2];
  uVar7 = puVar12[3];
  uVar8 = puVar12[5];
  param_2[4] = puVar12[4];
  param_2[5] = uVar8;
  param_2[2] = uVar6;
  param_2[3] = uVar7;
  *param_2 = uVar4;
  param_2[1] = uVar5;
  uVar4 = *puVar13;
  uVar5 = puVar13[1];
  uVar6 = puVar13[2];
  uVar7 = puVar13[3];
  uVar8 = puVar13[5];
  param_2[10] = puVar13[4];
  param_2[0xb] = uVar8;
  param_2[8] = uVar6;
  param_2[9] = uVar7;
  param_2[6] = uVar4;
  param_2[7] = uVar5;
  uVar4 = *puVar19;
  uVar5 = puVar19[1];
  uVar6 = puVar19[2];
  uVar7 = puVar19[3];
  uVar8 = puVar19[5];
  param_2[0x10] = puVar19[4];
  param_2[0x11] = uVar8;
  param_2[0xe] = uVar6;
  param_2[0xf] = uVar7;
  param_2[0xc] = uVar4;
  param_2[0xd] = uVar5;
  uVar4 = *puVar1;
  uVar5 = puVar1[1];
  uVar6 = puVar1[2];
  uVar7 = puVar1[3];
  uVar8 = puVar1[5];
  param_2[0x16] = puVar1[4];
  param_2[0x17] = uVar8;
  param_2[0x14] = uVar6;
  param_2[0x15] = uVar7;
  param_2[0x12] = uVar4;
  param_2[0x13] = uVar5;
  return;
}

