/* address=08f71568 rva=0x1568 */

/* WARNING: Function: __chkstk replaced with injection: alloca_probe */

void FUN_08f71568(void)

{
  LPVOID pvVar1;
  int *piVar2;
  undefined1 local_c00 [3000];
  undefined8 uStack_48;
  
  uStack_48 = 0x8f7157e;
  ANALYST_constant_init();
  pvVar1 = FUN_08fc693d(0,0x140);
  piVar2 = &DAT_08ffc8a0;
  if (pvVar1 == (LPVOID)0x0) {
    piVar2 = &DAT_08ffc870;
  }
                    /* WARNING: Could not recover jumptable at 0x08f7160d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(&LAB_08f7160f + *piVar2))(local_c00);
  return;
}

