/* address=08f71480 rva=0x1480 */

void FUN_08f71480(longlong *param_1,uint param_2)

{
  longlong lVar1;
  undefined1 uVar2;
  undefined1 uVar3;
  ulonglong uVar4;
  undefined1 uVar5;
  uint local_1c;
  
  uVar3 = (undefined1)param_2;
  if (param_2 < 0x80) {
    local_1c = param_2 & 0xff;
    uVar4 = 1;
  }
  else {
    uVar2 = (undefined1)(param_2 >> 6);
    if (param_2 < 0x800) {
      local_1c = (uint)(CONCAT11(uVar3,uVar2) & 0x3fff | 0x80c0);
      uVar4 = 2;
    }
    else {
      uVar5 = (undefined1)(param_2 >> 0xc);
      if (param_2 < 0x10000) {
        local_1c = (uint)(CONCAT12(uVar3,CONCAT11(uVar2,uVar5)) & 0x3f3fff | 0x8080e0);
        uVar4 = 3;
      }
      else {
        local_1c = CONCAT13(uVar3,CONCAT12(uVar2,CONCAT11(uVar5,(char)(param_2 >> 0x12)))) &
                   0x3f3f3fff | 0x808080f0;
        uVar4 = 4;
      }
    }
  }
  FUN_08fa5f6a(param_1,uVar4);
  lVar1 = param_1[2];
  FUN_08fee630((undefined8 *)(*param_1 + lVar1),(undefined8 *)&local_1c,uVar4);
  param_1[2] = lVar1 + uVar4;
  return;
}

