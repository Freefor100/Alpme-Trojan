/* address=08f731ad rva=0x31ad */

void FUN_08f731ad(undefined8 *param_1,longlong *param_2,undefined8 *param_3,undefined8 *param_4)

{
  undefined8 *puVar1;
  ushort uVar2;
  ushort uVar3;
  longlong lVar4;
  code *pcVar5;
  int iVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  ulonglong uVar9;
  longlong lVar10;
  LPVOID pvVar11;
  undefined8 *puVar12;
  longlong lVar13;
  undefined8 *puVar14;
  undefined8 uVar15;
  ulonglong uVar16;
  longlong lVar17;
  longlong lVar18;
  short sVar19;
  ulonglong uVar20;
  ulonglong uVar21;
  void *_Buf1;
  bool bVar22;
  ulonglong local_150;
  undefined8 local_118;
  undefined8 local_110;
  undefined8 local_108;
  longlong lStack_100;
  undefined8 local_f8;
  undefined8 local_e8;
  longlong lStack_e0;
  undefined8 local_d8;
  undefined8 *local_d0;
  undefined8 *local_c8;
  longlong local_c0;
  undefined8 local_b8;
  longlong lStack_b0;
  undefined8 local_a8;
  undefined8 local_98;
  longlong lStack_90;
  undefined8 local_88;
  undefined8 local_78;
  longlong lStack_70;
  undefined8 local_68;
  undefined8 local_58;
  longlong lStack_50;
  undefined8 local_48;
  
  puVar7 = (undefined8 *)param_2[2];
  if (puVar7 != (undefined8 *)0x0) {
    lVar17 = param_2[1];
    _Buf1 = (void *)*param_3;
    uVar16 = param_3[2];
    local_c8 = puVar7;
    local_c0 = lVar17;
    do {
      uVar2 = *(ushort *)(puVar7 + 0x44);
      uVar20 = 0xffffffffffffffff;
      lVar13 = (ulonglong)((uint)uVar2 * 8) * 3;
      puVar8 = puVar7;
      do {
        if (lVar13 == 0) {
          uVar20 = (ulonglong)uVar2;
          goto LAB_08f73381;
        }
        uVar21 = puVar8[2];
        uVar9 = uVar21;
        if (uVar16 < uVar21) {
          uVar9 = uVar16;
        }
        iVar6 = memcmp(_Buf1,(void *)*puVar8,uVar9);
        lVar18 = (longlong)iVar6;
        if (iVar6 == 0) {
          lVar18 = uVar16 - uVar21;
        }
        lVar13 = lVar13 + -0x18;
        uVar20 = uVar20 + 1;
        puVar8 = puVar8 + 3;
      } while ((char)((0 < lVar18) - (lVar18 < 0)) == '\x01');
      if (0 < lVar18 == lVar18 < 0) {
        FUN_08fba6b1(_Buf1,param_3[1],1,1);
        param_1[2] = puVar7[uVar20 * 3 + 0x23];
        uVar15 = (puVar7 + uVar20 * 3 + 0x21)[1];
        *param_1 = puVar7[uVar20 * 3 + 0x21];
        param_1[1] = uVar15;
        uVar15 = param_4[1];
        puVar7[uVar20 * 3 + 0x21] = *param_4;
        (puVar7 + uVar20 * 3 + 0x21)[1] = uVar15;
        puVar7[uVar20 * 3 + 0x23] = param_4[2];
        return;
      }
LAB_08f73381:
      bVar22 = lVar17 == 0;
      lVar17 = lVar17 + -1;
      if (bVar22) goto LAB_08f733b0;
      puVar7 = (undefined8 *)puVar7[uVar20 + 0x45];
    } while( true );
  }
  _Buf1 = (void *)*param_3;
  uVar15 = param_3[1];
  uVar16 = param_3[2];
LAB_08f732e2:
  puVar7 = FUN_08fc693d(0,0x228);
  if (puVar7 == (undefined8 *)0x0) {
LAB_08f73a23:
                    /* WARNING: Does not return */
    pcVar5 = (code *)invalidInstructionException();
    (*pcVar5)();
  }
  puVar7[0x43] = 0;
  param_2[1] = 0;
  param_2[2] = (longlong)puVar7;
  *(undefined2 *)(puVar7 + 0x44) = 1;
  *puVar7 = _Buf1;
  puVar7[1] = uVar15;
  puVar7[2] = uVar16;
  uVar15 = param_4[1];
  puVar7[0x21] = *param_4;
  puVar7[0x22] = uVar15;
  puVar7[0x23] = param_4[2];
LAB_08f73339:
  *param_2 = *param_2 + 1;
  param_1[1] = 0xffffffffffffffff;
  return;
LAB_08f733b0:
  uVar15 = param_3[1];
  if (puVar7 != (undefined8 *)0x0) {
    if (10 < uVar2) {
      if (uVar20 < 5) {
        bVar22 = false;
        uVar21 = 4;
      }
      else if (uVar20 == 5) {
        bVar22 = false;
        uVar21 = 5;
      }
      else if (uVar20 == 6) {
        uVar21 = 5;
        bVar22 = true;
        uVar20 = 0;
      }
      else {
        uVar20 = uVar20 - 7;
        uVar21 = 6;
        bVar22 = true;
      }
      puVar8 = FUN_08fc693d(0,0x228);
      if (puVar8 != (undefined8 *)0x0) {
        puVar8[0x43] = 0;
        *(undefined2 *)(puVar8 + 0x44) = 0;
        uVar9 = ~uVar21 + (ulonglong)*(ushort *)(puVar7 + 0x44);
        *(short *)(puVar8 + 0x44) = (short)uVar9;
        local_110 = puVar7[uVar21 * 3];
        lVar17 = puVar7[uVar21 * 3 + 1];
        local_118 = puVar7[uVar21 * 3 + 2];
        local_f8 = puVar7[uVar21 * 3 + 0x23];
        local_108 = puVar7[uVar21 * 3 + 0x21];
        lStack_100 = (puVar7 + uVar21 * 3 + 0x21)[1];
        if (uVar9 < 0xc) {
          local_d0 = puVar7 + 0x21;
          FUN_08fee630(puVar8,puVar7 + uVar21 * 3 + 3,uVar9 * 0x18);
          FUN_08fee630(puVar8 + 0x21,local_d0 + uVar21 * 3 + 3,uVar9 * 0x18);
          *(short *)(puVar7 + 0x44) = (short)uVar21;
          local_78 = local_108;
          lStack_70 = lStack_100;
          local_68 = local_f8;
          puVar12 = puVar8;
          if (!bVar22) {
            puVar12 = puVar7;
          }
          uVar2 = *(ushort *)(puVar12 + 0x44);
          puVar14 = puVar12 + uVar20 * 3;
          if (uVar20 < uVar2) {
            uVar21 = (ulonglong)(((uint)uVar2 - (int)uVar20) * 8) * 3;
            FUN_08fee630(puVar12 + uVar20 * 3 + 3,puVar14,uVar21);
            FUN_08fee630(puVar12 + uVar20 * 3 + 0x24,puVar12 + uVar20 * 3 + 0x21,uVar21);
          }
          *puVar14 = _Buf1;
          puVar14[1] = uVar15;
          puVar14[2] = uVar16;
          puVar12[uVar20 * 3 + 0x23] = param_4[2];
          uVar15 = param_4[1];
          puVar12[uVar20 * 3 + 0x21] = *param_4;
          (puVar12 + uVar20 * 3 + 0x21)[1] = uVar15;
          *(ushort *)(puVar12 + 0x44) = uVar2 + 1;
          if (lVar17 == -1) goto LAB_08f73339;
          local_d8 = local_68;
          local_e8 = local_78;
          lStack_e0 = lStack_70;
          lVar13 = 0;
          if ((undefined8 *)puVar7[0x43] != (undefined8 *)0x0) {
            puVar12 = puVar8;
            puVar14 = (undefined8 *)puVar7[0x43];
            do {
              uVar2 = *(ushort *)(puVar7 + 0x42);
              local_150 = (ulonglong)uVar2;
              local_108 = local_110;
              local_f8 = local_118;
              uVar3 = *(ushort *)(puVar14 + 0x44);
              lStack_100 = lVar17;
              if (uVar3 < 0xb) {
                FUN_08fd72ad(local_150,(longlong)puVar14,&local_108,&local_e8,puVar12);
                goto LAB_08f73339;
              }
              if (uVar2 < 5) {
                uVar16 = 4;
                bVar22 = false;
              }
              else if (local_150 == 5) {
                bVar22 = false;
                uVar16 = 5;
              }
              else if (uVar2 == 6) {
                bVar22 = true;
                uVar16 = 5;
                local_150 = 0;
              }
              else {
                local_150 = local_150 - 7;
                uVar16 = 6;
                bVar22 = true;
              }
              puVar8 = FUN_08fc693d(0,0x288);
              if (puVar8 == (undefined8 *)0x0) goto LAB_08f73a23;
              puVar8[0x43] = 0;
              *(undefined2 *)(puVar8 + 0x44) = 0;
              uVar20 = ~uVar16 + (ulonglong)*(ushort *)(puVar14 + 0x44);
              *(short *)(puVar8 + 0x44) = (short)uVar20;
              lVar18 = (ulonglong)(uint)((int)uVar16 * 8) * 3;
              local_110 = *(undefined8 *)((longlong)puVar14 + lVar18);
              lVar17 = *(longlong *)((longlong)puVar14 + lVar18 + 8);
              local_118 = *(undefined8 *)((longlong)puVar14 + lVar18 + 0x10);
              local_48 = *(undefined8 *)((longlong)puVar14 + lVar18 + 0x118);
              puVar7 = (undefined8 *)((longlong)puVar14 + lVar18 + 0x108);
              local_58 = *puVar7;
              lStack_50 = puVar7[1];
              if (0xb < uVar20) goto LAB_08f73a23;
              FUN_08fee630(puVar8,puVar14 + uVar16 * 3 + 3,uVar20 * 0x18);
              FUN_08fee630(puVar8 + 0x21,puVar14 + uVar16 * 3 + 0x24,uVar20 * 0x18);
              *(short *)(puVar14 + 0x44) = (short)uVar16;
              local_b8 = local_58;
              lStack_b0 = lStack_50;
              local_a8 = local_48;
              if (0xb < (ulonglong)*(ushort *)(puVar8 + 0x44)) goto LAB_08f73a23;
              iVar6 = (uint)uVar3 - (int)uVar16;
              lVar18 = (ulonglong)*(ushort *)(puVar8 + 0x44) + 1;
              if (iVar6 != (int)lVar18) goto LAB_08f73a23;
              lVar13 = lVar13 + 1;
              FUN_08fee630(puVar8 + 0x45,puVar14 + uVar16 + 0x46,(ulonglong)(uint)(iVar6 * 8));
              lVar10 = 0;
              do {
                lVar4 = puVar8[lVar10 + 0x45];
                *(undefined8 **)(lVar4 + 0x218) = puVar8;
                *(short *)(lVar4 + 0x210) = (short)lVar10;
                lVar10 = lVar10 + 1;
              } while (lVar10 != lVar18);
              local_88 = local_a8;
              local_98 = local_b8;
              lStack_90 = lStack_b0;
              puVar7 = puVar8;
              if (!bVar22) {
                puVar7 = puVar14;
              }
              FUN_08fd72ad(local_150,(longlong)puVar7,&local_108,&local_e8,puVar12);
              if (lVar17 == -1) goto LAB_08f73339;
              local_d8 = local_88;
              local_e8 = local_98;
              lStack_e0 = lStack_90;
              puVar1 = puVar14 + 0x43;
              puVar7 = puVar14;
              puVar12 = puVar8;
              puVar14 = (undefined8 *)*puVar1;
            } while ((undefined8 *)*puVar1 != (undefined8 *)0x0);
          }
          pvVar11 = FUN_08fc693d(0,0x288);
          if (pvVar11 != (LPVOID)0x0) {
            *(undefined8 *)((longlong)pvVar11 + 0x218) = 0;
            *(undefined2 *)((longlong)pvVar11 + 0x220) = 0;
            *(undefined8 **)((longlong)pvVar11 + 0x228) = local_c8;
            if (local_c0 + 1 != 0) {
              lVar18 = *(longlong *)((longlong)pvVar11 + 0x228);
              *(LPVOID *)(lVar18 + 0x218) = pvVar11;
              *(undefined2 *)(lVar18 + 0x210) = 0;
              param_2[1] = local_c0 + 1;
              param_2[2] = (longlong)pvVar11;
              if (local_c0 == lVar13) {
                uVar16 = (ulonglong)*(ushort *)((longlong)pvVar11 + 0x220);
                if (uVar16 < 0xb) {
                  sVar19 = *(ushort *)((longlong)pvVar11 + 0x220) + 1;
                  *(short *)((longlong)pvVar11 + 0x220) = sVar19;
                  *(undefined8 *)((longlong)pvVar11 + uVar16 * 0x18) = local_110;
                  *(longlong *)((longlong)pvVar11 + uVar16 * 0x18 + 8) = lVar17;
                  *(undefined8 *)((longlong)pvVar11 + uVar16 * 0x18 + 0x10) = local_118;
                  puVar7 = (undefined8 *)((longlong)pvVar11 + uVar16 * 0x18 + 0x108);
                  *puVar7 = local_e8;
                  puVar7[1] = lStack_e0;
                  *(undefined8 *)((longlong)pvVar11 + uVar16 * 0x18 + 0x118) = local_d8;
                  *(undefined8 **)((longlong)pvVar11 + uVar16 * 8 + 0x230) = puVar8;
                  puVar8[0x43] = pvVar11;
                  *(short *)(puVar8 + 0x42) = sVar19;
                  goto LAB_08f73339;
                }
              }
            }
          }
        }
      }
      goto LAB_08f73a23;
    }
    puVar8 = puVar7 + uVar20 * 3;
    if (uVar20 < uVar2) {
      uVar21 = (ulonglong)(((uint)uVar2 - (int)uVar20) * 8) * 3;
      FUN_08fee630(puVar7 + uVar20 * 3 + 3,puVar8,uVar21);
      FUN_08fee630(puVar7 + uVar20 * 3 + 0x24,puVar7 + uVar20 * 3 + 0x21,uVar21);
    }
    *puVar8 = _Buf1;
    puVar8[1] = uVar15;
    puVar8[2] = uVar16;
    puVar7[uVar20 * 3 + 0x23] = param_4[2];
    uVar15 = param_4[1];
    puVar7[uVar20 * 3 + 0x21] = *param_4;
    (puVar7 + uVar20 * 3 + 0x21)[1] = uVar15;
    *(ushort *)(puVar7 + 0x44) = uVar2 + 1;
    goto LAB_08f73339;
  }
  goto LAB_08f732e2;
}

