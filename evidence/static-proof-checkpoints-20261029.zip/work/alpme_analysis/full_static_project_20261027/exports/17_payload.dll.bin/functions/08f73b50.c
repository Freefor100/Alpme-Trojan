/* address=08f73b50 rva=0x3b50 */

longlong FUN_08f73b50(undefined8 *param_1,ulonglong param_2)

{
  longlong lVar1;
  
  if (((ulonglong)(param_1[1] - param_1[2]) < param_2) &&
     (lVar1 = FUN_08fb9e65(param_1,param_1[2],param_2,(undefined8 *)0x1,1), lVar1 != -1)) {
    return lVar1;
  }
  return -1;
}

