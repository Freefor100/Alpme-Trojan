/* address=08f72e85 rva=0x2e85 */

undefined8 FUN_08f72e85(LPCWSTR param_1,byte *param_2)

{
  byte bVar1;
  byte bVar2;
  bool bVar3;
  BOOL BVar4;
  DWORD DVar5;
  HANDLE hFile;
  undefined8 *puVar6;
  DWORD dwDesiredAccess;
  ulonglong uVar7;
  FILETIME *lpLastAccessTime;
  _SECURITY_ATTRIBUTES *lpSecurityAttributes;
  FILETIME *lpLastWriteTime;
  FILETIME local_40;
  undefined8 local_38;
  _SECURITY_ATTRIBUTES local_30;
  
  bVar1 = param_2[0x14];
  if (param_2[0x1d] == 0) {
    if (bVar1 != 0) goto LAB_08f72ea9;
    DVar5 = (uint)param_2[0x1c] * 2 + 3;
  }
  else {
    DVar5 = 4;
    if (bVar1 != 0) {
LAB_08f72ea9:
      DVar5 = 1;
    }
  }
  local_30.nLength = 0x18;
  local_30.lpSecurityDescriptor = (LPVOID)0x0;
  local_30.bInheritHandle = (BOOL)*param_2;
  if (*(int *)(param_2 + 8) == 1) {
    dwDesiredAccess = *(DWORD *)(param_2 + 0xc);
  }
  else {
    bVar2 = param_2[2];
    if (param_2[0x24] == 0) {
      if (param_2[0x25] != 0) goto LAB_08f72f0f;
      if ((param_2[0x1d] != 0 || param_2[0x1c] != 0) || bVar1 != 0) {
        puVar6 = (undefined8 *)&DAT_08ff4d8f;
        uVar7 = 0x3d;
        goto LAB_08f72f25;
      }
      dwDesiredAccess = 0x80000000;
      if (bVar2 == 0) {
        uVar7 = 0x3a;
        puVar6 = (undefined8 *)&DAT_08ff6faa;
        goto LAB_08f72f25;
      }
    }
    else if (param_2[0x25] == 0) {
      dwDesiredAccess = (uint)(byte)~bVar2 * -0x80000000 + 0xc0000000;
    }
    else {
LAB_08f72f0f:
      if (param_2[0x1c] == 1 && bVar1 == 0) {
        puVar6 = (undefined8 *)&DAT_08ff5feb;
        uVar7 = 0x2a;
LAB_08f72f25:
        FUN_08fc0670(puVar6,uVar7);
        return 1;
      }
      dwDesiredAccess = (uint)(byte)~bVar2 * -0x80000000 + 0x80120114;
    }
  }
  lpSecurityAttributes = &local_30;
  if (*param_2 == 0) {
    lpSecurityAttributes = (LPSECURITY_ATTRIBUTES)0x0;
  }
  hFile = CreateFileW(param_1,dwDesiredAccess,*(DWORD *)(param_2 + 0x10),lpSecurityAttributes,DVar5,
                      (uint)bVar1 << 0x15 | *(uint *)(param_2 + 0x20) | *(uint *)(param_2 + 0x18) |
                      *(uint *)(param_2 + 4),(HANDLE)0x0);
  if (hFile == (HANDLE)0xffffffffffffffff) {
    GetLastError();
    if ((undefined **)PTR_PTR_0900af90 != &PTR_LAB_08ff19c8) {
      PTR_PTR_0900af90 = (undefined *)&PTR_LAB_08ff19c8;
    }
    return 1;
  }
  if (param_2[0x26] == 0) {
    if (param_2[1] != 0) {
      lpLastAccessTime = (FILETIME *)0x0;
      lpLastWriteTime = &local_40;
      goto LAB_08f73009;
    }
  }
  else {
    lpLastAccessTime = &local_40;
    lpLastWriteTime = (FILETIME *)0x0;
    if (param_2[1] != 0) {
      lpLastWriteTime = lpLastAccessTime;
    }
LAB_08f73009:
    local_40.dwLowDateTime = 0xffffffff;
    local_40.dwHighDateTime = 0xffffffff;
    BVar4 = SetFileTime(hFile,(FILETIME *)0x0,lpLastAccessTime,lpLastWriteTime);
    if (BVar4 == 0) {
      GetLastError();
      goto LAB_08f730a8;
    }
  }
  if (DVar5 != 4) {
    return 0;
  }
  if (param_2[0x1c] == 0) {
    return 0;
  }
  DVar5 = GetLastError();
  if (DVar5 == 0xb7) {
    local_40.dwLowDateTime = 0;
    local_40.dwHighDateTime = 0;
    bVar3 = FUN_08fba05b(hFile,FileAllocationInfo,&local_40);
    if (bVar3) {
      local_38 = 0;
      bVar3 = FUN_08fba05b(hFile,FileEndOfFileInfo,&local_38);
      if (bVar3) {
LAB_08f730a8:
        if ((undefined **)PTR_PTR_0900af90 != &PTR_LAB_08ff19c8) {
          PTR_PTR_0900af90 = (undefined *)&PTR_LAB_08ff19c8;
        }
        CloseHandle(hFile);
        return 1;
      }
    }
  }
  return 0;
}

