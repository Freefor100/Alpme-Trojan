/* address=08f72bf2 rva=0x2bf2 */

ulonglong FUN_08f72bf2(ushort *param_1,longlong param_2,longlong param_3,longlong param_4,
                      undefined8 param_5,longlong param_6)

{
  char *pcVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  char cVar4;
  uint uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  longlong lVar8;
  uint uVar9;
  longlong lVar10;
  ushort uVar11;
  uint uVar12;
  ushort uVar13;
  ulonglong uVar14;
  undefined7 uVar16;
  ulonglong uVar15;
  
  if ((char)param_2 == '\0') {
    uVar14 = param_6 + 1;
    uVar5 = *(uint *)(param_1 + 2);
    uVar12 = 0x2d;
  }
  else {
    uVar5 = *(uint *)(param_1 + 2);
    uVar14 = (ulonglong)((uVar5 & 0x200000) >> 0x15) + param_6;
    uVar12 = -(uint)((uVar5 & 0x200000) == 0) | 0x2b;
  }
  if ((uVar5 >> 0x17 & 1) == 0) {
    param_3 = 0;
  }
  else {
    lVar8 = 0;
    if (param_4 != 0) {
      param_2 = 0;
      do {
        pcVar1 = (char *)(param_3 + param_2);
        param_2 = param_2 + 1;
        lVar8 = lVar8 + (ulonglong)(-0x41 < *pcVar1);
      } while (param_4 != param_2);
    }
    uVar14 = uVar14 + lVar8;
  }
  uVar11 = *param_1;
  uVar16 = (undefined7)(uVar14 >> 8);
  if (uVar14 < uVar11) {
    if ((uVar5 >> 0x18 & 1) == 0) {
      uVar15 = CONCAT71(uVar16,1);
      uVar9 = (uint)CONCAT62((int6)((ulonglong)param_2 >> 0x10),uVar11 - (short)uVar14);
      uVar5 = FUN_08f9b0b9((longlong)param_1,uVar9,'\x01');
      if (uVar5 != 0xffffffff) {
        uVar3 = *(undefined8 *)(param_1 + 8);
        lVar8 = *(longlong *)(param_1 + 0xc);
        uVar6 = FUN_08f9bdcd(uVar3,lVar8,uVar12,param_3,param_4);
        if (((char)uVar6 == '\0') &&
           (cVar4 = (**(code **)(lVar8 + 0x18))(uVar3,param_5,param_6), cVar4 == '\0')) {
          uVar13 = 0xffff;
          uVar11 = (ushort)uVar9;
          do {
            if ((ushort)(uVar13 - uVar11) == -1) {
              uVar13 = uVar11;
              break;
            }
            cVar4 = (**(code **)(lVar8 + 0x20))(uVar3,uVar5);
            uVar13 = uVar13 + 1;
          } while (cVar4 == '\0');
          uVar15 = CONCAT71(uVar16,uVar13 < uVar11);
        }
      }
    }
    else {
      uVar2 = *(undefined4 *)(param_1 + 4);
      uVar3 = *(undefined8 *)param_1;
      *(uint *)(param_1 + 2) = uVar5 & 0x9fe00000 | 0x20000030;
      uVar6 = *(undefined8 *)(param_1 + 8);
      lVar8 = *(longlong *)(param_1 + 0xc);
      lVar10 = lVar8;
      uVar7 = FUN_08f9bdcd(uVar6,lVar8,uVar12,param_3,param_4);
      if ((char)uVar7 == '\0') {
        uVar12 = (uint)CONCAT62((int6)((ulonglong)lVar10 >> 0x10),uVar11 - (short)uVar14);
        uVar5 = FUN_08f9b0b9((longlong)param_1,uVar12,'\x01');
        if (uVar5 != 0xffffffff) {
          cVar4 = (**(code **)(lVar8 + 0x18))(uVar6,param_5,param_6);
          if (cVar4 == '\0') {
            uVar12 = (uVar12 & 0xffff) + 1;
            do {
              uVar11 = (short)uVar12 - 1;
              uVar12 = (uint)uVar11;
              if (uVar11 == 0) {
                *(undefined4 *)(param_1 + 4) = uVar2;
                *(undefined8 *)param_1 = uVar3;
                uVar15 = 0;
                goto LAB_08f72db0;
              }
              cVar4 = (**(code **)(lVar8 + 0x20))(uVar6,uVar5);
            } while (cVar4 == '\0');
          }
        }
      }
      uVar15 = CONCAT71(uVar16,1);
    }
  }
  else {
    uVar3 = *(undefined8 *)(param_1 + 8);
    lVar8 = *(longlong *)(param_1 + 0xc);
    uVar6 = FUN_08f9bdcd(uVar3,lVar8,uVar12,param_3,param_4);
    uVar15 = CONCAT71(uVar16,1);
    if ((char)uVar6 == '\0') {
                    /* WARNING: Could not recover jumptable at 0x08f72e25. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar14 = (**(code **)(lVar8 + 0x18))(uVar3,param_5,param_6);
      return uVar14;
    }
  }
LAB_08f72db0:
  return uVar15 & 0xffffffff;
}

