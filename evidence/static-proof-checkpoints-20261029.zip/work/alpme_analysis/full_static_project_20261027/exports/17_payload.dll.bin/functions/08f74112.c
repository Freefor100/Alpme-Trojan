/* address=08f74112 rva=0x4112 */

/* WARNING: Function: __chkstk replaced with injection: alloca_probe */

ulonglong FUN_08f74112(uint param_1,longlong param_2)

{
  code *pcVar1;
  DWORD DVar2;
  uint uVar3;
  HMODULE lpSource;
  ulonglong uVar4;
  undefined8 uVar5;
  longlong lVar6;
  code **ppcVar7;
  ushort *puVar8;
  uint local_105c;
  code *local_1058;
  uint *local_1050;
  code *local_1048;
  uint *local_1040;
  code *local_1038;
  code **local_1030;
  undefined1 local_1028 [4088];
  undefined8 uStack_30;
  
  uStack_30 = 0x8f74122;
  lpSource = (HMODULE)0x0;
  local_105c = param_1;
  FUN_08feece0((undefined1 (*) [32])local_1028,0,0x1000);
  DVar2 = 0x1200;
  if ((param_1 >> 0x1c & 1) != 0) {
    lpSource = GetModuleHandleW(L"NTDLL.DLL");
    if (lpSource == (HMODULE)0x0) {
      lpSource = (HMODULE)0x0;
    }
    else {
      param_1 = param_1 & 0xefffffff;
      DVar2 = 0x1a00;
      local_105c = param_1;
    }
  }
  DVar2 = FormatMessageW(DVar2,lpSource,param_1,0,(LPWSTR)local_1028,0x800,(va_list *)0x0);
  if (DVar2 == 0) {
    DVar2 = GetLastError();
    local_1058 = (code *)CONCAT44(local_1058._4_4_,DVar2);
    ppcVar7 = &local_1048;
    local_1048 = FUN_08fba8f4;
    local_1040 = &local_105c;
    local_1038 = FUN_08fba8f4;
    uVar5 = *(undefined8 *)(param_2 + 0x10);
    lVar6 = *(longlong *)(param_2 + 0x18);
    puVar8 = (ushort *)0x8ff30fa;
    local_1030 = &local_1058;
  }
  else {
    if (0x800 < DVar2) {
                    /* WARNING: Does not return */
      pcVar1 = (code *)invalidInstructionException();
      (*pcVar1)();
    }
    FUN_08fb5d49(&local_1048,(longlong)local_1028,(ulonglong)DVar2);
    ppcVar7 = &local_1058;
    local_1050 = &local_105c;
    if (local_1040 != (uint *)0xffffffffffffffff) {
      for (; local_1038 != (code *)0x0; local_1038 = local_1038 + -1) {
        if ((0x20 < (ulonglong)(byte)local_1048[(longlong)(local_1038 + -1)]) ||
           ((0x100003600U >> ((ulonglong)(byte)local_1048[(longlong)(local_1038 + -1)] & 0x3f) & 1)
            == 0)) goto LAB_08f7424c;
      }
      local_1038 = (code *)0x0;
LAB_08f7424c:
      uVar3 = (**(code **)(*(longlong *)(param_2 + 0x18) + 0x18))
                        (*(undefined8 *)(param_2 + 0x10),local_1048,local_1038);
      FUN_08fba6b1(local_1048,(longlong)local_1040,1,1);
      return (ulonglong)uVar3;
    }
    local_1058 = FUN_08fba8f4;
    uVar5 = *(undefined8 *)(param_2 + 0x10);
    lVar6 = *(longlong *)(param_2 + 0x18);
    puVar8 = (ushort *)0x8ff5eec;
  }
  uVar4 = FUN_08f75e3d(uVar5,lVar6,(ulonglong)ppcVar7,puVar8);
  return uVar4 & 0xffffffff;
}

