/* address=08f72b7f rva=0x2b7f */

void FUN_08f72b7f(undefined8 *param_1,undefined8 *param_2,ulonglong param_3)

{
  code *pcVar1;
  char local_40 [8];
  undefined8 *local_38;
  undefined8 local_30;
  
  FUN_08fcb993((undefined8 *)local_40,param_3,'\0',2,2);
  if (local_40[0] != '\0') {
                    /* WARNING: Does not return */
    pcVar1 = (code *)invalidInstructionException();
    (*pcVar1)();
  }
  if (param_3 != 0) {
    FUN_08fee630(local_38,param_2,param_3 * 2);
  }
  *param_1 = local_38;
  param_1[1] = local_30;
  param_1[2] = param_3;
  return;
}

