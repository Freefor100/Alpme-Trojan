/* address=08f72954 rva=0x2954 */

void FUN_08f72954(longlong *param_1,longlong param_2)

{
  code *pcVar1;
  uint uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  short *psVar6;
  char local_58 [8];
  short *local_50;
  short *local_48;
  longlong local_40;
  longlong lStack_38;
  longlong lStack_30;
  undefined1 uStack_28;
  undefined7 uStack_27;
  
  psVar6 = (short *)(param_2 + 0x34);
  uVar5 = 0x104;
  uVar3 = FUN_08f9d226(psVar6,0x104);
  uVar4 = 0x104;
  if ((uVar3 & 1) != 0) {
    if (0x104 < uVar5) goto LAB_08f72a0c;
    uVar4 = uVar5;
  }
  FUN_08fcb993(&local_40,uVar4,'\0',1,1);
  local_48 = psVar6 + uVar4;
  if ((char)local_40 == '\0') {
    local_40 = lStack_38;
    lStack_38 = lStack_30;
    lStack_30 = 0;
    uStack_28 = 1;
    local_58[0] = '\0';
    local_58[1] = '\0';
    local_50 = psVar6;
    while( true ) {
      uVar4 = FUN_08fb8166(local_58);
      if ((short)uVar4 == 2) break;
      if ((uVar4 & 1) == 0) {
        uVar2 = (uint)(uVar4 >> 0x20);
      }
      else {
        uVar2 = (uint)(uVar4 >> 0x10) & 0xffff;
        uStack_28 = 0;
      }
      FUN_08f71480(&local_40,uVar2);
    }
    param_1[2] = lStack_30;
    param_1[3] = CONCAT71(uStack_27,uStack_28);
    *param_1 = local_40;
    param_1[1] = lStack_38;
    return;
  }
LAB_08f72a0c:
                    /* WARNING: Does not return */
  pcVar1 = (code *)invalidInstructionException();
  (*pcVar1)();
}

