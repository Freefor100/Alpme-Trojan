/* address=08f742ac rva=0x42ac */

ulonglong FUN_08f742ac(uint param_1)

{
  undefined8 in_RAX;
  undefined7 uVar2;
  ulonglong uVar1;
  
  uVar2 = (undefined7)((ulonglong)in_RAX >> 8);
  uVar1 = CONCAT71(uVar2,1);
  if (0x377 < param_1) {
    if (param_1 < 0x3fffe) {
      uVar1 = FUN_08f9bd16(param_1);
      uVar1 = uVar1 ^ 1;
    }
    else if ((param_1 != 0xe0001 && 0xfffd < param_1 - 0xf0000) &&
             (0x5f < param_1 - 0xe0020 && 0xef < param_1 - 0xe0100)) {
      uVar1 = CONCAT71(uVar2,param_1 - 0x100000 < 0xfffe);
    }
  }
  return uVar1;
}

