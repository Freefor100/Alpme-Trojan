/* address=08f73acd rva=0x3acd */

void FUN_08f73acd(undefined8 *param_1,longlong param_2)

{
  undefined8 *puVar1;
  code *pcVar2;
  undefined8 uVar3;
  
  puVar1 = *(undefined8 **)*param_1;
  *(longlong *)*param_1 = 0;
  if (puVar1 == (undefined8 *)0x0) {
                    /* WARNING: Does not return */
    pcVar2 = (code *)invalidInstructionException();
    (*pcVar2)();
  }
  if (*(char *)(param_2 + 4) != '\0') {
    FUN_08fef408();
                    /* WARNING: Does not return */
    pcVar2 = (code *)invalidInstructionException();
    (*pcVar2)();
  }
  uVar3 = (*(code *)*puVar1)();
  *puVar1 = uVar3;
  puVar1[1] = param_2;
  return;
}

