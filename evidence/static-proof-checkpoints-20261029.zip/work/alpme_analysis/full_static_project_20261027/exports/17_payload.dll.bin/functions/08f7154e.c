/* address=08f7154e rva=0x154e */

void FUN_08f7154e(undefined8 *param_1)

{
  undefined8 local_8;
  
  local_8 = *param_1;
  FUN_08fd229b(&local_8);
  return;
}

