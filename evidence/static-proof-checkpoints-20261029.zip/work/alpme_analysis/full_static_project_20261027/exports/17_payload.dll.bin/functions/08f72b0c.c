/* address=08f72b0c rva=0x2b0c */

void FUN_08f72b0c(undefined8 *param_1)

{
  longlong lVar1;
  
  lVar1 = param_1[1];
  if (lVar1 == -1) {
    return;
  }
  FUN_08fba649(param_1 + 3);
  FUN_08fba6b1((LPVOID)*param_1,lVar1,1,1);
  return;
}

