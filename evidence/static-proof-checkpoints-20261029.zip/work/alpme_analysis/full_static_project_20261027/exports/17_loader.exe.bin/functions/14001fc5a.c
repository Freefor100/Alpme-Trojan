/* address=14001fc5a rva=0x1fc5a */

undefined8 FUN_14001fc5a(void)

{
  char cVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  longlong lVar5;
  longlong lVar6;
  char *pcVar7;
  byte *unaff_RBP;
  byte *unaff_RDI;
  uint *unaff_R14;
  
  iVar3 = *(int *)(unaff_RDI + 4);
  if (iVar3 == 0) {
    lVar5 = 0;
  }
  else {
    lVar5 = FUN_14001a6c0();
    lVar5 = lVar5 + iVar3;
  }
  lVar6 = FUN_14001a700();
  if (lVar5 != *(int *)(unaff_RBP + 4) + lVar6) {
    iVar3 = *(int *)(unaff_RDI + 4);
    if (iVar3 == 0) {
      lVar5 = 0;
    }
    else {
      lVar5 = FUN_14001a6c0();
      lVar5 = lVar5 + iVar3;
    }
    iVar3 = *(int *)(unaff_RBP + 4);
    lVar6 = FUN_14001a700();
    pcVar7 = (char *)(lVar5 + 0x10);
    lVar5 = ((longlong)iVar3 + 0x10 + lVar6) - (longlong)pcVar7;
    do {
      cVar1 = *pcVar7;
      cVar2 = pcVar7[lVar5];
      if (cVar1 != cVar2) break;
      pcVar7 = pcVar7 + 1;
    } while (cVar2 != '\0');
    if (cVar1 != cVar2) {
      return 0;
    }
  }
  if ((((((*unaff_RBP & 2) == 0) || ((*unaff_RDI & 8) != 0)) &&
       ((uVar4 = *unaff_R14, (uVar4 & 1) == 0 || ((*unaff_RDI & 1) != 0)))) &&
      (((uVar4 & 4) == 0 || ((*unaff_RDI & 4) != 0)))) &&
     (((uVar4 & 2) == 0 || ((*unaff_RDI & 2) != 0)))) {
    return 1;
  }
  return 0;
}

