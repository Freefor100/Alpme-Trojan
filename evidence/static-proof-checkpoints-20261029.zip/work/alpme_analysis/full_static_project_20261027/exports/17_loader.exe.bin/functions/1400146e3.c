/* address=1400146e3 rva=0x146e3 */

void FUN_1400146e3(undefined8 *param_1,ulonglong param_2,byte param_3,longlong param_4,
                  ulonglong param_5)

{
  undefined1 auVar1 [16];
  undefined1 auVar2 [16];
  ulonglong uVar3;
  LPVOID pvVar4;
  longlong lVar5;
  undefined8 uVar6;
  
  auVar1._8_8_ = 0;
  auVar1._0_8_ = param_2;
  auVar2._8_8_ = 0;
  auVar2._0_8_ = param_5;
  uVar3 = SUB168(auVar1 * auVar2,0);
  uVar6 = 1;
  if (0x8000000000000000U - param_4 < uVar3 || SUB168(auVar1 * auVar2,8) != 0) {
    lVar5 = 8;
  }
  else {
    if (uVar3 != 0) {
      pvVar4 = FUN_1400128ed((uint)param_3 << 3,uVar3);
      if (pvVar4 == (LPVOID)0x0) {
        param_1[1] = param_4;
        lVar5 = 0x10;
      }
      else {
        param_1[1] = pvVar4;
        lVar5 = 0x10;
        uVar6 = 0;
        uVar3 = param_2;
      }
      goto LAB_14001476c;
    }
    param_1[1] = param_4;
    uVar6 = 0;
    lVar5 = 0x10;
  }
  uVar3 = 0;
LAB_14001476c:
  *(ulonglong *)((longlong)param_1 + lVar5) = uVar3;
  *param_1 = uVar6;
  return;
}

