/* address=14001623c rva=0x1623c */

void FUN_14001623c(undefined8 param_1,int *param_2,undefined8 *param_3,int *param_4)

{
  FUN_140017cb4(*param_2);
  FUN_14001617c(param_3);
  FUN_140017cd0(*param_4);
  return;
}

