/* address=14001ff10 rva=0x1ff10 */

void FUN_14001ff10(longlong param_1,longlong *param_2,uint *param_3,byte *param_4)

{
  char cVar1;
  int iVar2;
  undefined7 extraout_var;
  longlong lVar3;
  longlong lVar4;
  undefined *puVar5;
  longlong *plVar6;
  
  if ((int)*param_3 < 0) {
    plVar6 = param_2;
  }
  else {
    plVar6 = (longlong *)((longlong)(int)param_3[2] + *param_2);
  }
  cVar1 = FUN_14001fd30(param_1,param_2,param_3,param_4);
  iVar2 = (int)CONCAT71(extraout_var,cVar1);
  if (iVar2 == 1) {
    lVar3 = FUN_140015c70(*(longlong *)(param_1 + 0x28),(int *)(param_4 + 8));
    iVar2 = *(int *)(param_4 + 0x18);
    if (iVar2 == 0) {
      puVar5 = (undefined *)0x0;
    }
    else {
      lVar4 = FUN_14001a700();
      puVar5 = (undefined *)(lVar4 + iVar2);
    }
    FUN_14001f860(plVar6,puVar5,lVar3);
  }
  else if (iVar2 == 2) {
    lVar3 = FUN_140015c70(*(longlong *)(param_1 + 0x28),(int *)(param_4 + 8));
    iVar2 = *(int *)(param_4 + 0x18);
    if (iVar2 == 0) {
      puVar5 = (undefined *)0x0;
    }
    else {
      lVar4 = FUN_14001a700();
      puVar5 = (undefined *)(lVar4 + iVar2);
    }
    FUN_14001f870(plVar6,puVar5,lVar3,1);
  }
  return;
}

