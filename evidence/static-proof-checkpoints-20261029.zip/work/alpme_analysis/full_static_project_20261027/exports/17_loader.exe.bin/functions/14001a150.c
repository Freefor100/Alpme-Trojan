/* address=14001a150 rva=0x1a150 */

ulonglong FUN_14001a150(void)

{
  return (ulonglong)(uint3)((uint)*(undefined4 *)((longlong)ProcessEnvironmentBlock + 0xbc) >> 8) &
         0xffffffffffffff01;
}

