/* address=14001f930 rva=0x1f930 */

undefined8 * FUN_14001f930(undefined8 *param_1)

{
  param_1[2] = 0;
  param_1[1] = "bad exception";
  *param_1 = std::bad_exception::vftable;
  return param_1;
}

