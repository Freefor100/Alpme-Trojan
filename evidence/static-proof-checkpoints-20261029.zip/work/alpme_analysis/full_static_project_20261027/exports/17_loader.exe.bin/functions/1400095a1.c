/* address=1400095a1 rva=0x95a1 */

ulonglong FUN_1400095a1(uint param_1)

{
  longlong lVar1;
  ulonglong uVar2;
  longlong lVar3;
  ulonglong uVar4;
  uint uVar5;
  uint uVar6;
  ulonglong uVar7;
  
  uVar4 = 0xc;
  lVar1 = 0;
  do {
    uVar2 = uVar4 >> 1;
    uVar4 = uVar4 - uVar2;
    lVar3 = uVar2 + lVar1;
    if (param_1 < ((&DAT_1400736b8)[lVar3] & 0x1fffff)) {
      lVar3 = lVar1;
    }
    lVar1 = lVar3;
  } while (1 < uVar4);
  uVar7 = (ulonglong)((&DAT_1400736b8)[lVar3] * 0x800 == param_1 * 0x800) + lVar3 +
          (ulonglong)((uint)((&DAT_1400736b8)[lVar3] * 0x800) < param_1 * 0x800);
  uVar4 = (ulonglong)((uint)(&DAT_1400736b8)[uVar7] >> 0x15);
  uVar2 = 0x23;
  if ((uVar7 < 0xb) &&
     (uVar2 = (ulonglong)(*(uint *)(&DAT_1400736bc + uVar7 * 4) >> 0x15), uVar7 == 0)) {
    uVar5 = 0;
  }
  else {
    uVar5 = *(uint *)(&DAT_1400736b4 + uVar7 * 4) & 0x1fffff;
  }
  if (~uVar4 + uVar2 != 0) {
    uVar6 = 0;
    do {
      uVar6 = (byte)(&DAT_140075215)[uVar4] + uVar6;
      if (param_1 - uVar5 < uVar6) break;
      uVar4 = uVar4 + 1;
    } while (uVar2 - 1 != uVar4);
  }
  return uVar4 & 0xffffffffffffff01;
}

