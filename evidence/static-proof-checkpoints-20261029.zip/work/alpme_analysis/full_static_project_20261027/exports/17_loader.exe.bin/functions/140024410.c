/* address=140024410 rva=0x24410 */

void FUN_140024410(undefined8 *param_1,longlong param_2)

{
  FUN_14001f9c0(param_1,*(longlong *)(param_2 + 0xd8),(undefined4 *)(param_2 + 0x20));
  return;
}

