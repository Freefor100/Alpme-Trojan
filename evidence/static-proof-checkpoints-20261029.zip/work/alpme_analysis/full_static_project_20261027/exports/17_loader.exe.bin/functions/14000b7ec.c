/* address=14000b7ec rva=0xb7ec */

void thunk_FUN_14000254d(void)

{
  int *piVar1;
  undefined8 auStack_590 [3];
  undefined1 uStack_571;
  undefined1 uStack_570;
  undefined1 uStack_56f;
  undefined1 uStack_56e;
  undefined1 uStack_56d;
  undefined1 uStack_56c;
  undefined1 uStack_56b;
  undefined1 uStack_56a;
  undefined1 uStack_569;
  undefined2 uStack_560;
  undefined2 uStack_55e;
  undefined2 uStack_55c;
  undefined2 uStack_55a;
  undefined2 uStack_558;
  undefined2 uStack_556;
  undefined2 uStack_554;
  undefined4 uStack_530;
  undefined4 uStack_52c;
  undefined4 uStack_528;
  undefined4 uStack_524;
  undefined4 uStack_520;
  undefined4 uStack_51c;
  undefined4 uStack_518;
  undefined4 uStack_514;
  char *pcStack_510;
  undefined8 uStack_508;
  undefined8 *puStack_500;
  undefined8 uStack_d0;
  undefined8 uStack_c8;
  undefined8 uStack_c0;
  undefined8 uStack_b8;
  undefined8 uStack_b0;
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined8 uStack_98;
  undefined8 uStack_90;
  undefined8 uStack_88;
  undefined8 uStack_80;
  undefined8 uStack_78;
  undefined8 uStack_70;
  undefined8 uStack_68;
  
  FUN_140012ed0();
  uStack_b8 = 0xf241ff6198b24821;
  uStack_569 = 0xf3;
  uStack_52c = 0x4e8dff8a;
  uStack_56f = 0xb0;
  uStack_556 = 0x4eed;
  uStack_558 = 0x1e66;
  uStack_560 = 0x84d4;
  uStack_51c = 0x2045940c;
  uStack_554 = 0x22aa;
  uStack_68 = 0xdf88c2144a901470;
  uStack_90 = 0x6338a7a6604a9c31;
  uStack_98 = 0x50cc327829cb0950;
  uStack_56e = 0xe1;
  uStack_56c = 0x75;
  uStack_528 = 0x50054eba;
  uStack_a0 = 0x2362abe8324d976e;
  uStack_518 = 0x292cae21;
  uStack_d0 = 0x1bc959f92b2487a1;
  uStack_a8 = 0x2f043c641c5546a4;
  uStack_55a = 0x36c4;
  uStack_70 = 0x359ea2508da5974a;
  uStack_530 = 0x2fdeb6b8;
  uStack_c0 = 0x20e23910ae11b0c3;
  uStack_520 = 0xfffffffd;
  uStack_88 = 0xdd5fcfa00cf91850;
  uStack_56b = 0xff;
  uStack_80 = 0xe30a863bafbff79f;
  uStack_55c = 0x4ea4;
  uStack_524 = 0x3ce45f4f;
  uStack_56d = 0x36;
  uStack_571 = 0x23;
  uStack_55e = 0xec76;
  uStack_56a = 0x8d;
  uStack_514 = 0x2eeb8f69;
  uStack_78 = 0xdab794cf30ee6b9d;
  uStack_b0 = 0xffffffffffffffff;
  uStack_570 = 0x6f;
  uStack_c8 = 0xcb76519b7f9d6ccf;
  puStack_500 = auStack_590;
  auStack_590[0] = 0xe9d44cb7113359bc;
  pcStack_510 = 
  "mOalms3oyEIsqArE-agyC9BEZ0ErOCMmh8ZW16gTin.cdNjZMyt0-stl archive timestamp from deltaqJn49VYGTCmNhF9AhynDoleQINxaveCWXXeKAr_phDhsA-yPBz_e5ics9b6_BkarJJwybnAbZ2rxjzXUJeZZ-Udd01G6XJp14x0igKGDae-3wvJMsdZS2Pk4bsOHD9KUNZ4KrgcQySdtSa0dFDPR8h2j-P5TNFOgmAKthrough may little line had end eE9F-_gg5ofUHmLMfsJchdqV30mN8IrQx2mPktqiGvCMKI08h7hPYKAMf7R6h5BOHhizQvDdXypmaEDRsOAdpPMsZvL"
  ;
  uStack_508 = 0x34;
  piVar1 = &DAT_140075998;
  if (DAT_1400d0188 ==
      ((uint)*(undefined8 *)
              (*(longlong *)((longlong)ThreadLocalStoragePointer + (ulonglong)_tls_index * 8) + 0xd0
              ) ^ 0x519d6cb2)) {
    piVar1 = &DAT_1400757ec;
  }
                    /* WARNING: Could not recover jumptable at 0x0001400027ad. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(&LAB_140006d28 + *piVar1))();
  return;
}

