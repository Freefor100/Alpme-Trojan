/* address=14001e37c rva=0x1e37c */

uint FUN_14001e37c(void)

{
  undefined8 uVar1;
  
  uVar1 = FUN_1400185dc();
  return (uint)uVar1 & 0xff ^ 1;
}

