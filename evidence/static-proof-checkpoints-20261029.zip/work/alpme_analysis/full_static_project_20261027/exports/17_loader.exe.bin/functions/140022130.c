/* address=140022130 rva=0x22130 */

void FUN_140022130(char *param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  
  lVar2 = 0;
  cVar1 = *param_1;
  while ((cVar1 != '\0' && (lVar2 != param_2))) {
    lVar2 = lVar2 + 1;
    cVar1 = param_1[lVar2];
  }
  return;
}

