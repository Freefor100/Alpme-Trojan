/* address=140017530 rva=0x17530 */

LPVOID thunk_FUN_14001ac00(ulonglong param_1)

{
  bool bVar1;
  int iVar2;
  undefined7 extraout_var;
  LPVOID pvVar3;
  undefined8 *puVar4;
  
  if (param_1 < 0xffffffffffffffe1) {
    if (param_1 == 0) {
      param_1 = 1;
    }
    do {
      pvVar3 = HeapAlloc(DAT_1400d13b0,0,param_1);
      if (pvVar3 != (LPVOID)0x0) {
        return pvVar3;
      }
      iVar2 = FUN_140017120();
    } while ((iVar2 != 0) &&
            (bVar1 = FUN_140019720(param_1), (int)CONCAT71(extraout_var,bVar1) != 0));
  }
  puVar4 = FUN_140019fec();
  *(undefined4 *)puVar4 = 0xc;
  return (LPVOID)0x0;
}

