/* address=14001b1e8 rva=0x1b1e8 */

undefined ** FUN_14001b1e8(void)

{
  longlong lVar1;
  undefined **ppuVar2;
  
  lVar1 = FUN_140017dc0();
  if (((DAT_1400d0ba0 & *(uint *)(lVar1 + 0x3a8)) == 0) ||
     (ppuVar2 = *(undefined ***)(lVar1 + 0x90), ppuVar2 == (undefined **)0x0)) {
    FUN_140017cb4(4);
    ppuVar2 = FUN_14001b258((longlong *)(lVar1 + 0x90),DAT_1400d1818);
    FUN_140017cd0(4);
    if (ppuVar2 == (undefined **)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_1400172f8();
    }
  }
  return ppuVar2;
}

