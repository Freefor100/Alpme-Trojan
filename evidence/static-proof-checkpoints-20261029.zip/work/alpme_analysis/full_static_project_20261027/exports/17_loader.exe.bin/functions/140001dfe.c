/* address=140001dfe rva=0x1dfe */

void FUN_140001dfe(undefined8 *param_1)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  ulonglong *puVar3;
  code *pcVar4;
  bool bVar5;
  byte *pbVar6;
  ulonglong uVar7;
  int iVar8;
  ulonglong uVar9;
  uint uVar10;
  ulonglong uVar11;
  ulonglong uVar12;
  uint uVar13;
  ulonglong uVar14;
  byte bVar15;
  uint uVar16;
  longlong lVar17;
  ulonglong uVar18;
  ulonglong uVar19;
  uint uVar20;
  ulonglong uVar21;
  byte *pbVar22;
  uint uVar23;
  longlong lVar24;
  byte *pbVar25;
  byte *pbVar26;
  ulonglong uVar27;
  bool bVar28;
  uint local_1c4;
  byte *local_1b8;
  ulonglong local_1b0;
  ulonglong local_1a8;
  ulonglong *local_1a0;
  char local_198 [8];
  byte *local_190;
  ulonglong local_188;
  ulonglong local_180;
  ulonglong local_178;
  ulonglong local_170;
  byte local_80 [64];
  
  puVar2 = (undefined8 *)*param_1;
  pbVar26 = (byte *)*puVar2;
  lVar24 = puVar2[1];
  puVar3 = (ulonglong *)puVar2[3];
  *puVar2 = 0;
  if (pbVar26 != (byte *)0x0) {
    uVar19 = *(ulonglong *)puVar2[2];
    local_180 = 0xd0e87fd9439110d1;
    FUN_1400079e1(local_80,0xd0e87fd9439110d1);
    lVar17 = 0;
    FUN_1400237e0((undefined1 (*) [32])&local_180,0,0x100);
    do {
      *(char *)((longlong)&local_180 + (ulonglong)local_80[lVar17]) = (char)lVar17;
      lVar17 = lVar17 + 1;
    } while (lVar17 != 0x40);
    FUN_1400146e3((undefined8 *)local_198,((ulonglong)(lVar24 * 6) >> 3) + 1,0,1,1);
    if (local_198[0] == '\0') {
      local_1b8 = local_190;
      local_1b0 = local_188;
      local_1a8 = 0;
      pbVar22 = pbVar26 + lVar24;
      uVar27 = 0;
      uVar16 = 0;
      lVar24 = 0;
      uVar23 = 0;
      local_1a0 = puVar3;
      do {
        uVar13 = uVar23;
        uVar7 = local_1b0;
        pbVar6 = local_1b8;
        do {
          pbVar25 = pbVar26;
          lVar17 = lVar24;
          if (pbVar25 == pbVar22) {
            if (uVar27 != 0) {
              uVar12 = uVar19 ^ 0x88711a1537065dec;
              uVar14 = 0xd87c0799cad9da81;
              if (uVar19 != 0x88711a1537065dec) {
                uVar14 = (uVar12 << 0x31 | uVar12 >> 0xf) + 0x20edc5be3f5d5bc7;
              }
              uVar19 = 0;
              uVar12 = 0;
              do {
                if ((uVar12 & 7) == 0) {
                  uVar14 = (uVar14 << 0x31 | uVar14 >> 0xf) + 0x20edc5be3f5d5bc7;
                  uVar19 = (uVar14 >> 0x21 ^ uVar14) * -0x5f4b86ab973243d9;
                  uVar19 = uVar19 >> 0x20 ^ uVar19;
                }
                local_1b8[uVar12] =
                     local_1b8[uVar12] ^ (byte)(uVar19 >> (sbyte)((int)(uVar12 & 7) << 3));
                uVar12 = uVar12 + 1;
              } while (uVar12 != uVar27);
              uVar19 = 1;
              if (uVar27 != 0) {
                bVar15 = *local_1b8;
                uVar14 = 0;
                uVar12 = 0;
                uVar16 = 0;
                uVar23 = 1;
                bVar28 = false;
                uVar13 = 1;
                do {
                  uVar16 = uVar16 * 2;
                  if (uVar14 < uVar27) {
                    pbVar26 = local_1b8 + uVar14;
                    uVar23 = uVar13 + 1;
                    if (uVar23 == 8) {
                      uVar23 = 0;
                      uVar12 = uVar14 + 1;
                      uVar14 = uVar14 + 1;
                    }
                    uVar16 = uVar16 | (*pbVar26 >> (uVar13 & 7) & 1) != 0;
                    uVar13 = uVar23;
                  }
                  bVar5 = !bVar28;
                  bVar28 = true;
                } while (bVar5);
                iVar8 = (uVar16 << 3 ^ 0x18) + 8;
                if (iVar8 != 0) {
                  uVar16 = 0;
                  uVar14 = uVar12;
                  uVar13 = uVar23;
                  do {
                    uVar16 = uVar16 * 2;
                    if (uVar12 < uVar27) {
                      pbVar26 = local_1b8 + uVar12;
                      uVar23 = uVar13 + 1;
                      uVar9 = uVar12 + 1;
                      if (uVar23 == 8) {
                        uVar23 = 0;
                        uVar12 = uVar9;
                        uVar14 = uVar9;
                      }
                      uVar16 = uVar16 | (*pbVar26 >> (uVar13 & 7) & 1) != 0;
                      uVar13 = uVar23;
                    }
                    iVar8 = iVar8 + -1;
                  } while (iVar8 != 0);
                  if (uVar16 == 0) {
                    uVar12 = 0;
                    uVar27 = 0;
                    goto LAB_1400021d2;
                  }
                  uVar9 = (ulonglong)uVar16;
                  uVar19 = 0x4000000;
                  if (uVar9 < 0x4000000) {
                    uVar19 = uVar9;
                  }
                  FUN_1400146e3(&local_180,uVar19,0,1,1);
                  uVar19 = local_178;
                  if ((char)local_180 != '\0') goto LAB_14000213a;
                  local_180 = local_178;
                  local_178 = local_170;
                  local_170 = 0;
                  if ((bVar15 & 1) == 0) {
                    do {
                      uVar12 = local_170;
                      bVar15 = 0;
                      iVar8 = 8;
                      uVar18 = uVar14;
                      do {
                        bVar15 = bVar15 * '\x02';
                        if (uVar14 < uVar27) {
                          bVar15 = bVar15 | (pbVar6[uVar14] >> (uVar23 & 7) & 1) != 0;
                          uVar23 = uVar23 + 1;
                          uVar21 = uVar14 + 1;
                          if (uVar23 == 8) {
                            uVar23 = 0;
                            uVar14 = uVar21;
                            uVar18 = uVar21;
                          }
                        }
                        iVar8 = iVar8 + -1;
                      } while (iVar8 != 0);
                      if (local_170 == local_178) {
                        FUN_1400098aa(&local_180);
                        uVar19 = local_180;
                      }
                      *(byte *)(uVar19 + uVar12) = bVar15;
                      local_170 = uVar12 + 1;
                      uVar14 = uVar18;
                    } while (local_170 != uVar9);
                    uVar12 = uVar9;
                  }
                  else {
                    local_1c4 = 4;
                    if (uVar16 != 1) {
                      lVar24 = 0x3f;
                      if (uVar9 - 1 != 0) {
                        for (; uVar9 - 1 >> lVar24 == 0; lVar24 = lVar24 + -1) {
                        }
                      }
                      uVar13 = (int)lVar24 + 1;
                      uVar16 = 4;
                      if (4 < uVar13) {
                        uVar16 = uVar13;
                      }
                      local_1c4 = 0xc;
                      if (uVar16 < 0xc) {
                        local_1c4 = uVar16;
                      }
                    }
                    uVar12 = 0;
                    do {
                      if (uVar14 < uVar27) {
                        uVar16 = uVar23 + 1;
                        bVar28 = uVar16 == 8;
                        if (bVar28) {
                          uVar16 = 0;
                        }
                        uVar18 = bVar28 + uVar14;
                        if ((pbVar6[uVar14] >> (uVar23 & 7) & 1) == 0) goto LAB_140002142;
                        uVar21 = 0;
                        iVar8 = 5;
                        uVar13 = 0;
                        uVar14 = uVar18;
                        uVar23 = uVar16;
                        do {
                          uVar10 = (int)uVar21 * 2;
                          if (uVar18 < uVar27) {
                            uVar10 = uVar10 | (pbVar6[uVar18] >> (uVar16 & 7) & 1) != 0;
                            uVar21 = uVar18 + 1;
                            uVar23 = uVar16 + 1;
                            if (uVar16 + 1 == 8) {
                              uVar18 = uVar21;
                              uVar14 = uVar21;
                              uVar23 = uVar13;
                            }
                            uVar16 = uVar23;
                          }
                          uVar21 = (ulonglong)uVar10;
                          iVar8 = iVar8 + -1;
                        } while (iVar8 != 0);
                        uVar16 = 0;
                        uVar18 = uVar14;
                        uVar20 = local_1c4;
                        do {
                          uVar16 = uVar16 * 2;
                          if (uVar18 < uVar27) {
                            uVar16 = uVar16 | (pbVar6[uVar18] >> (uVar23 & 7) & 1) != 0;
                            uVar23 = uVar23 + 1;
                            if (uVar23 == 8) {
                              uVar14 = uVar18 + 1;
                              uVar18 = uVar18 + 1;
                              uVar23 = uVar13;
                            }
                          }
                          uVar20 = uVar20 - 1;
                        } while (uVar20 != 0);
                        uVar21 = uVar21 + 4;
                        if (uVar10 == 0x1f) {
                          do {
                            uVar11 = 0;
                            iVar8 = 8;
                            uVar18 = uVar14;
                            uVar10 = uVar23;
                            do {
                              uVar20 = (int)uVar11 * 2;
                              if (uVar18 < uVar27) {
                                uVar20 = uVar20 | (pbVar6[uVar18] >> (uVar10 & 7) & 1) != 0;
                                uVar11 = uVar18 + 1;
                                uVar23 = uVar10 + 1;
                                if (uVar10 + 1 == 8) {
                                  uVar18 = uVar11;
                                  uVar14 = uVar11;
                                  uVar23 = uVar13;
                                }
                                uVar10 = uVar23;
                              }
                              uVar11 = (ulonglong)uVar20;
                              iVar8 = iVar8 + -1;
                            } while (iVar8 != 0);
                            uVar21 = uVar21 + uVar11;
                          } while (0xfe < uVar20);
                        }
                        if (uVar12 <= uVar16) break;
                        uVar18 = uVar9 - uVar12;
                        if (uVar21 < uVar9 - uVar12) {
                          uVar18 = uVar21;
                        }
                        if (uVar18 != 0) {
                          uVar21 = ~(ulonglong)uVar16 + uVar12;
                          do {
                            if (uVar12 <= uVar21) goto LAB_14000213a;
                            uVar1 = *(undefined1 *)(uVar19 + uVar21);
                            if (uVar12 == local_178) {
                              FUN_1400098aa(&local_180);
                              uVar19 = local_180;
                            }
                            *(undefined1 *)(uVar19 + uVar12) = uVar1;
                            uVar12 = uVar12 + 1;
                            uVar21 = uVar21 + 1;
                            uVar18 = uVar18 - 1;
                            local_170 = uVar12;
                          } while (uVar18 != 0);
                        }
                      }
                      else {
                        uVar18 = uVar14;
                        uVar16 = uVar23;
LAB_140002142:
                        bVar15 = 0;
                        iVar8 = 8;
                        uVar14 = uVar18;
                        uVar23 = uVar16;
                        do {
                          bVar15 = bVar15 * '\x02';
                          if (uVar18 < uVar27) {
                            uVar16 = uVar23 + 1;
                            bVar15 = bVar15 | (pbVar6[uVar18] >> (uVar23 & 7) & 1) != 0;
                            uVar19 = uVar18 + 1;
                            if (uVar16 == 8) {
                              uVar16 = 0;
                              uVar18 = uVar19;
                              uVar14 = uVar19;
                            }
                            uVar23 = uVar16;
                          }
                          iVar8 = iVar8 + -1;
                        } while (iVar8 != 0);
                        if (uVar12 == local_178) {
                          FUN_1400098aa(&local_180);
                        }
                        *(byte *)(local_180 + uVar12) = bVar15;
                        uVar12 = uVar12 + 1;
                        uVar19 = local_180;
                        uVar23 = uVar16;
                        local_170 = uVar12;
                      }
                    } while (uVar12 < uVar9);
                  }
                  uVar27 = local_178;
                  uVar19 = local_180;
                  goto LAB_1400021d2;
                }
              }
            }
            uVar12 = 0;
            uVar19 = 1;
            uVar27 = 0;
LAB_1400021d2:
            FUN_14000250d(pbVar6,uVar7,1,1);
            *local_1a0 = uVar19;
            local_1a0[1] = uVar27;
            local_1a0[2] = uVar12;
            return;
          }
          pbVar26 = pbVar25 + 1;
          lVar24 = 0;
        } while (lVar17 == 0x2a);
        lVar24 = lVar17 + 1;
        uVar16 = (uint)*(byte *)((longlong)&local_180 + (ulonglong)*pbVar25) | uVar16 << 6;
        uVar23 = uVar13 + 6;
        if (1 < uVar13) {
          bVar15 = (byte)(uVar13 - 2);
          if (uVar27 == local_1b0) {
            FUN_1400098aa(&local_1b8);
            local_190 = local_1b8;
          }
          local_190[uVar27] = (byte)(uVar16 >> (bVar15 & 0x1f));
          uVar27 = uVar27 + 1;
          uVar16 = uVar16 & ~(-1 << (bVar15 & 0x1f));
          uVar23 = uVar13 - 2;
          local_1a8 = uVar27;
        }
      } while( true );
    }
  }
LAB_14000213a:
                    /* WARNING: Does not return */
  pcVar4 = (code *)invalidInstructionException();
  (*pcVar4)();
}

