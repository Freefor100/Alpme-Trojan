/* address=14001b4a0 rva=0x1b4a0 */

undefined8 FUN_14001b4a0(undefined8 param_1,ulonglong param_2,undefined8 param_3,longlong param_4)

{
  FUN_14001b2c0(param_2,param_4,*(int **)(param_4 + 0x38));
  return 1;
}

