/* address=14001c4e0 rva=0x1c4e0 */

ulonglong FUN_14001c4e0(byte *param_1,int param_2)

{
  byte bVar1;
  BOOL BVar2;
  undefined8 *puVar3;
  byte *pbVar4;
  longlong lVar5;
  ulonglong uVar6;
  byte *pbVar7;
  longlong *plVar8;
  char *pcVar9;
  undefined8 uVar10;
  longlong *plVar11;
  ulonglong uVar12;
  ulonglong uVar13;
  longlong lVar14;
  
  uVar12 = 0;
  if (param_1 == (byte *)0x0) {
    puVar3 = FUN_140019fec();
    *(undefined4 *)puVar3 = 0x16;
    return 0xffffffffffffffff;
  }
  pbVar4 = (byte *)FUN_140021520((ulonglong)param_1,'=');
  if ((pbVar4 == (byte *)0x0) || (pbVar4 == param_1)) {
    puVar3 = FUN_140019fec();
    *(undefined4 *)puVar3 = 0x16;
    FUN_1400191b0(param_1);
    return 0xffffffffffffffff;
  }
  bVar1 = pbVar4[1];
  if (DAT_1400d0fb8 == DAT_1400d0fd0) {
    DAT_1400d0fb8 = FUN_14001c838(DAT_1400d0fb8);
  }
  if (DAT_1400d0fb8 == (longlong *)0x0) {
    if ((param_2 == 0) || (DAT_1400d0fc0 == (LPVOID)0x0)) {
      if (bVar1 == 0) goto LAB_14001c6ea;
      DAT_1400d0fb8 = FUN_14001ab80(1,8);
      FUN_1400191b0((LPVOID)0x0);
      if (DAT_1400d0fb8 != (longlong *)0x0) {
        if (DAT_1400d0fc0 == (LPVOID)0x0) {
          DAT_1400d0fc0 = FUN_14001ab80(1,8);
          FUN_1400191b0((LPVOID)0x0);
          if (DAT_1400d0fc0 == (LPVOID)0x0) goto LAB_14001c592;
        }
LAB_14001c631:
        if (DAT_1400d0fb8 != (longlong *)0x0) goto LAB_14001c63a;
      }
    }
    else {
      lVar5 = FUN_140016b88();
      if (lVar5 != 0) {
        if (DAT_1400d0fb8 == DAT_1400d0fd0) {
          DAT_1400d0fb8 = FUN_14001c838(DAT_1400d0fb8);
        }
        goto LAB_14001c631;
      }
      puVar3 = FUN_140019fec();
      *(undefined4 *)puVar3 = 0x16;
    }
  }
  else {
LAB_14001c63a:
    plVar8 = DAT_1400d0fb8;
    uVar13 = (longlong)pbVar4 - (longlong)param_1;
    pbVar7 = (byte *)*DAT_1400d0fb8;
    plVar11 = DAT_1400d0fb8;
    while (pbVar7 != (byte *)0x0) {
      uVar6 = FUN_1400215b0(param_1,pbVar7,uVar13);
      if (((int)uVar6 == 0) &&
         ((*(char *)(uVar13 + *plVar11) == '=' || (*(char *)(uVar13 + *plVar11) == '\0')))) {
        uVar13 = (longlong)plVar11 - (longlong)plVar8 >> 3;
        goto LAB_14001c680;
      }
      plVar11 = plVar11 + 1;
      pbVar7 = (byte *)*plVar11;
    }
    uVar13 = -((longlong)plVar11 - (longlong)plVar8 >> 3);
LAB_14001c680:
    if ((-1 < (longlong)uVar13) && (*plVar8 != 0)) {
      FUN_1400191b0((LPVOID)plVar8[uVar13]);
      if (bVar1 == 0) {
        for (; plVar8[uVar13] != 0; uVar13 = uVar13 + 1) {
          plVar8[uVar13] = plVar8[uVar13 + 1];
        }
        plVar8 = FUN_14001c240(plVar8,uVar13,8);
        FUN_1400191b0((LPVOID)0x0);
        pbVar7 = param_1;
        if (plVar8 != (longlong *)0x0) {
          DAT_1400d0fb8 = plVar8;
        }
      }
      else {
        plVar8[uVar13] = (longlong)param_1;
LAB_14001c745:
        pbVar7 = (byte *)0x0;
      }
      if (param_2 == 0) {
LAB_14001c7e8:
        FUN_1400191b0(pbVar7);
        return 0;
      }
      lVar5 = -1;
      do {
        lVar14 = lVar5;
        lVar5 = lVar14 + 1;
      } while (param_1[lVar14 + 1] != 0);
      pcVar9 = FUN_14001ab80(lVar14 + 3,1);
      if (pcVar9 == (char *)0x0) {
        FUN_1400191b0((LPVOID)0x0);
      }
      else {
        uVar10 = FUN_140017540(pcVar9,lVar14 + 3,(longlong)param_1);
        if ((int)uVar10 != 0) {
                    /* WARNING: Subroutine does not return */
          FUN_1400192e4();
        }
        pbVar4[(longlong)pcVar9 - (longlong)param_1] = 0;
        BVar2 = FUN_140021754(pcVar9,(LPCSTR)(-(ulonglong)(bVar1 != 0) &
                                             (ulonglong)
                                             (pbVar4 + ((longlong)pcVar9 - (longlong)param_1) + 1)))
        ;
        if (BVar2 != 0) {
          FUN_1400191b0(pcVar9);
          goto LAB_14001c7e8;
        }
        puVar3 = FUN_140019fec();
        *(undefined4 *)puVar3 = 0x2a;
        FUN_1400191b0(pcVar9);
        uVar12 = 0xffffffff;
      }
      FUN_1400191b0(pbVar7);
      return uVar12;
    }
    if (bVar1 == 0) {
LAB_14001c6ea:
      uVar12 = 0;
      goto LAB_14001c596;
    }
    uVar6 = -uVar13 + 2;
    if ((-uVar13 <= uVar6) && (uVar6 < 0x1fffffffffffffff)) {
      plVar8 = FUN_14001c240(plVar8,uVar6,8);
      FUN_1400191b0((LPVOID)0x0);
      if (plVar8 != (longlong *)0x0) {
        plVar8[-uVar13] = (longlong)param_1;
        plVar8[1 - uVar13] = 0;
        DAT_1400d0fb8 = plVar8;
        goto LAB_14001c745;
      }
    }
  }
LAB_14001c592:
  uVar12 = 0xffffffffffffffff;
LAB_14001c596:
  FUN_1400191b0(param_1);
  return uVar12 & 0xffffffff;
}

