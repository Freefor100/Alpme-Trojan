/* address=140019760 rva=0x19760 */

void FUN_140019760(undefined8 param_1)

{
  DAT_1400d17f0 = param_1;
  return;
}

