/* address=14001e424 rva=0x1e424 */

undefined8 FUN_14001e424(undefined8 param_1,uint *param_2,undefined8 *param_3,uint *param_4)

{
  uint uVar1;
  BOOL BVar2;
  DWORD DVar3;
  HANDLE hFile;
  DWORD *pDVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  
  FUN_14001cbf4(*param_2);
  uVar1 = *(uint *)*param_3;
  if ((*(byte *)((&DAT_1400d13c0)[(longlong)(int)uVar1 >> 6] + 0x38 +
                (ulonglong)(uVar1 & 0x3f) * 0x48) & 1) != 0) {
    hFile = (HANDLE)FUN_14001c920(uVar1);
    BVar2 = FlushFileBuffers(hFile);
    uVar6 = 0;
    if (BVar2 != 0) goto LAB_14001e49b;
    DVar3 = GetLastError();
    pDVar4 = (DWORD *)FUN_14001a010();
    *pDVar4 = DVar3;
  }
  puVar5 = FUN_140019fec();
  *(undefined4 *)puVar5 = 9;
  uVar6 = 0xffffffff;
LAB_14001e49b:
  FUN_14001cc1c(*param_4);
  return uVar6;
}

