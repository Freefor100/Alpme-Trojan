/* address=1400154e0 rva=0x154e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1400154e0(void)

{
  _DAT_1400d0e10 = 0;
  return;
}

