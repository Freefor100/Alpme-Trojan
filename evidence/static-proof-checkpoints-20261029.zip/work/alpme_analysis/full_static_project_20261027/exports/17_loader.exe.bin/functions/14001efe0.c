/* address=14001efe0 rva=0x1efe0 */

void FUN_14001efe0(DWORD *param_1,uint param_2,short *param_3,uint param_4,undefined1 param_5)

{
  short sVar1;
  HANDLE hFile;
  uint uVar2;
  BOOL BVar3;
  DWORD DVar4;
  longlong lVar5;
  uint uVar6;
  ulonglong uVar7;
  short *psVar8;
  short *psVar9;
  undefined8 uStackX_10;
  undefined8 uStack_30;
  
  uStack_30 = 0x14001effc;
  lVar5 = FUN_140014e00();
  lVar5 = -lVar5;
  *(ulonglong *)((longlong)register0x00000020 + lVar5 + 0x1438) =
       DAT_1400d02c0 ^ (longlong)register0x00000020 + lVar5 + -0x28;
  hFile = *(HANDLE *)
           ((&DAT_1400d13c0)[(longlong)(int)param_2 >> 6] + 0x28 +
           (ulonglong)(param_2 & 0x3f) * 0x48);
  param_1[0] = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  psVar8 = param_3;
  do {
    if ((short *)((ulonglong)param_4 + (longlong)param_3) <= psVar8) {
LAB_14001f125:
      uVar7 = *(ulonglong *)((longlong)register0x00000020 + lVar5 + 0x1438);
      *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x14001f138;
      FUN_14001b4d0(uVar7 ^ (longlong)register0x00000020 + lVar5 + -0x28);
      return;
    }
    psVar9 = (short *)(&param_5 + lVar5);
    do {
      if ((short *)((ulonglong)param_4 + (longlong)param_3) <= psVar8) break;
      sVar1 = *psVar8;
      psVar8 = psVar8 + 1;
      if (sVar1 == 10) {
        *psVar9 = 0xd;
        psVar9 = psVar9 + 1;
      }
      *psVar9 = sVar1;
      psVar9 = psVar9 + 1;
    } while (psVar9 < (short *)((longlong)register0x00000020 + lVar5 + 0x6d0));
    *(undefined8 *)((longlong)&uStackX_10 + lVar5) = 0;
    *(undefined8 *)((longlong)register0x00000020 + lVar5 + 8) = 0;
    *(undefined4 *)((longlong)register0x00000020 + lVar5) = 0xd55;
    *(longlong *)((longlong)register0x00000020 + lVar5 + -8) =
         (longlong)register0x00000020 + lVar5 + 0x6d8;
    *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x14001f0c6;
    uVar2 = FUN_14001c2e8(0xfde9,0,&param_5 + lVar5,
                          (int)((longlong)psVar9 - (longlong)(&param_5 + lVar5) >> 1));
    if (uVar2 == 0) {
LAB_14001f11d:
      *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x14001f123;
      DVar4 = GetLastError();
      *param_1 = DVar4;
      goto LAB_14001f125;
    }
    uVar7 = 0;
    if (uVar2 != 0) {
      do {
        *(undefined4 *)((longlong)register0x00000020 + lVar5 + 0x18) = 0;
        *(undefined8 *)((longlong)register0x00000020 + lVar5 + -8) = 0;
        *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x14001f0fe;
        BVar3 = WriteFile(hFile,(LPCVOID)((longlong)register0x00000020 + uVar7 + lVar5 + 0x6d8),
                          uVar2 - (int)uVar7,(LPDWORD)((longlong)register0x00000020 + lVar5 + 0x18),
                          *(LPOVERLAPPED *)((longlong)register0x00000020 + lVar5 + -8));
        if (BVar3 == 0) goto LAB_14001f11d;
        uVar6 = (int)uVar7 + *(int *)((longlong)register0x00000020 + lVar5 + 0x18);
        uVar7 = (ulonglong)uVar6;
      } while (uVar6 < uVar2);
    }
    param_1[1] = (int)psVar8 - (int)param_3;
  } while( true );
}

