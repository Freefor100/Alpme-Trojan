/* address=1400151c0 rva=0x151c0 */

ulonglong FUN_1400151c0(void)

{
  bool bVar1;
  undefined7 extraout_var;
  void *pvVar2;
  
  bVar1 = FUN_140015930();
  pvVar2 = (void *)CONCAT71(extraout_var,bVar1);
  if ((int)pvVar2 != 0) {
    pvVar2 = (void *)0x0;
    LOCK();
    bVar1 = DAT_1400d0d98 == (void *)0x0;
    if (bVar1) {
      DAT_1400d0d98 = StackBase;
    }
    else {
      pvVar2 = DAT_1400d0d98;
    }
    UNLOCK();
    while (!bVar1) {
      if (StackBase == pvVar2) {
        return CONCAT71((int7)((ulonglong)pvVar2 >> 8),1);
      }
      pvVar2 = (void *)0x0;
      LOCK();
      bVar1 = DAT_1400d0d98 == (void *)0x0;
      if (bVar1) {
        DAT_1400d0d98 = StackBase;
      }
      else {
        pvVar2 = DAT_1400d0d98;
      }
      UNLOCK();
    }
  }
  return (ulonglong)pvVar2 & 0xffffffffffffff00;
}

