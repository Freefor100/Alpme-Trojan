/* address=140023fbe rva=0x23fbe */

void FUN_140023fbe(uint *param_1,char param_2,undefined8 param_3,longlong param_4)

{
  uint uVar1;
  code *pcVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  bool bVar7;
  uint local_34;
  uint local_30;
  undefined1 local_2c;
  
  uVar4 = *param_1;
  uVar5 = uVar4 & 3;
  uVar6 = uVar4 & 4;
  switch(uVar5) {
  case 0:
switchD_140023fef_caseD_0:
    return;
  case 2:
    goto switchD_140023fef_caseD_2;
  case 3:
    goto switchD_140023fef_caseD_3;
  }
switchD_140023fef_caseD_1:
  do {
    if (uVar6 == 0) {
      uVar6 = 1;
      uVar4 = uVar4 | 4;
      LOCK();
      uVar5 = *param_1;
      if (uVar5 == 1) {
        *param_1 = uVar4;
      }
      else {
        uVar6 = uVar5;
      }
      UNLOCK();
      if (uVar5 != 1) goto LAB_14002406d;
    }
    local_34 = uVar4;
    iVar3 = WaitOnAddress(param_1,&local_34,4,0xffffffff);
    if (iVar3 != 1) {
      GetLastError();
      uVar4 = *param_1;
      uVar5 = uVar4 & 3;
      uVar6 = uVar4 & 4;
      switch(uVar5) {
      case 0:
        goto switchD_140023fef_caseD_0;
      case 2:
        goto switchD_140023fef_caseD_2;
      case 3:
        goto switchD_140023fef_caseD_3;
      }
      goto switchD_140023fef_caseD_1;
    }
    uVar4 = *param_1;
    uVar5 = uVar4 & 3;
    uVar6 = uVar4 & 4;
    switch(uVar5) {
    case 0:
      goto switchD_140023fef_caseD_0;
    case 2:
switchD_140023fef_caseD_2:
      if (param_2 == '\0') {
                    /* WARNING: Does not return */
        pcVar2 = (code *)invalidInstructionException();
        (*pcVar2)();
      }
switchD_140023fef_caseD_3:
      do {
        LOCK();
        uVar1 = *param_1;
        bVar7 = uVar4 == uVar1;
        if (bVar7) {
          *param_1 = uVar6 + 1;
        }
        else {
          uVar4 = uVar1;
        }
        UNLOCK();
        uVar6 = uVar4;
        if (bVar7) {
          local_2c = uVar5 == 2;
          local_30 = 0;
          (**(code **)(param_4 + 0x20))(param_3,&local_30);
          LOCK();
          uVar4 = *param_1;
          *param_1 = local_30;
          UNLOCK();
          if ((uVar4 & 4) == 0) {
            return;
          }
          WakeByAddressAll(param_1);
          return;
        }
LAB_14002406d:
        uVar4 = uVar6;
        uVar5 = uVar4 & 3;
        uVar6 = uVar4 & 4;
        switch(uVar5) {
        case 0:
          goto switchD_140023fef_caseD_0;
        case 1:
          goto switchD_140023fef_caseD_1;
        case 2:
          goto switchD_140023fef_caseD_2;
        }
      } while( true );
    case 3:
      goto switchD_140023fef_caseD_3;
    }
  } while( true );
}

