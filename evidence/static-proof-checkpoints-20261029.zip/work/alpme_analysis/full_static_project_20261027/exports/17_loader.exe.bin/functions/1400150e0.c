/* address=1400150e0 rva=0x150e0 */

int FUN_1400150e0(longlong param_1)

{
  int iVar1;
  longlong lVar2;
  
  if (DAT_1400d0da8 == -1) {
    iVar1 = FUN_1400167e0(param_1);
  }
  else {
    iVar1 = FUN_140016754(&DAT_1400d0da8,param_1);
  }
  lVar2 = 0;
  if (iVar1 == 0) {
    lVar2 = param_1;
  }
  return (lVar2 != 0) - 1;
}

