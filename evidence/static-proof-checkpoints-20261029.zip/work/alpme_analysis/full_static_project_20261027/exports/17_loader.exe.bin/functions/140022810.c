/* address=140022810 rva=0x22810 */

undefined8 FUN_140022810(longlong param_1,longlong param_2,ulonglong param_3)

{
  undefined8 *puVar1;
  
  if (((param_1 == 0) || (param_2 == 0)) || (0x7fffffff < param_3)) {
    puVar1 = FUN_140019fec();
    *(undefined4 *)puVar1 = 0x16;
    FUN_1400192c4();
  }
  return 0x7fffffff;
}

