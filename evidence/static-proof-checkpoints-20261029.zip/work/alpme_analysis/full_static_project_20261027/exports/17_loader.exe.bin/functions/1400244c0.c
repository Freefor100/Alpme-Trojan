/* address=1400244c0 rva=0x244c0 */

void FUN_1400244c0(undefined8 *param_1)

{
  FUN_140015ca0(param_1);
  return;
}

