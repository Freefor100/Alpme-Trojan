/* address=140014e50 rva=0x14e50 */

void FUN_140014e50(void)

{
  code *pcVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  undefined8 uVar5;
  undefined4 *puVar6;
  undefined7 extraout_var;
  
  FUN_1400170d4(1);
  uVar5 = FUN_140015430();
  FUN_1400170dc((int)uVar5);
  uVar5 = FUN_140015410();
  puVar6 = (undefined4 *)FUN_140015f40();
  *puVar6 = (int)uVar5;
  uVar5 = FUN_1400152b0(1);
  if ((char)uVar5 != '\0') {
    FUN_1400155e0();
    FUN_1400150e0(0x140015630);
    uVar5 = FUN_140015420();
    iVar4 = FUN_14001638c((int)uVar5);
    if (iVar4 == 0) {
      FUN_140015440();
      bVar2 = FUN_1400154b0();
      if ((int)CONCAT71(extraout_var,bVar2) != 0) {
        FUN_140015f50(0x140015410);
      }
      _guard_check_icall();
      _guard_check_icall();
      uVar5 = FUN_140015410();
      FUN_140016280((int)uVar5);
      cVar3 = FUN_140015450();
      if (cVar3 != '\0') {
        thunk_FUN_140016c08();
      }
      FUN_140015410();
      uVar5 = thunk_FUN_140015410();
      if ((int)uVar5 == 0) {
        return;
      }
    }
  }
  FUN_140015570(7);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}

