/* address=1400185c0 rva=0x185c0 */

void FUN_1400185c0(void)

{
  longlong lVar1;
  
  lVar1 = FUN_140017dc0();
  FUN_140018ab8(lVar1,&DAT_1400d17d8);
  return;
}

