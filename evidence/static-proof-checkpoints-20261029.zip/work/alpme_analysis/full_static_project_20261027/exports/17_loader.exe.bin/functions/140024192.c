/* address=140024192 rva=0x24192 */

void FUN_140024192(undefined8 param_1,longlong param_2)

{
  FUN_140017cd0(**(int **)(param_2 + 0x48));
  return;
}

