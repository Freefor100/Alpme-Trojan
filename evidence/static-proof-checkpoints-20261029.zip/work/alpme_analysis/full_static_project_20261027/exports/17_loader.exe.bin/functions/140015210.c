/* address=140015210 rva=0x15210 */

undefined8 FUN_140015210(char param_1)

{
  undefined8 uVar1;
  bool bVar2;
  undefined7 extraout_var;
  undefined8 uVar3;
  
  bVar2 = FUN_140015930();
  uVar1 = DAT_1400d0d98;
  uVar3 = CONCAT71(extraout_var,bVar2);
  if (((int)uVar3 != 0) && (param_1 == '\0')) {
    LOCK();
    DAT_1400d0d98 = 0;
    UNLOCK();
    uVar3 = uVar1;
  }
  return uVar3;
}

