/* address=1400244d6 rva=0x244d6 */

void FUN_1400244d6(void)

{
  PVOID pvVar1;
  
  pvVar1 = FUN_1400173f0();
  if (0 < *(int *)((longlong)pvVar1 + 0x30)) {
    pvVar1 = FUN_1400173f0();
    *(int *)((longlong)pvVar1 + 0x30) = *(int *)((longlong)pvVar1 + 0x30) + -1;
  }
  return;
}

