/* address=1400207e5 rva=0x207e5 */

void FUN_1400207e5(void)

{
  int iVar1;
  int iVar2;
  longlong in_RAX;
  PVOID pvVar3;
  PVOID pvVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong *plVar7;
  undefined8 unaff_RBX;
  undefined8 unaff_RBP;
  int *unaff_RSI;
  byte *pbVar8;
  uint uVar9;
  undefined8 unaff_RDI;
  int *piVar10;
  undefined8 unaff_R12;
  undefined8 unaff_R13;
  ulonglong *unaff_R14;
  undefined8 unaff_R15;
  undefined4 in_stack_0000003c;
  int iStack0000000000000060;
  longlong lStack0000000000000068;
  undefined1 uStack0000000000000070;
  ulonglong uStack0000000000000078;
  undefined8 uStack0000000000000080;
  uint in_stack_00000088;
  uint in_stack_00000098;
  ULONG_PTR in_stack_000000e0;
  longlong *in_stack_000000e8;
  ULONG_PTR in_stack_000000f0;
  ULONG_PTR in_stack_00000100;
  int in_stack_00000108;
  
  *(undefined8 *)(in_RAX + -0x28) = unaff_RBP;
  *(undefined8 *)(in_RAX + -0x30) = unaff_RDI;
  *(undefined8 *)(in_RAX + -0x38) = unaff_R12;
  *(undefined8 *)(in_RAX + 0x20) = unaff_RBX;
  pvVar3 = FUN_1400173f0();
  if (*(longlong *)((longlong)pvVar3 + 0x10) != 0) {
    pvVar3 = FUN_1400173f0();
    pvVar3 = *(PVOID *)((longlong)pvVar3 + 0x10);
    pvVar4 = EncodePointer((PVOID)0x0);
    if ((((pvVar3 != pvVar4) && (*unaff_RSI != -0x1fbcb0b3)) && (*unaff_RSI != -0x1fbcbcae)) &&
       (uVar5 = FUN_14001a860(unaff_RSI,unaff_R15,unaff_R13), (int)uVar5 != 0)) {
      return;
    }
  }
  uStack0000000000000078 = unaff_R14[1];
  _uStack0000000000000070 = in_stack_00000100;
  if (*(int *)(in_stack_00000100 + 0xc) == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_1400172f8();
  }
  FUN_14001a590(&uStack0000000000000080,&uStack0000000000000070,in_stack_00000108,unaff_R14,
                in_stack_00000100);
  uVar9 = in_stack_00000088;
  if (in_stack_00000088 < in_stack_00000098) {
    do {
      piVar10 = (int *)((longlong)*(int *)(*uStack0000000000000080 + 0x10) + (ulonglong)uVar9 * 0x14
                       + uStack0000000000000080[1]);
      iVar1 = *piVar10;
      if ((iVar1 <= in_stack_00000108) && (in_stack_00000108 <= piVar10[1])) {
        iStack0000000000000060 = piVar10[2];
        pbVar8 = (byte *)((unaff_R14[1] - 0x14) +
                         (longlong)piVar10[4] + (ulonglong)(uint)piVar10[3] * 0x14);
        iVar2 = *(int *)(pbVar8 + 4);
        if ((iVar2 != 0) && (lVar6 = FUN_14001a6c0(), lVar6 + iVar2 != 0)) {
          iVar2 = *(int *)(pbVar8 + 4);
          if (iVar2 == 0) {
            lVar6 = 0;
          }
          else {
            lVar6 = FUN_14001a6c0();
            lVar6 = lVar6 + iVar2;
          }
          if (*(char *)(lVar6 + 0x10) != '\0') goto LAB_1400209bd;
        }
        if ((*pbVar8 & 0x40) == 0) {
          plVar7 = FUN_14001a360(in_stack_000000e8,unaff_R14,in_stack_00000100,
                                 &lStack0000000000000068);
          lVar6 = FUN_14001a6c0();
          FUN_14001a460(in_stack_000000e8,in_stack_000000e0,in_stack_000000f0,(ULONG_PTR)plVar7,
                        *(int *)(pbVar8 + 0xc) + lVar6,in_stack_00000100,iVar1,
                        CONCAT44(in_stack_0000003c,iStack0000000000000060),pbVar8,unaff_R14,0);
        }
      }
LAB_1400209bd:
      uVar9 = uVar9 + 1;
    } while (uVar9 < in_stack_00000098);
  }
  return;
}

