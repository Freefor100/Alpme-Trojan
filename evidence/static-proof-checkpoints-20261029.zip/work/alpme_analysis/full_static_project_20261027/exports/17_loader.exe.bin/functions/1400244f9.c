/* address=1400244f9 rva=0x244f9 */

void FUN_1400244f9(undefined8 param_1,longlong param_2)

{
  FUN_140019e64(*(longlong *)(param_2 + 0x40));
  return;
}

