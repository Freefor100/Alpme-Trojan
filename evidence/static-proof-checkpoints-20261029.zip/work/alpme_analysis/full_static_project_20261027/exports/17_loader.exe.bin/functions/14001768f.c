/* address=14001768f rva=0x1768f */

undefined1 FUN_14001768f(void)

{
  return 1;
}

