/* address=14001c998 rva=0x1c998 */

undefined8 FUN_14001c998(uint param_1)

{
  int iVar1;
  ulonglong uVar2;
  undefined8 *puVar3;
  undefined4 *puVar4;
  DWORD nStdHandle;
  
  if ((-1 < (int)param_1) && (param_1 < DAT_1400d17c0)) {
    uVar2 = (ulonglong)(param_1 & 0x3f);
    if (((*(byte *)((&DAT_1400d13c0)[(ulonglong)(longlong)(int)param_1 >> 6] + 0x38 + uVar2 * 0x48)
         & 1) != 0) &&
       (*(longlong *)
         ((&DAT_1400d13c0)[(ulonglong)(longlong)(int)param_1 >> 6] + 0x28 + uVar2 * 0x48) != -1)) {
      iVar1 = FUN_1400170cc();
      if (iVar1 == 1) {
        if (param_1 == 0) {
          nStdHandle = 0xfffffff6;
        }
        else if (param_1 == 1) {
          nStdHandle = 0xfffffff5;
        }
        else {
          if (param_1 != 2) goto LAB_14001ca18;
          nStdHandle = 0xfffffff4;
        }
        SetStdHandle(nStdHandle,(HANDLE)0x0);
      }
LAB_14001ca18:
      *(undefined8 *)
       ((&DAT_1400d13c0)[(ulonglong)(longlong)(int)param_1 >> 6] + 0x28 + uVar2 * 0x48) =
           0xffffffffffffffff;
      return 0;
    }
  }
  puVar3 = FUN_140019fec();
  *(undefined4 *)puVar3 = 9;
  puVar4 = (undefined4 *)FUN_14001a010();
  *puVar4 = 0;
  return 0xffffffff;
}

