/* address=140020b12 rva=0x20b12 */

void FUN_140020b12(void)

{
  undefined1 uVar1;
  int iVar2;
  undefined1 *puVar3;
  longlong lVar4;
  undefined1 *puVar5;
  undefined1 *puVar6;
  undefined1 *puVar7;
  ulonglong uVar8;
  code *unaff_R12;
  undefined1 *unaff_R13;
  ulonglong unaff_R14;
  longlong unaff_R15;
  undefined1 *puVar9;
  undefined1 uStack0000000000000000;
  longlong local_res20;
  undefined1 uStack0000000000000030;
  ulonglong in_stack_00000410;
  
  local_res20 = 0;
  puVar9 = unaff_R13 + unaff_R15 * unaff_R14;
LAB_140020b40:
  uVar8 = (ulonglong)((longlong)puVar9 - (longlong)unaff_R13) / unaff_R14 + 1;
  if (8 < uVar8) {
    lVar4 = (uVar8 >> 1) * unaff_R14;
    puVar3 = unaff_R13 + lVar4;
    iVar2 = (*unaff_R12)(unaff_R13,puVar3);
    if (0 < iVar2) {
      puVar5 = puVar3;
      uVar8 = unaff_R14;
      if (unaff_R13 != puVar3) {
        do {
          uVar1 = puVar5[-lVar4];
          puVar5[-lVar4] = *puVar5;
          *puVar5 = uVar1;
          uVar8 = uVar8 - 1;
          puVar5 = puVar5 + 1;
        } while (uVar8 != 0);
      }
    }
    iVar2 = (*unaff_R12)(unaff_R13,puVar9);
    if ((0 < iVar2) && (unaff_R13 != puVar9)) {
      puVar5 = puVar9;
      uVar8 = unaff_R14;
      do {
        uVar1 = puVar5[(longlong)unaff_R13 - (longlong)puVar9];
        puVar5[(longlong)unaff_R13 - (longlong)puVar9] = *puVar5;
        *puVar5 = uVar1;
        puVar5 = puVar5 + 1;
        uVar8 = uVar8 - 1;
      } while (uVar8 != 0);
    }
    iVar2 = (*unaff_R12)(puVar3);
    if ((0 < iVar2) && (puVar3 != puVar9)) {
      puVar5 = puVar9;
      uVar8 = unaff_R14;
      do {
        uVar1 = puVar5[(longlong)puVar3 - (longlong)puVar9];
        puVar5[(longlong)puVar3 - (longlong)puVar9] = *puVar5;
        *puVar5 = uVar1;
        puVar5 = puVar5 + 1;
        uVar8 = uVar8 - 1;
      } while (uVar8 != 0);
    }
    puVar5 = unaff_R13;
    puVar7 = puVar9;
    do {
      if (puVar5 < puVar3) {
        do {
          puVar5 = puVar5 + unaff_R14;
          if (puVar3 <= puVar5) goto LAB_140020cd0;
          iVar2 = (*unaff_R12)(puVar5);
        } while (iVar2 < 1);
      }
      else {
LAB_140020cd0:
        do {
          puVar5 = puVar5 + unaff_R14;
          if (puVar9 < puVar5) break;
          iVar2 = (*unaff_R12)(puVar5);
        } while (iVar2 < 1);
      }
      do {
        puVar6 = puVar7;
        puVar7 = puVar6 + -unaff_R14;
        if (puVar7 <= puVar3) break;
        iVar2 = (*unaff_R12)(puVar7);
      } while (0 < iVar2);
      if (puVar7 < puVar5) goto LAB_140020d3a;
      if (puVar7 != puVar5) {
        puVar6 = puVar7;
        uVar8 = unaff_R14;
        do {
          uVar1 = puVar6[(longlong)puVar5 - (longlong)puVar7];
          puVar6[(longlong)puVar5 - (longlong)puVar7] = *puVar6;
          *puVar6 = uVar1;
          puVar6 = puVar6 + 1;
          uVar8 = uVar8 - 1;
        } while (uVar8 != 0);
      }
      puVar6 = puVar5;
      if (puVar3 != puVar7) {
        puVar6 = puVar3;
      }
      puVar3 = puVar6;
    } while( true );
  }
  puVar5 = unaff_R13;
  puVar3 = unaff_R13;
  if (unaff_R13 < puVar9) {
    do {
      while( true ) {
        puVar7 = puVar5;
        puVar3 = puVar3 + unaff_R14;
        if (puVar9 < puVar3) break;
        iVar2 = (*unaff_R12)(puVar3,puVar7);
        puVar5 = puVar3;
        if (iVar2 < 1) {
          puVar5 = puVar7;
        }
      }
      if (puVar7 != puVar9) {
        puVar3 = puVar9;
        uVar8 = unaff_R14;
        do {
          uVar1 = puVar3[(longlong)puVar7 - (longlong)puVar9];
          puVar3[(longlong)puVar7 - (longlong)puVar9] = *puVar3;
          *puVar3 = uVar1;
          puVar3 = puVar3 + 1;
          uVar8 = uVar8 - 1;
        } while (uVar8 != 0);
      }
      puVar9 = puVar9 + -unaff_R14;
      puVar5 = unaff_R13;
      puVar3 = unaff_R13;
    } while (unaff_R13 < puVar9);
  }
  goto LAB_140020bc3;
LAB_140020d3a:
  if (puVar3 < puVar6) {
    do {
      puVar6 = puVar6 + -unaff_R14;
      if (puVar6 <= puVar3) goto LAB_140020d57;
      iVar2 = (*unaff_R12)(puVar6);
    } while (iVar2 == 0);
  }
  else {
LAB_140020d57:
    do {
      puVar6 = puVar6 + -unaff_R14;
      if (puVar6 <= unaff_R13) break;
      iVar2 = (*unaff_R12)(puVar6);
    } while (iVar2 == 0);
  }
  if ((longlong)puVar6 - (longlong)unaff_R13 < (longlong)puVar9 - (longlong)puVar5) {
    if (puVar5 < puVar9) {
      *(undefined1 **)(&uStack0000000000000030 + local_res20 * 8) = puVar5;
      *(undefined1 **)((longlong)register0x00000020 + local_res20 * 8 + 0x220) = puVar9;
      local_res20 = local_res20 + 1;
    }
    if (unaff_R13 < puVar6) {
      puVar9 = puVar6;
      goto LAB_140020b40;
    }
  }
  else {
    if (unaff_R13 < puVar6) {
      *(undefined1 **)(&uStack0000000000000030 + local_res20 * 8) = unaff_R13;
      *(undefined1 **)((longlong)register0x00000020 + local_res20 * 8 + 0x220) = puVar6;
      local_res20 = local_res20 + 1;
    }
    if (puVar5 < puVar9) {
      unaff_R13 = puVar5;
      goto LAB_140020b40;
    }
  }
LAB_140020bc3:
  local_res20 = local_res20 + -1;
  if (local_res20 < 0) {
    FUN_14001b4d0(in_stack_00000410 ^ (ulonglong)&uStack0000000000000000);
    return;
  }
  unaff_R13 = *(undefined1 **)(&uStack0000000000000030 + local_res20 * 8);
  puVar9 = *(undefined1 **)((longlong)register0x00000020 + local_res20 * 8 + 0x220);
  goto LAB_140020b40;
}

