/* address=140001a3f rva=0x1a3f */

ulonglong FUN_140001a3f(uint param_1,longlong param_2)

{
  undefined1 (*pauVar1) [32];
  ushort uVar2;
  ushort uVar3;
  code *pcVar4;
  DWORD DVar5;
  uint uVar6;
  longlong lVar7;
  HMODULE lpSource;
  ulonglong uVar8;
  undefined8 uVar9;
  byte bVar10;
  undefined1 *puVar11;
  longlong lVar12;
  undefined1 (*pauVar13) [32];
  ushort *puVar14;
  bool bVar15;
  LPVOID pvVar16;
  byte bVar17;
  byte bVar18;
  undefined1 uStack0000000000000048;
  undefined8 uStack_48;
  
  uStack_48 = 0x140001a55;
  lVar7 = FUN_140014e00();
  lVar7 = -lVar7;
  *(uint *)((longlong)register0x00000020 + lVar7) = param_1;
  pauVar13 = (undefined1 (*) [32])(&uStack0000000000000048 + lVar7);
  lpSource = (HMODULE)0x0;
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x140001a7c;
  FUN_1400237e0(pauVar13,0,0x1000);
  DVar5 = 0x1200;
  puVar11 = (undefined1 *)((longlong)register0x00000020 + lVar7 + -0x40);
  if ((param_1 >> 0x1c & 1) != 0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x140001a94;
    lpSource = GetModuleHandleW(L"NTDLL.DLL");
    puVar11 = (undefined1 *)((longlong)register0x00000020 + lVar7 + -0x40);
    if (lpSource == (HMODULE)0x0) {
      lpSource = (HMODULE)0x0;
    }
    else {
      param_1 = param_1 & 0xefffffff;
      *(uint *)((longlong)register0x00000020 + lVar7) = param_1;
      DVar5 = 0x1a00;
      puVar11 = (undefined1 *)((longlong)register0x00000020 + lVar7 + -0x40);
    }
  }
  *(undefined1 (**) [32])(puVar11 + 0x20) = pauVar13;
  *(undefined8 *)(puVar11 + 0x30) = 0;
  *(undefined4 *)(puVar11 + 0x28) = 0x800;
  *(undefined8 *)(puVar11 + -8) = 0x140001ad8;
  DVar5 = FormatMessageW(DVar5,lpSource,param_1,0,*(LPWSTR *)(puVar11 + 0x20),
                         *(DWORD *)(puVar11 + 0x28),*(va_list **)(puVar11 + 0x30));
  if (DVar5 != 0) {
    if (DVar5 < 0x801) {
      *(undefined8 *)(puVar11 + 0x20) = 1;
      *(undefined8 *)(puVar11 + -8) = 0x140001b09;
      FUN_1400146e3((undefined8 *)(puVar11 + 0x68),(ulonglong)DVar5,0,1,
                    *(ulonglong *)(puVar11 + 0x20));
      pauVar1 = (undefined1 (*) [32])(puVar11 + (ulonglong)DVar5 * 2 + 0x88);
      if (puVar11[0x68] == '\0') {
        *(longlong *)(puVar11 + 0x60) = param_2;
        pvVar16 = *(LPVOID *)(puVar11 + 0x70);
        *(LPVOID *)(puVar11 + 0x48) = pvVar16;
        *(undefined8 *)(puVar11 + 0x50) = *(undefined8 *)(puVar11 + 0x78);
        bVar15 = false;
        lVar7 = 0;
        do {
          *(longlong *)(puVar11 + 0x58) = lVar7;
          if (!bVar15) {
            if (pauVar13 != pauVar1) {
              uVar2 = *(ushort *)*pauVar13;
              pauVar13 = (undefined1 (*) [32])(*pauVar13 + 2);
              goto LAB_140001b9d;
            }
LAB_140001d38:
            lVar12 = *(longlong *)(puVar11 + 0x50);
            if (lVar12 == -1) goto LAB_140001db5;
            goto joined_r0x000140001d4b;
          }
          uVar2 = *(ushort *)(puVar11 + 0x46);
LAB_140001b9d:
          uVar6 = (uint)uVar2;
          if ((uVar6 & 0xf800) == 0xd800) {
            if (uVar6 < 0xdc00) {
              if (pauVar1 == pauVar13) {
                uVar8 = (ulonglong)uVar2 * 0x10000 + 1;
                bVar15 = false;
                pauVar13 = pauVar1;
              }
              else {
                uVar3 = *(ushort *)*pauVar13;
                pauVar13 = (undefined1 (*) [32])(*pauVar13 + 2);
                if (0xfbff < (ushort)(uVar3 + 0x2000)) {
                  uVar8 = ((ulonglong)(uVar6 & 0x3ff) << 0x2a) + 0x1000000000000 |
                          (ulonglong)(uVar3 & 0x3ff) << 0x20;
                  goto LAB_140001c2c;
                }
                uVar8 = (ulonglong)uVar2 * 0x10000 + 1;
                bVar15 = true;
                *(ushort *)(puVar11 + 0x46) = uVar3;
              }
            }
            else {
              uVar8 = (ulonglong)uVar2 * 0x10000 + 1;
LAB_140001c2c:
              bVar15 = false;
            }
          }
          else {
            uVar8 = (ulonglong)uVar6 << 0x20;
            bVar15 = false;
          }
          if ((short)uVar8 == 2) goto LAB_140001d38;
          if ((uVar8 & 1) != 0) goto LAB_140001d9c;
          bVar17 = (byte)(uVar8 >> 0x20);
          if (uVar8 >> 0x27 == 0) {
            lVar12 = 1;
            *(undefined8 *)(puVar11 + -8) = 0x140001c67;
            FUN_14000100e((undefined8 *)(puVar11 + 0x48),1);
            pvVar16 = *(LPVOID *)(puVar11 + 0x48);
            *(byte *)((longlong)pvVar16 + lVar7) = bVar17;
          }
          else if (uVar8 >> 0x2b == 0) {
            lVar12 = 2;
            *(undefined8 *)(puVar11 + -8) = 0x140001c8f;
            FUN_14000100e((undefined8 *)(puVar11 + 0x48),2);
            pvVar16 = *(LPVOID *)(puVar11 + 0x48);
            *(byte *)((longlong)pvVar16 + lVar7) = (byte)(uVar8 >> 0x26) | 0xc0;
            *(byte *)((longlong)pvVar16 + lVar7 + 1) = bVar17 & 0x3f | 0x80;
          }
          else {
            *(undefined8 *)(puVar11 + -8) = 0x140001cfb;
            FUN_14000100e((undefined8 *)(puVar11 + 0x48),4 - (ulonglong)(uVar8 < 0x1000000000000));
            bVar10 = (byte)(uVar8 >> 0x26) & 0x3f | 0x80;
            bVar18 = bVar17 & 0x3f | 0x80;
            pvVar16 = *(LPVOID *)(puVar11 + 0x48);
            bVar17 = (byte)(uVar8 >> 0x2c);
            if (uVar8 < 0x1000000000000) {
              *(byte *)((longlong)pvVar16 + lVar7) = bVar17 | 0xe0;
              *(byte *)((longlong)pvVar16 + lVar7 + 1) = bVar10;
              *(byte *)((longlong)pvVar16 + lVar7 + 2) = bVar18;
              lVar12 = 3;
            }
            else {
              *(byte *)((longlong)pvVar16 + lVar7) = (byte)(uVar8 >> 0x32) | 0xf0;
              *(byte *)((longlong)pvVar16 + lVar7 + 1) = bVar17 & 0x3f | 0x80;
              *(byte *)((longlong)pvVar16 + lVar7 + 2) = bVar10;
              *(byte *)((longlong)pvVar16 + lVar7 + 3) = bVar18;
              lVar12 = 4;
            }
          }
          lVar7 = lVar7 + lVar12;
        } while( true );
      }
    }
                    /* WARNING: Does not return */
    pcVar4 = (code *)invalidInstructionException();
    (*pcVar4)();
  }
  *(undefined8 *)(puVar11 + -8) = 0x140001b55;
  DVar5 = GetLastError();
  *(DWORD *)(puVar11 + 0x48) = DVar5;
  *(code **)(puVar11 + 0x68) = FUN_14000b529;
  *(undefined1 **)(puVar11 + 0x70) = puVar11 + 0x40;
  *(code **)(puVar11 + 0x78) = FUN_14000b529;
  *(undefined1 **)(puVar11 + 0x80) = puVar11 + 0x48;
  uVar9 = *(undefined8 *)(param_2 + 0x10);
  lVar7 = *(longlong *)(param_2 + 0x18);
  puVar14 = (ushort *)0x14007468e;
LAB_140001de1:
  *(undefined8 *)(puVar11 + -8) = 0x140001de6;
  uVar8 = FUN_1400096e5(uVar9,lVar7,(ulonglong)(puVar11 + 0x68),puVar14);
  return uVar8 & 0xffffffff;
joined_r0x000140001d4b:
  if (lVar7 == 0) {
    lVar7 = 0;
LAB_140001d70:
    uVar9 = *(undefined8 *)(*(longlong *)(puVar11 + 0x60) + 0x10);
    pcVar4 = *(code **)(*(longlong *)(*(longlong *)(puVar11 + 0x60) + 0x18) + 0x18);
    *(undefined8 *)(puVar11 + -8) = 0x140001d81;
    uVar6 = (*pcVar4)(uVar9,pvVar16,lVar7);
    *(undefined8 *)(puVar11 + -8) = 0x140001d9a;
    FUN_14000250d(pvVar16,lVar12,1,1);
    return (ulonglong)uVar6;
  }
  uVar8 = (ulonglong)*(byte *)((longlong)pvVar16 + lVar7 + -1);
  if ((0x20 < uVar8) || ((0x100003600U >> (uVar8 & 0x3f) & 1) == 0)) goto LAB_140001d70;
  lVar7 = lVar7 + -1;
  goto joined_r0x000140001d4b;
LAB_140001d9c:
  *(undefined8 *)(puVar11 + -8) = 0x140001db5;
  FUN_14000250d(pvVar16,*(longlong *)(puVar11 + 0x50),1,1);
LAB_140001db5:
  *(code **)(puVar11 + 0x68) = FUN_14000b529;
  *(undefined1 **)(puVar11 + 0x70) = puVar11 + 0x40;
  uVar9 = *(undefined8 *)(*(longlong *)(puVar11 + 0x60) + 0x10);
  lVar7 = *(longlong *)(*(longlong *)(puVar11 + 0x60) + 0x18);
  puVar14 = (ushort *)0x14007400a;
  goto LAB_140001de1;
}

