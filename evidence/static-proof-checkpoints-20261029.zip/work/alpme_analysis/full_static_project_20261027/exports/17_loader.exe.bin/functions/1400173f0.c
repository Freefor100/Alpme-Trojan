/* address=1400173f0 rva=0x173f0 */

PVOID FUN_1400173f0(void)

{
  DWORD dwErrCode;
  BOOL BVar1;
  PVOID lpFlsData;
  
  if (DAT_1400d0334 != 0xffffffff) {
    dwErrCode = GetLastError();
    lpFlsData = FlsGetValue(DAT_1400d0334);
    if (lpFlsData != (PVOID)0xffffffffffffffff) {
      if (lpFlsData != (PVOID)0x0) {
LAB_140017488:
        SetLastError(dwErrCode);
        return lpFlsData;
      }
      BVar1 = FlsSetValue(DAT_1400d0334,(PVOID)0xffffffffffffffff);
      if (BVar1 != 0) {
        lpFlsData = thunk_FUN_14001ab80(1,0x80);
        if (lpFlsData == (LPVOID)0x0) {
          FlsSetValue(DAT_1400d0334,(PVOID)0x0);
          lpFlsData = (LPVOID)0x0;
        }
        else {
          BVar1 = FlsSetValue(DAT_1400d0334,lpFlsData);
          if (BVar1 != 0) {
            *(undefined4 *)((longlong)lpFlsData + 0x78) = 0xfffffffe;
            thunk_FUN_1400191b0((LPVOID)0x0);
            goto LAB_140017488;
          }
          FlsSetValue(DAT_1400d0334,(PVOID)0x0);
        }
        thunk_FUN_1400191b0(lpFlsData);
      }
    }
    SetLastError(dwErrCode);
  }
                    /* WARNING: Subroutine does not return */
  FUN_1400172f8();
}

