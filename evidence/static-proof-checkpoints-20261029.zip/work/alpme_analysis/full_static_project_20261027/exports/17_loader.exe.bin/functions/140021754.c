/* address=140021754 rva=0x21754 */

BOOL FUN_140021754(LPCSTR param_1,LPCSTR param_2)

{
  uint uVar1;
  BOOL BVar2;
  INT_PTR IVar3;
  UINT UVar4;
  LPCWSTR pWVar5;
  UINT UVar6;
  undefined1 local_res18 [8];
  longlong local_98;
  longlong local_90;
  char local_80;
  undefined8 local_78;
  undefined8 local_70;
  LPCWSTR local_68;
  undefined8 local_60;
  undefined8 local_58;
  char local_50;
  undefined8 local_48;
  undefined8 local_40;
  LPCWSTR local_38;
  undefined8 local_30;
  undefined8 local_28;
  char local_20;
  
  local_48 = 0;
  local_40 = 0;
  local_38 = (LPCWSTR)0x0;
  local_30 = 0;
  local_28 = 0;
  local_20 = '\0';
  local_78 = 0;
  local_70 = 0;
  local_68 = (LPCWSTR)0x0;
  local_60 = 0;
  local_58 = 0;
  local_50 = '\0';
  FUN_14001863c(&local_98,(undefined4 *)0x0);
  UVar4 = 0xfde9;
  if (*(int *)(local_90 + 0xc) == 0xfde9) {
    if (local_80 != '\0') {
      *(uint *)(local_98 + 0x3a8) = *(uint *)(local_98 + 0x3a8) & 0xfffffffd;
    }
    UVar6 = 0xfde9;
  }
  else {
    IVar3 = FUN_14001770c();
    if ((int)IVar3 == 0) {
      if (local_80 != '\0') {
        *(uint *)(local_98 + 0x3a8) = *(uint *)(local_98 + 0x3a8) & 0xfffffffd;
      }
      UVar6 = 1;
    }
    else {
      if (local_80 != '\0') {
        *(uint *)(local_98 + 0x3a8) = *(uint *)(local_98 + 0x3a8) & 0xfffffffd;
      }
      UVar6 = 0;
    }
  }
  uVar1 = FUN_14001b734(param_1,(longlong)&local_48,local_res18,UVar6);
  pWVar5 = (LPCWSTR)0x0;
  if (uVar1 == 0) {
    FUN_14001863c(&local_98,(undefined4 *)0x0);
    if (*(int *)(local_90 + 0xc) == 0xfde9) {
      if (local_80 != '\0') {
        *(uint *)(local_98 + 0x3a8) = *(uint *)(local_98 + 0x3a8) & 0xfffffffd;
      }
    }
    else {
      IVar3 = FUN_14001770c();
      if ((int)IVar3 == 0) {
        if (local_80 != '\0') {
          *(uint *)(local_98 + 0x3a8) = *(uint *)(local_98 + 0x3a8) & 0xfffffffd;
        }
        UVar4 = 1;
      }
      else {
        if (local_80 != '\0') {
          *(uint *)(local_98 + 0x3a8) = *(uint *)(local_98 + 0x3a8) & 0xfffffffd;
        }
        UVar4 = 0;
      }
    }
    uVar1 = FUN_14001b734(param_2,(longlong)&local_78,local_res18,UVar4);
    pWVar5 = local_68;
    if (uVar1 == 0) {
      BVar2 = SetEnvironmentVariableW(local_38,local_68);
      goto LAB_1400218b7;
    }
  }
  BVar2 = 0;
LAB_1400218b7:
  if (local_50 != '\0') {
    FUN_1400191b0(pWVar5);
  }
  if (local_20 != '\0') {
    FUN_1400191b0(local_38);
  }
  return BVar2;
}

