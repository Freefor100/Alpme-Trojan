/* address=14001a720 rva=0x1a720 */

void FUN_14001a720(undefined8 param_1)

{
  PVOID pvVar1;
  
  pvVar1 = FUN_1400173f0();
  *(undefined8 *)((longlong)pvVar1 + 0x68) = param_1;
  return;
}

