/* address=140017200 rva=0x17200 */

ulonglong FUN_140017200(longlong param_1)

{
  bool bVar1;
  undefined7 extraout_var;
  ulonglong uVar2;
  longlong lVar3;
  
  bVar1 = FUN_140017180((short *)&IMAGE_DOS_HEADER_140000000);
  uVar2 = CONCAT71(extraout_var,bVar1);
  if ((int)uVar2 != 0) {
    lVar3 = FUN_1400171b0(0x140000000,param_1 - 0x140000000);
    uVar2 = 0;
    if (lVar3 != 0) {
      uVar2 = (ulonglong)(~*(uint *)(lVar3 + 0x24) >> 0x1f);
    }
  }
  return uVar2;
}

