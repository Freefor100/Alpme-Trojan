/* address=14001fbf0 rva=0x1fbf0 */

void FUN_14001fbf0(int *param_1,longlong *param_2,ULONG_PTR param_3,ulonglong *param_4,uint *param_5
                  ,int param_6,undefined8 param_7,byte param_8)

{
  FUN_14001ffd0(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  return;
}

