/* address=14001a6e0 rva=0x1a6e0 */

void FUN_14001a6e0(undefined8 param_1)

{
  PVOID pvVar1;
  
  pvVar1 = FUN_1400173f0();
  *(undefined8 *)((longlong)pvVar1 + 0x60) = param_1;
  return;
}

