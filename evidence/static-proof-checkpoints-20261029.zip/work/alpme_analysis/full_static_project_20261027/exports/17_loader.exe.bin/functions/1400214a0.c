/* address=1400214a0 rva=0x214a0 */

LPVOID FUN_1400214a0(LPVOID param_1,ulonglong param_2)

{
  bool bVar1;
  int iVar2;
  LPVOID pvVar3;
  undefined8 *puVar4;
  undefined7 extraout_var;
  
  if (param_1 == (LPVOID)0x0) {
    pvVar3 = FUN_14001ac00(param_2);
  }
  else {
    if (param_2 == 0) {
      FUN_1400191b0(param_1);
    }
    else {
      if (param_2 < 0xffffffffffffffe1) {
        do {
          pvVar3 = HeapReAlloc(DAT_1400d13b0,0,param_1,param_2);
          if (pvVar3 != (LPVOID)0x0) {
            return pvVar3;
          }
          iVar2 = FUN_140017120();
        } while ((iVar2 != 0) &&
                (bVar1 = FUN_140019720(param_2), (int)CONCAT71(extraout_var,bVar1) != 0));
      }
      puVar4 = FUN_140019fec();
      *(undefined4 *)puVar4 = 0xc;
    }
    pvVar3 = (LPVOID)0x0;
  }
  return pvVar3;
}

