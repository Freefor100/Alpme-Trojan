/* address=140015460 rva=0x15460 */

void _guard_check_icall(void)

{
  return;
}

