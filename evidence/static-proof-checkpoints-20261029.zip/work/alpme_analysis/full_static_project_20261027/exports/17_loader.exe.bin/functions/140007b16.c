/* address=140007b16 rva=0x7b16 */

ulonglong FUN_140007b16(longlong *param_1,longlong param_2)

{
  ulonglong uVar1;
  undefined4 uVar2;
  bool bVar3;
  char cVar4;
  uint uVar5;
  uint uVar6;
  ulonglong uVar7;
  undefined8 unaff_RBX;
  ulonglong uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined8 uVar11;
  longlong lVar12;
  code *pcVar13;
  longlong lVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  longlong lVar17;
  byte bVar18;
  undefined2 uStack_84;
  undefined2 local_82;
  undefined1 uStack_80;
  char cStack_7f;
  char cStack_7e;
  char cStack_7d;
  char cStack_7c;
  char cStack_7b;
  undefined2 local_7a;
  undefined2 local_78;
  undefined2 uStack_76;
  undefined4 uStack_74;
  undefined2 uStack_70;
  char local_6c;
  char local_6b;
  undefined8 local_68;
  longlong local_60;
  code *local_58;
  longlong local_50;
  longlong local_48;
  
  lVar12 = *param_1;
  uVar1 = param_1[2];
  uVar11 = *(undefined8 *)(param_2 + 0x10);
  lVar14 = *(longlong *)(param_2 + 0x18);
  pcVar13 = *(code **)(lVar14 + 0x20);
  cVar4 = (*pcVar13)(uVar11,0x22);
  uVar8 = CONCAT71((int7)((ulonglong)unaff_RBX >> 8),1);
  if (cVar4 == '\0') {
    local_60 = lVar12;
    local_50 = lVar14;
    if (uVar1 == 0) {
      uVar16 = 0;
      uVar15 = 0;
    }
    else {
      uVar15 = 0;
      uVar16 = 0;
      uVar9 = uVar1;
      local_68 = uVar11;
      local_58 = pcVar13;
      do {
        uVar10 = 0;
        lVar14 = lVar12 + uVar9;
        while (((cVar4 = *(char *)(lVar12 + uVar10), 0xa0 < (byte)(cVar4 + 0x81U) && (cVar4 != '\"')
                ) && (cVar4 != '\\'))) {
          uVar10 = uVar10 + 1;
          if (uVar10 == uVar9) {
            uVar16 = uVar16 + uVar9;
            goto LAB_140007e22;
          }
        }
        bVar18 = *(byte *)(lVar12 + uVar10);
        uVar6 = (uint)bVar18;
        if ((char)bVar18 < '\0') {
          lVar17 = lVar12 + uVar10;
          uVar5 = *(byte *)(lVar17 + 1) & 0x3f;
          if (bVar18 < 0xe0) {
            lVar12 = lVar17 + 2;
            uVar6 = (uVar6 & 0x1f) << 6 | uVar5;
          }
          else {
            uVar5 = *(byte *)(lVar17 + 2) & 0x3f | uVar5 << 6;
            if (bVar18 < 0xf0) {
              lVar12 = lVar17 + 3;
              uVar6 = (uVar6 & 0x1f) << 0xc;
            }
            else {
              lVar12 = lVar17 + 4;
              uVar6 = (uVar6 & 7) << 0x12;
              uVar5 = uVar5 << 6 | *(byte *)(lVar17 + 3) & 0x3f;
            }
            uVar6 = uVar5 | uVar6;
          }
        }
        else {
          lVar12 = lVar12 + uVar10 + 1;
        }
        if (uVar6 < 0xd) {
          if (uVar6 == 0) {
            local_78 = 0x305c;
          }
          else if (uVar6 == 9) {
            local_78 = 0x745c;
          }
          else {
            if (uVar6 != 10) goto LAB_140007c0f;
            local_78 = 0x6e5c;
          }
LAB_140007f53:
          uStack_76 = 0;
          uStack_74 = 0;
          uStack_70 = 0;
          uVar9 = 0;
          bVar3 = true;
          uVar8 = CONCAT71((int7)(uVar8 >> 8),2);
        }
        else {
          if (uVar6 < 0x27) {
            if (uVar6 == 0xd) {
              local_78 = 0x725c;
            }
            else {
              if (uVar6 != 0x22) goto LAB_140007c0f;
              local_78 = 0x225c;
            }
            goto LAB_140007f53;
          }
          if (uVar6 == 0x27) {
LAB_140007bfd:
            local_78 = (undefined2)uVar6;
            uStack_76 = (undefined2)(uVar6 >> 0x10);
            uVar9 = 0x80;
            uVar8 = CONCAT71((int7)(uVar8 >> 8),0x81);
            bVar3 = false;
          }
          else {
            if (uVar6 == 0x5c) {
              local_78 = 0x5c5c;
              goto LAB_140007f53;
            }
LAB_140007c0f:
            if ((uVar6 & 0xfffffffe) == 0xff9e || uVar6 - 0x20 < 0x5f) goto LAB_140007bfd;
            if (((0x1f < uVar6 && 0x20 < uVar6 - 0x7f) &&
                (0xfffd < uVar6 - 0x100000 && (0xfffd < uVar6 - 0xf0000 && 0x18ff < uVar6 - 0xe000))
                ) && ((4 < uVar6 - 9 && (uVar6 != 0x20)))) {
              if (uVar6 < 0x85) {
LAB_140007d35:
                uVar9 = FUN_140007969(uVar6);
                uVar8 = uVar1;
                if ((char)uVar9 != '\0') goto LAB_140007bfd;
              }
              else {
                uVar5 = uVar6 >> 8;
                if (uVar5 < 0x20) {
                  if (uVar5 == 0) {
                    bVar18 = (&DAT_140074baa)[uVar6 & 0xff];
                  }
                  else {
                    if (uVar5 != 0x16) goto LAB_140007df9;
                    bVar18 = uVar6 == 0x1680;
                  }
LAB_140007df1:
                  if ((bVar18 & 1) != 0) goto LAB_140007c86;
                }
                else {
                  if (uVar5 == 0x20) {
                    bVar18 = (byte)(&DAT_140074baa)[uVar6 & 0xff] >> 1;
                    goto LAB_140007df1;
                  }
                  if (uVar5 == 0x30) {
                    bVar18 = uVar6 == 0x3000;
                    goto LAB_140007df1;
                  }
                }
LAB_140007df9:
                if (uVar6 < 0x300) {
                  if (uVar6 < 0xad) goto LAB_140007d35;
                }
                else {
                  uVar9 = FUN_140012924(uVar6);
                  uVar8 = uVar1;
                  if ((char)uVar9 != '\0') goto LAB_140007c86;
                }
                uVar9 = FUN_1400095a1(uVar6);
                uVar8 = uVar1;
                if ((char)uVar9 == '\0') {
                  uVar9 = FUN_1400129f6(uVar6);
                  if ((char)uVar9 == '\0') goto LAB_140007d35;
                }
              }
            }
LAB_140007c86:
            uVar5 = 0x1f;
            if ((uVar6 | 1) != 0) {
              for (; (uVar6 | 1) >> uVar5 == 0; uVar5 = uVar5 - 1) {
              }
            }
            uVar7 = (ulonglong)((uVar5 ^ 0x1c) >> 2);
            uVar9 = uVar7 - 2;
            uStack_80 = 0;
            local_82 = 0;
            cStack_7f = "Jsmwle7NECa2qV1tacgTWoKmkzrPa-PuWY11qqIJ-ZlY7icOa2WkVVdOXeerZDQiETw0_3c7n6Rrf0ggRiUeqyaSDkii1xvmy thing through picture three my here is folarge play into if think different kind clYwqEo4NocjoUEOrf01k1zjgcFallback encoder does support subregion layout configurationline then will down only only us put all use afteroverride-expressions should have least forward declaredvariables, value declarations, non-static data members incompatible with C++20AXaa2AlwyFnIOFNCi1J5mneHbGE-wcbeen for so must make one right with word use been hand over eqkOMUsnrZvbL6atVpeUrjy7iyqqgT-Fi2VBVrE3r_frpGW-8FNAmCPWGotJusgw7P0123456789abcdefS_imju6t_nojNc8x"
                        [(ulonglong)(uVar6 >> 0x14) + 0x25d];
            cStack_7e = "Jsmwle7NECa2qV1tacgTWoKmkzrPa-PuWY11qqIJ-ZlY7icOa2WkVVdOXeerZDQiETw0_3c7n6Rrf0ggRiUeqyaSDkii1xvmy thing through picture three my here is folarge play into if think different kind clYwqEo4NocjoUEOrf01k1zjgcFallback encoder does support subregion layout configurationline then will down only only us put all use afteroverride-expressions should have least forward declaredvariables, value declarations, non-static data members incompatible with C++20AXaa2AlwyFnIOFNCi1J5mneHbGE-wcbeen for so must make one right with word use been hand over eqkOMUsnrZvbL6atVpeUrjy7iyqqgT-Fi2VBVrE3r_frpGW-8FNAmCPWGotJusgw7P0123456789abcdefS_imju6t_nojNc8x"
                        [(ulonglong)(uVar6 >> 0x10 & 0xf) + 0x25d];
            cStack_7d = "Jsmwle7NECa2qV1tacgTWoKmkzrPa-PuWY11qqIJ-ZlY7icOa2WkVVdOXeerZDQiETw0_3c7n6Rrf0ggRiUeqyaSDkii1xvmy thing through picture three my here is folarge play into if think different kind clYwqEo4NocjoUEOrf01k1zjgcFallback encoder does support subregion layout configurationline then will down only only us put all use afteroverride-expressions should have least forward declaredvariables, value declarations, non-static data members incompatible with C++20AXaa2AlwyFnIOFNCi1J5mneHbGE-wcbeen for so must make one right with word use been hand over eqkOMUsnrZvbL6atVpeUrjy7iyqqgT-Fi2VBVrE3r_frpGW-8FNAmCPWGotJusgw7P0123456789abcdefS_imju6t_nojNc8x"
                        [(ulonglong)(uVar6 >> 0xc & 0xf) + 0x25d];
            cStack_7c = "Jsmwle7NECa2qV1tacgTWoKmkzrPa-PuWY11qqIJ-ZlY7icOa2WkVVdOXeerZDQiETw0_3c7n6Rrf0ggRiUeqyaSDkii1xvmy thing through picture three my here is folarge play into if think different kind clYwqEo4NocjoUEOrf01k1zjgcFallback encoder does support subregion layout configurationline then will down only only us put all use afteroverride-expressions should have least forward declaredvariables, value declarations, non-static data members incompatible with C++20AXaa2AlwyFnIOFNCi1J5mneHbGE-wcbeen for so must make one right with word use been hand over eqkOMUsnrZvbL6atVpeUrjy7iyqqgT-Fi2VBVrE3r_frpGW-8FNAmCPWGotJusgw7P0123456789abcdefS_imju6t_nojNc8x"
                        [(ulonglong)(uVar6 >> 8 & 0xf) + 0x25d];
            cStack_7b = "Jsmwle7NECa2qV1tacgTWoKmkzrPa-PuWY11qqIJ-ZlY7icOa2WkVVdOXeerZDQiETw0_3c7n6Rrf0ggRiUeqyaSDkii1xvmy thing through picture three my here is folarge play into if think different kind clYwqEo4NocjoUEOrf01k1zjgcFallback encoder does support subregion layout configurationline then will down only only us put all use afteroverride-expressions should have least forward declaredvariables, value declarations, non-static data members incompatible with C++20AXaa2AlwyFnIOFNCi1J5mneHbGE-wcbeen for so must make one right with word use been hand over eqkOMUsnrZvbL6atVpeUrjy7iyqqgT-Fi2VBVrE3r_frpGW-8FNAmCPWGotJusgw7P0123456789abcdefS_imju6t_nojNc8x"
                        [(ulonglong)(uVar6 >> 4 & 0xf) + 0x25d];
            local_7a = CONCAT11(0x7d,"Jsmwle7NECa2qV1tacgTWoKmkzrPa-PuWY11qqIJ-ZlY7icOa2WkVVdOXeerZDQiETw0_3c7n6Rrf0ggRiUeqyaSDkii1xvmy thing through picture three my here is folarge play into if think different kind clYwqEo4NocjoUEOrf01k1zjgcFallback encoder does support subregion layout configurationline then will down only only us put all use afteroverride-expressions should have least forward declaredvariables, value declarations, non-static data members incompatible with C++20AXaa2AlwyFnIOFNCi1J5mneHbGE-wcbeen for so must make one right with word use been hand over eqkOMUsnrZvbL6atVpeUrjy7iyqqgT-Fi2VBVrE3r_frpGW-8FNAmCPWGotJusgw7P0123456789abcdefS_imju6t_nojNc8x"
                                     [(ulonglong)(uVar6 & 0xf) + 0x25d]);
            *(undefined2 *)((longlong)&uStack_84 + uVar7) = 0x755c;
            *(undefined1 *)((longlong)&local_82 + uVar7) = 0x7b;
            uVar2 = CONCAT13(cStack_7f,CONCAT12(uStack_80,local_82));
            local_78 = local_82;
            uStack_76 = (undefined2)((uint)uVar2 >> 0x10);
            uStack_74 = (undefined4)
                        (CONCAT17(cStack_7b,
                                  CONCAT16(cStack_7c,CONCAT15(cStack_7d,CONCAT14(cStack_7e,uVar2))))
                        >> 0x20);
            uStack_70 = local_7a;
            uVar8 = CONCAT71((int7)(uVar8 >> 8),10);
            bVar3 = true;
          }
        }
        uVar10 = uVar10 + uVar16;
        local_6c = (char)uVar8;
        local_6b = (char)uVar9;
        if ((char)(local_6c - local_6b) != '\x01') {
          local_48 = lVar14;
          if (((uVar10 < uVar15) || (uVar1 < uVar10)) ||
             ((uVar1 != uVar15 &&
              (((uVar15 != 0 && (*(char *)(local_60 + uVar15) < -0x40)) ||
               ((uVar1 != uVar10 && (*(char *)(local_60 + uVar10) < -0x40))))))))
          goto LAB_140007e6d;
          pcVar13 = *(code **)(local_50 + 0x18);
          cVar4 = (*pcVar13)(local_68,uVar15 + local_60,uVar10 - uVar15);
          if (cVar4 == '\0') {
            if (bVar3) {
              cVar4 = (*pcVar13)(local_68,(longlong)&local_78 + (uVar9 & 0xff),
                                 (uVar8 & 0xff) - (uVar9 & 0xff));
            }
            else {
              cVar4 = (*local_58)(local_68,CONCAT22(uStack_76,local_78));
            }
            if (cVar4 == '\0') {
              lVar14 = 1;
              if ((0x7f < uVar6) && (lVar14 = 2, 0x7ff < uVar6)) {
                lVar14 = 4 - (ulonglong)(uVar6 < 0x10000);
              }
              uVar15 = lVar14 + uVar10;
              lVar14 = local_48;
              goto LAB_140008036;
            }
          }
          uVar8 = CONCAT71((int7)(uVar8 >> 8),1);
          goto LAB_140007ea4;
        }
LAB_140008036:
        lVar17 = 1;
        if ((0x7f < uVar6) && (lVar17 = 2, 0x7ff < uVar6)) {
          lVar17 = 4 - (ulonglong)(uVar6 < 0x10000);
        }
        uVar16 = lVar17 + uVar10;
        uVar9 = lVar14 - lVar12;
      } while (uVar9 != 0);
LAB_140007e22:
      uVar8 = CONCAT71((int7)(uVar8 >> 8),1);
      if ((uVar16 < uVar15) || (uVar1 < uVar16)) {
LAB_140007e6d:
                    /* WARNING: Does not return */
        pcVar13 = (code *)invalidInstructionException();
        (*pcVar13)();
      }
      uVar11 = local_68;
      pcVar13 = local_58;
      if (uVar15 == uVar1) {
        uVar15 = uVar1;
      }
      else {
        if ((uVar15 != 0) && (*(char *)(local_60 + uVar15) < -0x40)) goto LAB_140007e6d;
        if (uVar1 == uVar16) {
          uVar16 = uVar1;
        }
        else if (*(char *)(local_60 + uVar16) < -0x40) goto LAB_140007e6d;
      }
    }
    cVar4 = (**(code **)(local_50 + 0x18))(uVar11,local_60 + uVar15,uVar16 - uVar15);
    if (cVar4 == '\0') {
      uVar6 = (*pcVar13)(uVar11,0x22);
      uVar8 = (ulonglong)uVar6;
    }
  }
LAB_140007ea4:
  return uVar8 & 0xffffffff;
}

