/* address=14000100e rva=0x100e */

void FUN_14000100e(undefined8 *param_1,ulonglong param_2)

{
  code *pcVar1;
  longlong lVar2;
  
  if ((ulonglong)(param_1[1] - param_1[2]) < param_2) {
    lVar2 = FUN_14000965c(param_1,param_1[2],param_2,(LPVOID)0x1,1);
    if (lVar2 != -1) {
                    /* WARNING: Does not return */
      pcVar1 = (code *)invalidInstructionException();
      (*pcVar1)();
    }
  }
  return;
}

