/* address=1400224ae rva=0x224ae */

void FUN_1400224ae(undefined8 param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  char *pcVar3;
  longlong *unaff_RBX;
  undefined8 *unaff_RDI;
  
  lVar1 = -1;
  do {
    lVar2 = lVar1;
    lVar1 = lVar2 + 1;
  } while (*(char *)(param_3 + 1 + lVar2) != '\0');
  pcVar3 = thunk_FUN_14001ac00(lVar2 + 2U);
  if (pcVar3 != (char *)0x0) {
    FUN_140017540(pcVar3,lVar2 + 2U,*unaff_RBX);
    *unaff_RDI = pcVar3;
    *(undefined1 *)(unaff_RDI + 1) = 1;
  }
  thunk_FUN_1400191b0((LPVOID)0x0);
  return;
}

