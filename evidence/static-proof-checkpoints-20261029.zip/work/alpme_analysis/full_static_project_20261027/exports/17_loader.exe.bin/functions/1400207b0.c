/* address=1400207b0 rva=0x207b0 */

void FUN_1400207b0(int *param_1,longlong *param_2,ULONG_PTR param_3,longlong param_4,
                  longlong param_5,int param_6,undefined4 param_7,undefined8 param_8)

{
  int iVar1;
  int iVar2;
  int iVar3;
  PVOID pvVar4;
  PVOID pvVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong *plVar8;
  byte *pbVar9;
  uint uVar10;
  int *piVar11;
  undefined4 in_stack_ffffffffffffff64;
  longlong lStack_70;
  longlong lStack_68;
  undefined8 uStack_60;
  longlong *plStack_58;
  uint uStack_50;
  uint uStack_40;
  
  if (*param_1 != -0x7ffffffd) {
    pvVar4 = FUN_1400173f0();
    if (*(longlong *)((longlong)pvVar4 + 0x10) != 0) {
      pvVar4 = FUN_1400173f0();
      pvVar4 = *(PVOID *)((longlong)pvVar4 + 0x10);
      pvVar5 = EncodePointer((PVOID)0x0);
      if ((((pvVar4 != pvVar5) && (*param_1 != -0x1fbcb0b3)) && (*param_1 != -0x1fbcbcae)) &&
         (uVar6 = FUN_14001a860(param_1,param_2,param_3), (int)uVar6 != 0)) {
        return;
      }
    }
    uStack_60 = *(undefined8 *)(param_4 + 8);
    lStack_68 = param_5;
    if (*(int *)(param_5 + 0xc) == 0) {
                    /* WARNING: Subroutine does not return */
      FUN_1400172f8();
    }
    FUN_14001a590(&plStack_58,&lStack_68,param_6,(ulonglong *)param_4,param_5);
    uVar10 = uStack_50;
    if (uStack_50 < uStack_40) {
      do {
        piVar11 = (int *)((longlong)*(int *)(*plStack_58 + 0x10) + (ulonglong)uVar10 * 0x14 +
                         plStack_58[1]);
        iVar1 = *piVar11;
        if ((iVar1 <= param_6) && (param_6 <= piVar11[1])) {
          iVar2 = piVar11[2];
          pbVar9 = (byte *)(*(longlong *)(param_4 + 8) + -0x14 +
                           (longlong)piVar11[4] + (ulonglong)(uint)piVar11[3] * 0x14);
          iVar3 = *(int *)(pbVar9 + 4);
          if ((iVar3 != 0) && (lVar7 = FUN_14001a6c0(), lVar7 + iVar3 != 0)) {
            iVar3 = *(int *)(pbVar9 + 4);
            if (iVar3 == 0) {
              lVar7 = 0;
            }
            else {
              lVar7 = FUN_14001a6c0();
              lVar7 = lVar7 + iVar3;
            }
            if (*(char *)(lVar7 + 0x10) != '\0') goto LAB_1400209bd;
          }
          if ((*pbVar9 & 0x40) == 0) {
            plVar8 = FUN_14001a360(param_2,(ulonglong *)param_4,param_5,&lStack_70);
            lVar7 = FUN_14001a6c0();
            FUN_14001a460(param_2,(ULONG_PTR)param_1,param_3,(ULONG_PTR)plVar8,
                          *(int *)(pbVar9 + 0xc) + lVar7,param_5,iVar1,
                          CONCAT44(in_stack_ffffffffffffff64,iVar2),pbVar9,(undefined8 *)param_4,0);
          }
        }
LAB_1400209bd:
        uVar10 = uVar10 + 1;
      } while (uVar10 < uStack_40);
    }
  }
  return;
}

