/* address=1400228d0 rva=0x228d0 */

void FUN_1400228d0(longlong *param_1,ushort *param_2,uint param_3,byte *param_4,int param_5,
                  byte *param_6,int param_7,UINT param_8)

{
  int *piVar1;
  byte bVar2;
  uint uVar3;
  byte *pbVar4;
  ushort *puVar5;
  BOOL BVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  BYTE *pBVar10;
  longlong lVar11;
  undefined4 *puVar12;
  ulonglong uVar13;
  PCNZWCH pWVar14;
  undefined1 *puVar15;
  undefined1 *puVar16;
  undefined1 *puVar17;
  undefined4 *puVar18;
  undefined1 auStackY_d8 [32];
  uint local_88 [2];
  byte *local_80;
  ushort *local_78;
  _cpinfo local_70;
  ulonglong local_58;
  
  puVar17 = auStackY_d8;
  local_58 = DAT_1400d02c0 ^ (ulonglong)local_88;
  local_80 = param_6;
  local_88[0] = param_3;
  local_78 = param_2;
  if (param_5 < 1) {
    if (param_5 < -1) goto LAB_140022c3b;
  }
  else {
    param_5 = FUN_140022130((char *)param_4,(longlong)param_5);
  }
  puVar17 = auStackY_d8;
  if (param_7 < 1) {
    if (param_7 < -1) goto LAB_140022c3b;
  }
  else {
    param_7 = FUN_140022130((char *)param_6,(longlong)param_7);
  }
  if (param_8 == 0) {
    param_8 = *(UINT *)(*param_1 + 0xc);
  }
  if ((param_5 == 0) || (param_7 == 0)) {
    local_70.LeadByte[10] = '\0';
    local_70.LeadByte[0xb] = '\0';
    local_70._18_2_ = 0;
    local_70.MaxCharSize = 0;
    local_70.DefaultChar[0] = '\0';
    local_70.DefaultChar[1] = '\0';
    local_70.LeadByte[0] = '\0';
    local_70.LeadByte[1] = '\0';
    local_70.LeadByte[2] = '\0';
    local_70.LeadByte[3] = '\0';
    local_70.LeadByte[4] = '\0';
    local_70.LeadByte[5] = '\0';
    local_70.LeadByte[6] = '\0';
    local_70.LeadByte[7] = '\0';
    local_70.LeadByte[8] = '\0';
    local_70.LeadByte[9] = '\0';
    if (param_5 == param_7) {
LAB_140022c58:
      puVar17 = auStackY_d8;
      goto LAB_140022c3b;
    }
    if (param_7 < 2) {
      if (param_5 < 2) {
        BVar6 = GetCPInfo(param_8,&local_70);
        puVar17 = auStackY_d8;
        if (BVar6 == 0) goto LAB_140022c3b;
        if (param_5 < 1) {
          if (param_7 < 1) goto LAB_140022a2c;
          if (1 < local_70.MaxCharSize) {
            pBVar10 = local_70.LeadByte;
            bVar2 = local_70.LeadByte[0];
            while ((bVar2 != 0 && (pBVar10[1] != 0))) {
              if ((*pBVar10 <= *param_6) && (*param_6 <= pBVar10[1])) goto LAB_140022c58;
              pBVar10 = pBVar10 + 2;
              bVar2 = *pBVar10;
            }
          }
          goto LAB_140022a22;
        }
        if (1 < local_70.MaxCharSize) {
          pBVar10 = local_70.LeadByte;
          bVar2 = local_70.LeadByte[0];
          while ((bVar2 != 0 && (pBVar10[1] != 0))) {
            if ((*pBVar10 <= *param_4) && (*param_4 <= pBVar10[1])) goto LAB_140022c58;
            pBVar10 = pBVar10 + 2;
            bVar2 = *pBVar10;
          }
        }
      }
      puVar17 = auStackY_d8;
    }
    else {
LAB_140022a22:
      puVar17 = auStackY_d8;
    }
    goto LAB_140022c3b;
  }
LAB_140022a2c:
  uVar7 = FUN_14001ae24(param_8,9,(LPCSTR)param_4,param_5,(LPWSTR)0x0,0);
  puVar17 = auStackY_d8;
  if ((uVar7 == 0) ||
     (uVar13 = (longlong)(int)uVar7 * 2 + 0x10,
     uVar13 = -(ulonglong)((ulonglong)((longlong)(int)uVar7 * 2) < uVar13) & uVar13,
     puVar17 = auStackY_d8, uVar13 == 0)) goto LAB_140022c3b;
  if (uVar13 < 0x401) {
    lVar11 = FUN_140014e00();
    lVar11 = -lVar11;
    puVar17 = auStackY_d8 + lVar11;
    puVar15 = auStackY_d8 + lVar11;
    puVar12 = (undefined4 *)((longlong)local_88 + lVar11);
    if (puVar12 == (undefined4 *)0x0) goto LAB_140022c3b;
    *puVar12 = 0xcccc;
LAB_140022ac4:
    pWVar14 = (PCNZWCH)(puVar12 + 4);
    puVar17 = puVar15;
  }
  else {
    puVar12 = FUN_14001ac00(uVar13);
    puVar17 = auStackY_d8;
    puVar15 = auStackY_d8;
    pWVar14 = (PCNZWCH)0x0;
    if (puVar12 != (undefined4 *)0x0) {
      *puVar12 = 0xdddd;
      goto LAB_140022ac4;
    }
  }
  if (pWVar14 == (PCNZWCH)0x0) goto LAB_140022c3b;
  *(uint *)(puVar17 + 0x28) = uVar7;
  *(PCNZWCH *)(puVar17 + 0x20) = pWVar14;
  *(undefined8 *)(puVar17 + -8) = 0x140022aee;
  iVar8 = FUN_14001ae24(param_8,1,(LPCSTR)param_4,param_5,*(LPWSTR *)(puVar17 + 0x20),
                        *(int *)(puVar17 + 0x28));
  if (iVar8 == 0) {
LAB_140022c28:
    iVar8 = *(int *)(pWVar14 + -8);
  }
  else {
    *(undefined4 *)(puVar17 + 0x28) = 0;
    *(undefined8 *)(puVar17 + 0x20) = 0;
    *(undefined8 *)(puVar17 + -8) = 0x140022b14;
    iVar8 = FUN_14001ae24(param_8,9,(LPCSTR)param_6,param_7,*(LPWSTR *)(puVar17 + 0x20),
                          *(int *)(puVar17 + 0x28));
    if ((iVar8 == 0) ||
       (uVar13 = (longlong)iVar8 * 2 + 0x10,
       uVar13 = -(ulonglong)((ulonglong)((longlong)iVar8 * 2) < uVar13) & uVar13, uVar13 == 0))
    goto LAB_140022c28;
    if (uVar13 < 0x401) {
      *(undefined8 *)(puVar17 + -8) = 0x140022b5d;
      lVar11 = FUN_140014e00();
      lVar11 = -lVar11;
      puVar16 = puVar17 + lVar11;
      puVar12 = (undefined4 *)(puVar17 + lVar11 + 0x50);
      puVar17 = puVar17 + lVar11;
      if (puVar12 == (undefined4 *)0x0) goto LAB_140022c28;
      *puVar12 = 0xcccc;
      puVar17 = puVar16;
LAB_140022b89:
      puVar18 = puVar12 + 4;
    }
    else {
      *(undefined8 *)(puVar17 + -8) = 0x140022b7b;
      puVar12 = FUN_14001ac00(uVar13);
      puVar18 = (undefined4 *)0x0;
      if (puVar12 != (undefined4 *)0x0) {
        *puVar12 = 0xdddd;
        goto LAB_140022b89;
      }
    }
    pbVar4 = local_80;
    if (puVar18 == (undefined4 *)0x0) goto LAB_140022c28;
    piVar1 = puVar18 + -4;
    *(int *)(puVar17 + 0x28) = iVar8;
    *(undefined4 **)(puVar17 + 0x20) = puVar18;
    *(undefined8 *)(puVar17 + -8) = 0x140022bb8;
    iVar9 = FUN_14001ae24(param_8,1,(LPCSTR)pbVar4,param_7,*(LPWSTR *)(puVar17 + 0x20),
                          *(int *)(puVar17 + 0x28));
    uVar3 = local_88[0];
    if (iVar9 != 0) {
      *(undefined8 *)(puVar17 + 0x40) = 0;
      *(undefined8 *)(puVar17 + 0x38) = 0;
      *(undefined8 *)(puVar17 + 0x30) = 0;
      puVar5 = local_78;
      *(int *)(puVar17 + 0x28) = iVar8;
      *(undefined4 **)(puVar17 + 0x20) = puVar18;
      *(undefined8 *)(puVar17 + -8) = 0x140022c03;
      FUN_140017758(puVar5,uVar3,pWVar14,uVar7,*(PCNZWCH *)(puVar17 + 0x20),*(int *)(puVar17 + 0x28)
                    ,*(undefined8 *)(puVar17 + 0x30),*(undefined8 *)(puVar17 + 0x38),
                    *(undefined8 *)(puVar17 + 0x40));
      if (*piVar1 == 0xdddd) {
        *(undefined8 *)(puVar17 + -8) = 0x140022c17;
        FUN_1400191b0(piVar1);
      }
      if (*(int *)(pWVar14 + -8) == 0xdddd) {
        *(undefined8 *)(puVar17 + -8) = 0x140022c24;
        FUN_1400191b0(pWVar14 + -8);
      }
      goto LAB_140022c3b;
    }
    if (*piVar1 == 0xdddd) {
      *(undefined8 *)(puVar17 + -8) = 0x140022bd0;
      FUN_1400191b0(piVar1);
    }
    iVar8 = *(int *)(pWVar14 + -8);
  }
  if (iVar8 == 0xdddd) {
    *(undefined8 *)(puVar17 + -8) = 0x140022c39;
    FUN_1400191b0(pWVar14 + -8);
  }
LAB_140022c3b:
  uVar13 = local_58 ^ (ulonglong)local_88;
  *(undefined8 *)(puVar17 + -8) = 0x140022c47;
  FUN_14001b4d0(uVar13);
  return;
}

