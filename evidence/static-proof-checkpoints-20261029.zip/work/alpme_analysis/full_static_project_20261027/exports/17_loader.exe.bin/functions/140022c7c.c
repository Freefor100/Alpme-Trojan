/* address=140022c7c rva=0x22c7c */

bool FUN_140022c7c(void)

{
  if (DAT_1400d0cc0 == (HANDLE)0xfffffffffffffffe) {
    DAT_1400d0cc0 = CreateFileW(L"CONOUT$",0x40000000,3,(LPSECURITY_ATTRIBUTES)0x0,3,0,(HANDLE)0x0);
  }
  return DAT_1400d0cc0 != (HANDLE)0xffffffffffffffff;
}

