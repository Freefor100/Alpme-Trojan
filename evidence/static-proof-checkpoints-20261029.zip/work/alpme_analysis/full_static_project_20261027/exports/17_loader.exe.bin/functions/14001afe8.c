/* address=14001afe8 rva=0x1afe8 */

void FUN_14001afe8(LPVOID param_1)

{
  int *piVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  
  if ((((*(undefined ***)((longlong)param_1 + 0xf8) != (undefined **)0x0) &&
       (*(undefined ***)((longlong)param_1 + 0xf8) != &PTR_DAT_1400d0b00)) &&
      (*(int **)((longlong)param_1 + 0xe0) != (int *)0x0)) &&
     (**(int **)((longlong)param_1 + 0xe0) == 0)) {
    piVar1 = *(int **)((longlong)param_1 + 0xf0);
    if ((piVar1 != (int *)0x0) && (*piVar1 == 0)) {
      FUN_1400191b0(piVar1);
      FUN_14001a8b0(*(longlong *)((longlong)param_1 + 0xf8));
    }
    piVar1 = *(int **)((longlong)param_1 + 0xe8);
    if ((piVar1 != (int *)0x0) && (*piVar1 == 0)) {
      FUN_1400191b0(piVar1);
      FUN_14001a9bc(*(undefined8 **)((longlong)param_1 + 0xf8));
    }
    FUN_1400191b0(*(LPVOID *)((longlong)param_1 + 0xe0));
    FUN_1400191b0(*(LPVOID *)((longlong)param_1 + 0xf8));
  }
  if ((*(int **)((longlong)param_1 + 0x100) != (int *)0x0) &&
     (**(int **)((longlong)param_1 + 0x100) == 0)) {
    FUN_1400191b0((LPVOID)(*(longlong *)((longlong)param_1 + 0x108) + -0xfe));
    FUN_1400191b0((LPVOID)(*(longlong *)((longlong)param_1 + 0x110) + -0x80));
    FUN_1400191b0((LPVOID)(*(longlong *)((longlong)param_1 + 0x118) + -0x80));
    FUN_1400191b0(*(LPVOID *)((longlong)param_1 + 0x100));
  }
  FUN_14001b1b0(*(undefined ***)((longlong)param_1 + 0x120));
  puVar3 = (undefined8 *)((longlong)param_1 + 0x128);
  lVar2 = 6;
  puVar4 = (undefined8 *)((longlong)param_1 + 0x38);
  do {
    if ((((undefined *)puVar4[-2] != &DAT_1400d09e8) &&
        (piVar1 = (int *)*puVar4, piVar1 != (int *)0x0)) && (*piVar1 == 0)) {
      FUN_1400191b0(piVar1);
      FUN_1400191b0((LPVOID)*puVar3);
    }
    if (((puVar4[-3] != 0) && (piVar1 = (int *)puVar4[-1], piVar1 != (int *)0x0)) && (*piVar1 == 0))
    {
      FUN_1400191b0(piVar1);
    }
    puVar3 = puVar3 + 1;
    puVar4 = puVar4 + 4;
    lVar2 = lVar2 + -1;
  } while (lVar2 != 0);
  FUN_1400191b0(param_1);
  return;
}

