/* address=1400170cc rva=0x170cc */

undefined4 FUN_1400170cc(void)

{
  return DAT_1400d0fd8;
}

