/* address=140017ddc rva=0x17ddc */

void FUN_140017ddc(void)

{
  PVOID pvVar1;
  undefined8 *puVar2;
  
  if (DAT_1400d0338 == 0xffffffff) {
    pvVar1 = (PVOID)0x0;
  }
  else {
    pvVar1 = FlsGetValue(DAT_1400d0338);
  }
  if (pvVar1 == (PVOID)0xffffffffffffffff) {
LAB_140017e18:
                    /* WARNING: Subroutine does not return */
    FUN_1400172f8();
  }
  if (pvVar1 == (PVOID)0x0) {
    puVar2 = FUN_14001815c();
    if (puVar2 == (undefined8 *)0x0) goto LAB_140017e18;
  }
  return;
}

