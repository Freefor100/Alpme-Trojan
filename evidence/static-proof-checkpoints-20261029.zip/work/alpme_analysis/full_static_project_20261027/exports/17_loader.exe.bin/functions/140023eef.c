/* address=140023eef rva=0x23eef */

void FUN_140023eef(ulonglong *param_1,LPVOID param_2,longlong param_3,ulonglong param_4,
                  LPVOID param_5,ulonglong param_6)

{
  undefined1 auVar1 [16];
  undefined1 auVar2 [16];
  ulonglong dwBytes;
  LPVOID *ppvVar3;
  HANDLE hHeap;
  ulonglong uVar4;
  LPVOID pvVar5;
  LPVOID local_30;
  LPVOID local_28;
  
  auVar1._8_8_ = 0;
  auVar1._0_8_ = param_6;
  auVar2._8_8_ = 0;
  auVar2._0_8_ = param_4;
  dwBytes = SUB168(auVar1 * auVar2,0);
  if (0x8000000000000000U - (longlong)param_5 < dwBytes || SUB168(auVar1 * auVar2,8) != 0) {
    param_1[1] = 0;
    uVar4 = 1;
  }
  else {
    ppvVar3 = &local_30;
    if (param_3 == 0) {
      pvVar5 = (LPVOID)0x0;
    }
    else {
      pvVar5 = (LPVOID)(param_3 * param_6);
      local_30 = param_5;
      ppvVar3 = &local_28;
    }
    *ppvVar3 = pvVar5;
    if ((local_30 == (LPVOID)0x0) || (local_28 == (LPVOID)0x0)) {
      if (dwBytes == 0) {
        pvVar5 = param_5;
      }
      else {
        pvVar5 = FUN_1400128ed(0,dwBytes);
      }
    }
    else {
      hHeap = GetProcessHeap();
      pvVar5 = HeapReAlloc(hHeap,0,param_2,dwBytes);
    }
    if (pvVar5 != (LPVOID)0x0) {
      param_5 = pvVar5;
    }
    uVar4 = (ulonglong)(pvVar5 == (LPVOID)0x0);
    param_1[1] = (ulonglong)param_5;
  }
  param_1[2] = dwBytes;
  *param_1 = uVar4;
  return;
}

