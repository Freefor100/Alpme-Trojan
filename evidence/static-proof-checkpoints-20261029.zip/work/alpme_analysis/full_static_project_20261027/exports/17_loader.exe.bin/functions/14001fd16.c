/* address=14001fd16 rva=0x1fd16 */

undefined8 FUN_14001fd16(void)

{
  return 1;
}

