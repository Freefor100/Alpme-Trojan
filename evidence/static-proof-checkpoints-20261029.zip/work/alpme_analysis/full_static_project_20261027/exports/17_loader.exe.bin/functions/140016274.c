/* address=140016274 rva=0x16274 */

undefined4 FUN_140016274(void)

{
  undefined4 uVar1;
  
  uVar1 = DAT_1400d0e78;
  LOCK();
  DAT_1400d0e78 = 1;
  UNLOCK();
  return uVar1;
}

