/* address=1400243c6 rva=0x243c6 */

void FUN_1400243c6(undefined8 param_1,longlong param_2)

{
  FUN_14001cc1c(**(uint **)(param_2 + 0x48));
  return;
}

