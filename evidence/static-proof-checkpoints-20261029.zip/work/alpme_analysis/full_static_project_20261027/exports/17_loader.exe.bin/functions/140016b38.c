/* address=140016b38 rva=0x16b38 */

void FUN_140016b38(void)

{
  undefined8 uVar1;
  longlong lVar2;
  
  if (DAT_1400d0fd0 != 0) {
    return;
  }
  lVar2 = DAT_1400d0fb8;
  if (DAT_1400d0fb8 == 0) {
    if ((DAT_1400d0fc0 == 0) ||
       ((uVar1 = FUN_140016c08(), (int)uVar1 != 0 && (uVar1 = FUN_140016e0c(), (int)uVar1 != 0)))) {
      lVar2 = 0;
    }
    else {
      lVar2 = DAT_1400d0fb8;
    }
  }
  DAT_1400d0fd0 = lVar2;
  return;
}

