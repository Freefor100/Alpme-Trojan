/* address=140016c7c rva=0x16c7c */

void FUN_140016c7c(undefined8 *param_1)

{
  if ((undefined8 *)*param_1 != DAT_1400d0fd0) {
    FUN_140016cb4((undefined8 *)*param_1);
  }
  return;
}

