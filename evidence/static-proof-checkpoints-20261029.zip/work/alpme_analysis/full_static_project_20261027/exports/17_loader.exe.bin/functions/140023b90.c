/* address=140023b90 rva=0x23b90 */

ulonglong FUN_140023b90(ulonglong *param_1,longlong param_2,ulonglong param_3)

{
  byte bVar1;
  ulonglong uVar2;
  longlong lVar3;
  bool bVar4;
  
  lVar3 = param_2 - (longlong)param_1;
  if (param_3 != 0) {
    do {
      if (((ulonglong)param_1 & 7) == 0) {
        while ((((int)lVar3 + (int)param_1 & 0xfffU) < 0xff9 &&
               (uVar2 = *param_1, uVar2 == *(ulonglong *)(lVar3 + (longlong)param_1)))) {
          param_1 = param_1 + 1;
          bVar4 = param_3 < 8;
          param_3 = param_3 - 8;
          if (bVar4 || param_3 == 0) {
            return 0;
          }
          if ((~uVar2 & uVar2 + 0xfefefefefefefeff & 0x8080808080808080) != 0) {
            return 0;
          }
        }
      }
      bVar1 = (byte)*param_1;
      if (bVar1 != *(byte *)(lVar3 + (longlong)param_1)) {
        return -(ulonglong)(bVar1 < *(byte *)(lVar3 + (longlong)param_1)) | 1;
      }
      param_1 = (ulonglong *)((longlong)param_1 + 1);
      param_3 = param_3 - 1;
    } while ((param_3 != 0) && (bVar1 != 0));
  }
  return 0;
}

