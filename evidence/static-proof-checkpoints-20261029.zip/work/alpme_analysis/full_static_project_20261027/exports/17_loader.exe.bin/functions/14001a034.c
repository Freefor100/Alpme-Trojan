/* address=14001a034 rva=0x1a034 */

void FUN_14001a034(uint param_1)

{
  uint uVar1;
  uint *puVar2;
  
  puVar2 = (uint *)FUN_14001a010();
  *puVar2 = param_1;
  uVar1 = FUN_14001a05c(param_1);
  puVar2 = (uint *)FUN_140019fec();
  *puVar2 = uVar1;
  return;
}

