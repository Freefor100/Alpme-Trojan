/* address=140024286 rva=0x24286 */

void FUN_140024286(void)

{
  FUN_140017cd0(0);
  return;
}

