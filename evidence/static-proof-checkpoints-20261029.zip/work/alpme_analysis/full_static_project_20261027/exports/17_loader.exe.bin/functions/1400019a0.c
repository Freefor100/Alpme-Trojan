/* address=1400019a0 rva=0x19a0 */

void tls_callback_1400019a0(undefined8 param_1,int param_2)

{
  if ((param_2 == 1) || (param_2 == 2)) {
    FUN_140012ed0();
    return;
  }
  return;
}

