/* address=14001715c rva=0x1715c */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */

void FUN_14001715c(void)

{
  longlong lVar1;
  
  lVar1 = FUN_140017dc0();
  if (*(code **)(lVar1 + 0x18) != (code *)0x0) {
    (**(code **)(lVar1 + 0x18))();
  }
                    /* WARNING: Subroutine does not return */
  FUN_1400172f8();
}

