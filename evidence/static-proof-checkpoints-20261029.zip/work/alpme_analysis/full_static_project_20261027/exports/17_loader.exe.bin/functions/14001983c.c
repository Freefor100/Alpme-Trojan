/* address=14001983c rva=0x1983c */

void FUN_14001983c(void)

{
  undefined1 local_res8 [8];
  int local_res10 [2];
  int local_res18 [4];
  
  local_res10[0] = 3;
  local_res18[0] = 3;
  FUN_140019ac8(local_res8,local_res18,local_res8,local_res10);
  return;
}

