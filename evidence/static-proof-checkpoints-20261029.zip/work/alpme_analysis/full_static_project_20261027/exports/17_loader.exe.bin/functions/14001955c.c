/* address=14001955c rva=0x1955c */

longlong FUN_14001955c(longlong *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  DWORD local_res8 [2];
  
  if (*param_1 == 0) {
    local_res8[0] = GetLastError();
    if ((char)param_1[2] == '\0') {
      param_1[1] = 0;
      lVar2 = 0;
      *(undefined1 *)(param_1 + 2) = 1;
    }
    else {
      lVar2 = param_1[1];
    }
    puVar1 = FUN_140017eb0(local_res8,lVar2);
    *param_1 = (longlong)puVar1;
    SetLastError(local_res8[0]);
    if (puVar1 == (undefined8 *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_1400172f8();
    }
  }
  return *param_1;
}

