/* address=14000b800 rva=0xb800 */

/* WARNING: Removing unreachable block (ram,0x00014000b857) */

void FUN_14000b800(void)

{
  longlong lVar1;
  code *pcVar2;
  int *piVar3;
  
  lVar1 = *(longlong *)((longlong)ThreadLocalStoragePointer + (ulonglong)_tls_index * 8);
  piVar3 = &DAT_140075694;
  switch(*(longlong *)(lVar1 + 0x48) != 0) {
  case false:
    switch(DAT_1400d0d80 != (*(ulonglong *)(lVar1 + 0x118) ^ 0x1502b128258863ce)) {
    case false:
                    /* WARNING: Does not return */
      pcVar2 = (code *)invalidInstructionException();
      (*pcVar2)();
    case true:
      DAT_1400d0d80 = DAT_1400d0d80 + 1;
      LOCK();
      UNLOCK();
      *(ulonglong *)(lVar1 + 0x48) = DAT_1400d0d80;
    }
  }
  thunk_FUN_14000254d();
  if (DAT_1400d0284 != ((int)DAT_1400cfd30 + 0x207491ad) * 0x38812a67 + -0x1d91b6c5) {
    piVar3 = &DAT_14007569c;
  }
                    /* WARNING: Could not recover jumptable at 0x00014000b8f2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(&DAT_14000b8a2 + *piVar3))();
  return;
}

