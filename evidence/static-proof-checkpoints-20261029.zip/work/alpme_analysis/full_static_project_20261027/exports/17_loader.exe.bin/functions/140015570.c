/* address=140015570 rva=0x15570 */

void FUN_140015570(undefined4 param_1)

{
  code *pcVar1;
  
  pcVar1 = (code *)swi(0x29);
  (*pcVar1)(param_1);
  return;
}

