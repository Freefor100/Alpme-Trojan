/* address=14000b971 rva=0xb971 */

bool FUN_14000b971(HANDLE param_1,FILE_INFO_BY_HANDLE_CLASS param_2,LPVOID param_3)

{
  BOOL BVar1;
  
  BVar1 = SetFileInformationByHandle(param_1,param_2,param_3,8);
  if (BVar1 == 0) {
    GetLastError();
  }
  return BVar1 == 0;
}

