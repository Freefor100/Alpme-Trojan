/* address=14001b258 rva=0x1b258 */

undefined ** FUN_14001b258(undefined8 *param_1,undefined **param_2)

{
  undefined **ppuVar1;
  
  if ((param_2 == (undefined **)0x0) || (param_1 == (undefined8 *)0x0)) {
    param_2 = (undefined **)0x0;
  }
  else {
    ppuVar1 = (undefined **)*param_1;
    if (ppuVar1 != param_2) {
      *param_1 = param_2;
      FUN_14001aeb4((longlong)param_2);
      if (((ppuVar1 != (undefined **)0x0) &&
          (FUN_14001af40((longlong)ppuVar1), *(int *)(ppuVar1 + 2) == 0)) &&
         (ppuVar1 != &PTR_DAT_1400d0880)) {
        FUN_14001afe8(ppuVar1);
      }
    }
  }
  return param_2;
}

