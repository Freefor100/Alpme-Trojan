/* address=14001c838 rva=0x1c838 */

LPVOID FUN_14001c838(longlong *param_1)

{
  char *pcVar1;
  longlong *plVar2;
  longlong lVar3;
  LPVOID pvVar4;
  longlong lVar5;
  LPVOID pvVar6;
  undefined8 uVar7;
  longlong lVar8;
  longlong lVar9;
  
  if (param_1 == (longlong *)0x0) {
    pvVar4 = (LPVOID)0x0;
  }
  else {
    lVar8 = 0;
    lVar5 = *param_1;
    plVar2 = param_1;
    while (lVar5 != 0) {
      lVar8 = lVar8 + 1;
      plVar2 = plVar2 + 1;
      lVar5 = *plVar2;
    }
    pvVar4 = FUN_14001ab80(lVar8 + 1,8);
    if (pvVar4 == (LPVOID)0x0) {
LAB_14001c917:
                    /* WARNING: Subroutine does not return */
      FUN_1400172f8();
    }
    lVar5 = *param_1;
    if (lVar5 != 0) {
      lVar8 = (longlong)pvVar4 - (longlong)param_1;
      do {
        lVar3 = -1;
        do {
          lVar9 = lVar3;
          lVar3 = lVar9 + 1;
        } while (*(char *)(lVar5 + lVar9 + 1) != '\0');
        pvVar6 = FUN_14001ab80(lVar9 + 2,1);
        *(LPVOID *)(lVar8 + (longlong)param_1) = pvVar6;
        FUN_1400191b0((LPVOID)0x0);
        pcVar1 = *(char **)(lVar8 + (longlong)param_1);
        if (pcVar1 == (char *)0x0) goto LAB_14001c917;
        uVar7 = FUN_140017540(pcVar1,lVar9 + 2,*param_1);
        if ((int)uVar7 != 0) {
                    /* WARNING: Subroutine does not return */
          FUN_1400192e4();
        }
        param_1 = param_1 + 1;
        lVar5 = *param_1;
      } while (lVar5 != 0);
    }
    FUN_1400191b0((LPVOID)0x0);
  }
  return pvVar4;
}

