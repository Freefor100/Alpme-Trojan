/* address=140019e70 rva=0x19e70 */

undefined8 FUN_140019e70(void)

{
  longlong lVar1;
  longlong lVar2;
  undefined4 *puVar3;
  longlong lVar4;
  undefined *puVar5;
  
  lVar1 = 0;
  lVar4 = 3;
  if (DAT_1400d1820 == 0) {
    DAT_1400d1820 = 0x200;
  }
  else if (DAT_1400d1820 < 3) {
    DAT_1400d1820 = 3;
  }
  DAT_1400d1828 = FUN_14001ab80((longlong)DAT_1400d1820,8);
  FUN_1400191b0((LPVOID)0x0);
  if (DAT_1400d1828 == (LPVOID)0x0) {
    DAT_1400d1820 = 3;
    DAT_1400d1828 = FUN_14001ab80(3,8);
    FUN_1400191b0((LPVOID)0x0);
    if (DAT_1400d1828 == (LPVOID)0x0) {
      return 0xffffffff;
    }
  }
  lVar2 = 0;
  puVar3 = &DAT_1400d0a08;
  puVar5 = &DAT_1400d09f0;
  do {
    InitializeCriticalSectionEx((LPCRITICAL_SECTION)(puVar5 + 0x30),4000,0);
    *(undefined **)(lVar1 + (longlong)DAT_1400d1828) = puVar5;
    if (*(longlong *)((&DAT_1400d13c0)[lVar2 >> 6] + 0x28 + (ulonglong)((uint)lVar2 & 0x3f) * 0x48)
        + 2U < 3) {
      *puVar3 = 0xfffffffe;
    }
    lVar2 = lVar2 + 1;
    puVar5 = puVar5 + 0x58;
    lVar1 = lVar1 + 8;
    puVar3 = puVar3 + 0x16;
    lVar4 = lVar4 + -1;
  } while (lVar4 != 0);
  return 0;
}

