/* address=140015d40 rva=0x15d40 */

uint FUN_140015d40(void)

{
  uint uVar1;
  undefined4 uVar2;
  uint3 extraout_var;
  
  uVar1 = FUN_1400175c0();
  if ((char)uVar1 != '\0') {
    uVar2 = FUN_140017350();
    if ((char)uVar2 != '\0') {
      return CONCAT31((int3)((uint)uVar2 >> 8),1);
    }
    FUN_140017650();
    uVar1 = (uint)extraout_var << 8;
  }
  return uVar1 & 0xffffff00;
}

