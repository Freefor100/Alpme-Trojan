/* address=140019fec rva=0x19fec */

undefined8 * FUN_140019fec(void)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  puVar1 = FUN_140017e20();
  puVar2 = puVar1 + 4;
  if (puVar1 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)&DAT_1400d0af8;
  }
  return puVar2;
}

