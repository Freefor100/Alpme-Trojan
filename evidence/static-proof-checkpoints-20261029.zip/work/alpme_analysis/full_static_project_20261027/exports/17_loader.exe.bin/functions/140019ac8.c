/* address=140019ac8 rva=0x19ac8 */

ulonglong FUN_140019ac8(undefined8 param_1,int *param_2,undefined8 param_3,int *param_4)

{
  byte bVar1;
  ulonglong uVar2;
  
  FUN_140017cb4(*param_2);
  bVar1 = (byte)DAT_1400d02c0 & 0x3f;
  uVar2 = DAT_1400d1808 ^ DAT_1400d02c0;
  FUN_140017cd0(*param_4);
  return uVar2 >> bVar1 | uVar2 << 0x40 - bVar1;
}

