/* address=14001df70 rva=0x1df70 */

void FUN_14001df70(longlong *param_1,ushort *param_2,uint param_3,char *param_4,int param_5,
                  undefined8 param_6,int param_7,UINT param_8,int param_9)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  ulonglong uVar4;
  longlong lVar5;
  undefined4 *puVar6;
  ulonglong uVar7;
  undefined8 uVar8;
  LPCWSTR pWVar9;
  undefined1 *puVar10;
  undefined1 *puVar11;
  undefined1 *puVar12;
  undefined4 *puVar13;
  undefined1 auStackY_88 [32];
  undefined4 local_38 [2];
  ulonglong local_30;
  
  local_30 = DAT_1400d02c0 ^ (ulonglong)local_38;
  iVar3 = param_5;
  if (0 < param_5) {
    iVar1 = FUN_140022130(param_4,(longlong)param_5);
    iVar3 = iVar1 + 1;
    if (param_5 <= iVar1) {
      iVar3 = iVar1;
    }
  }
  if (param_8 == 0) {
    param_8 = *(UINT *)(*param_1 + 0xc);
  }
  uVar2 = FUN_14001ae24(param_8,(-(uint)(param_9 != 0) & 8) + 1,param_4,iVar3,(LPWSTR)0x0,0);
  puVar12 = auStackY_88;
  if (uVar2 == 0) goto LAB_14001e27b;
  uVar4 = (longlong)(int)uVar2 * 2 + 0x10;
  uVar4 = -(ulonglong)((ulonglong)((longlong)(int)uVar2 * 2) < uVar4) & uVar4;
  if (uVar4 == 0) {
    pWVar9 = (LPCWSTR)0x0;
    puVar12 = auStackY_88;
LAB_14001e261:
    if (pWVar9 == (LPCWSTR)0x0) goto LAB_14001e27b;
  }
  else {
    if (uVar4 < 0x401) {
      uVar7 = uVar4 + 0xf;
      if (uVar7 <= uVar4) {
        uVar7 = 0xffffffffffffff0;
      }
      uVar7 = uVar7 & 0xfffffffffffffff0;
      FUN_140014e00();
      lVar5 = -uVar7;
      puVar10 = auStackY_88 + lVar5;
      puVar13 = (undefined4 *)((longlong)local_38 + lVar5);
      pWVar9 = (LPCWSTR)0x0;
      puVar12 = auStackY_88 + lVar5;
      if (puVar13 == (undefined4 *)0x0) goto LAB_14001e261;
      *puVar13 = 0xcccc;
LAB_14001e07c:
      pWVar9 = (LPCWSTR)(puVar13 + 4);
      puVar11 = puVar10;
    }
    else {
      puVar13 = FUN_14001ac00(uVar4);
      puVar11 = auStackY_88;
      puVar10 = auStackY_88;
      pWVar9 = (LPCWSTR)0x0;
      if (puVar13 != (undefined4 *)0x0) {
        *puVar13 = 0xdddd;
        goto LAB_14001e07c;
      }
    }
    puVar12 = puVar11;
    if (pWVar9 == (LPCWSTR)0x0) goto LAB_14001e261;
    *(uint *)(puVar11 + 0x28) = uVar2;
    *(LPCWSTR *)(puVar11 + 0x20) = pWVar9;
    *(undefined8 *)(puVar11 + -8) = 0x14001e0a6;
    iVar3 = FUN_14001ae24(param_8,1,param_4,iVar3,*(LPWSTR *)(puVar11 + 0x20),
                          *(int *)(puVar11 + 0x28));
    if (iVar3 == 0) goto LAB_14001e261;
    *(undefined8 *)(puVar11 + 0x40) = 0;
    *(undefined8 *)(puVar11 + 0x38) = 0;
    *(undefined8 *)(puVar11 + 0x30) = 0;
    *(undefined4 *)(puVar11 + 0x28) = 0;
    *(undefined8 *)(puVar11 + 0x20) = 0;
    *(undefined8 *)(puVar11 + -8) = 0x14001e0d9;
    iVar3 = FUN_140017850(param_2,param_3,pWVar9,uVar2,*(LPWSTR *)(puVar11 + 0x20),
                          *(int *)(puVar11 + 0x28),*(undefined8 *)(puVar11 + 0x30),
                          *(undefined8 *)(puVar11 + 0x38),*(undefined8 *)(puVar11 + 0x40));
    uVar8 = 0;
    if (iVar3 == 0) goto LAB_14001e261;
    if ((param_3 & 0x400) == 0) {
      uVar4 = (longlong)iVar3 * 2 + 0x10;
      uVar4 = -(ulonglong)((ulonglong)((longlong)iVar3 * 2) < uVar4) & uVar4;
      if (uVar4 == 0) {
        puVar13 = (undefined4 *)0x0;
LAB_14001e244:
        if (puVar13 != (undefined4 *)0x0) {
LAB_14001e249:
          if (puVar13[-4] == 0xdddd) {
            *(undefined8 *)(puVar12 + -8) = 0x14001e25a;
            FUN_1400191b0(puVar13 + -4);
          }
        }
      }
      else {
        if (uVar4 < 0x401) {
          *(undefined8 *)(puVar11 + -8) = 0x14001e17c;
          lVar5 = FUN_140014e00();
          lVar5 = -lVar5;
          puVar12 = puVar11 + lVar5;
          puVar6 = (undefined4 *)(puVar11 + lVar5 + 0x50);
          if (puVar6 == (undefined4 *)0x0) goto LAB_14001e268;
          *puVar6 = 0xcccc;
          puVar11 = puVar11 + lVar5;
LAB_14001e1aa:
          puVar13 = puVar6 + 4;
          puVar12 = puVar11;
        }
        else {
          *(undefined8 *)(puVar11 + -8) = 0x14001e19a;
          puVar6 = FUN_14001ac00(uVar4);
          uVar8 = 0;
          puVar13 = (undefined4 *)0x0;
          if (puVar6 != (undefined4 *)0x0) {
            *puVar6 = 0xdddd;
            goto LAB_14001e1aa;
          }
        }
        if (puVar13 != (undefined4 *)0x0) {
          *(undefined8 *)(puVar12 + 0x40) = uVar8;
          *(undefined8 *)(puVar12 + 0x38) = uVar8;
          *(undefined8 *)(puVar12 + 0x30) = uVar8;
          *(int *)(puVar12 + 0x28) = iVar3;
          *(undefined4 **)(puVar12 + 0x20) = puVar13;
          *(undefined8 *)(puVar12 + -8) = 0x14001e1e0;
          iVar1 = FUN_140017850(param_2,param_3,pWVar9,uVar2,*(LPWSTR *)(puVar12 + 0x20),
                                *(int *)(puVar12 + 0x28),*(undefined8 *)(puVar12 + 0x30),
                                *(undefined8 *)(puVar12 + 0x38),*(undefined8 *)(puVar12 + 0x40));
          if (iVar1 == 0) goto LAB_14001e244;
          *(undefined8 *)(puVar12 + 0x38) = 0;
          *(undefined8 *)(puVar12 + 0x30) = 0;
          if (param_7 == 0) {
            *(undefined4 *)(puVar12 + 0x28) = 0;
            *(undefined8 *)(puVar12 + 0x20) = 0;
            *(undefined8 *)(puVar12 + -8) = 0x14001e20e;
            iVar3 = FUN_14001c2e8(param_8,0,puVar13,iVar3);
            if (iVar3 == 0) goto LAB_14001e244;
          }
          else {
            *(int *)(puVar12 + 0x28) = param_7;
            *(undefined8 *)(puVar12 + 0x20) = param_6;
            *(undefined8 *)(puVar12 + -8) = 0x14001e228;
            iVar3 = FUN_14001c2e8(param_8,0,puVar13,iVar3);
            if (iVar3 == 0) goto LAB_14001e249;
          }
          if (puVar13[-4] == 0xdddd) {
            *(undefined8 *)(puVar12 + -8) = 0x14001e23f;
            FUN_1400191b0(puVar13 + -4);
          }
        }
      }
    }
    else if (param_7 != 0) {
      if (iVar3 <= param_7) {
        *(undefined8 *)(puVar11 + 0x40) = 0;
        *(undefined8 *)(puVar11 + 0x38) = 0;
        *(undefined8 *)(puVar11 + 0x30) = 0;
        *(int *)(puVar11 + 0x28) = param_7;
        *(undefined8 *)(puVar11 + 0x20) = param_6;
        *(undefined8 *)(puVar11 + -8) = 0x14001e131;
        iVar3 = FUN_140017850(param_2,param_3,pWVar9,uVar2,*(LPWSTR *)(puVar11 + 0x20),
                              *(int *)(puVar11 + 0x28),*(undefined8 *)(puVar11 + 0x30),
                              *(undefined8 *)(puVar11 + 0x38),*(undefined8 *)(puVar11 + 0x40));
        if (iVar3 != 0) goto LAB_14001e268;
      }
      goto LAB_14001e261;
    }
  }
LAB_14001e268:
  if (*(int *)(pWVar9 + -8) == 0xdddd) {
    *(undefined8 *)(puVar12 + -8) = 0x14001e279;
    FUN_1400191b0(pWVar9 + -8);
  }
LAB_14001e27b:
  uVar4 = local_30 ^ (ulonglong)local_38;
  *(undefined8 *)(puVar12 + -8) = 0x14001e287;
  FUN_14001b4d0(uVar4);
  return;
}

