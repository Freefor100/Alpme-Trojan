/* address=1400154d0 rva=0x154d0 */

undefined * FUN_1400154d0(void)

{
  return &DAT_1400d0e08;
}

