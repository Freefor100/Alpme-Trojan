/* address=1400194a4 rva=0x194a4 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */

void FUN_1400194a4(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4,
                  undefined8 param_5,longlong *param_6)

{
  undefined8 *puVar1;
  ulonglong *puVar2;
  byte bVar3;
  code *pcVar4;
  
  puVar1 = FUN_1400195c4(param_6);
  if ((puVar1 == (undefined8 *)0x0) || (pcVar4 = (code *)puVar1[0x77], pcVar4 == (code *)0x0)) {
    puVar2 = (ulonglong *)FUN_140019630(0x1400d17e8,(longlong)param_6);
    bVar3 = (byte)DAT_1400d02c0 & 0x3f;
    pcVar4 = (code *)((*puVar2 ^ DAT_1400d02c0) >> bVar3 | (*puVar2 ^ DAT_1400d02c0) << 0x40 - bVar3
                     );
    if (pcVar4 == (code *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_1400192e4();
    }
  }
  (*pcVar4)(param_1,param_2,param_3,param_4,param_5);
  return;
}

