/* address=140002475 rva=0x2475 */

uint FUN_140002475(HANDLE param_1,undefined8 param_2,ulonglong param_3)

{
  code *pcVar1;
  uint uVar2;
  ulonglong uVar3;
  undefined8 local_18;
  undefined8 uStack_10;
  
  local_18 = 0x103;
  uStack_10 = 0;
  uVar3 = 0xffffffff;
  if (param_3 < 0xffffffff) {
    uVar3 = param_3;
  }
  uVar2 = NtWriteFile(param_1,0,0,0,&local_18,param_2,(int)uVar3,0,0);
  if (uVar2 == 0x103) {
    WaitForSingleObject(param_1,0xffffffff);
    uVar2 = (uint)local_18;
    if ((uint)local_18 == 0x103) {
      pcVar1 = (code *)swi(0x29);
      (*pcVar1)(7);
                    /* WARNING: Does not return */
      pcVar1 = (code *)invalidInstructionException();
      (*pcVar1)();
    }
  }
  uVar2 = FUN_1400017d8(uVar2);
  return uVar2 & 0xff;
}

