/* address=140018fd8 rva=0x18fd8 */

void FUN_140018fd8(undefined8 param_1,int *param_2,undefined8 *param_3,int *param_4)

{
  int iVar1;
  int *piVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  undefined1 (*pauVar5) [32];
  undefined1 (*pauVar6) [32];
  longlong lVar7;
  
  FUN_140017cb4(*param_2);
  puVar4 = (undefined8 *)(*(longlong *)(*(longlong *)*param_3 + 0x88) + 0x18);
  if (DAT_1400d17c8 == (undefined1 (*) [32])0x0) {
LAB_14001908b:
    puVar4 = FUN_140019fec();
    *(undefined4 *)puVar4 = 0x16;
    FUN_1400192c4();
  }
  else {
    if (puVar4 == (undefined8 *)0x0) {
      FUN_1400237e0(DAT_1400d17c8,0,0x101);
      goto LAB_14001908b;
    }
    lVar7 = 2;
    pauVar6 = DAT_1400d17c8;
    do {
      uVar3 = puVar4[1];
      *(undefined8 *)*pauVar6 = *puVar4;
      *(undefined8 *)(*pauVar6 + 8) = uVar3;
      uVar3 = puVar4[3];
      *(undefined8 *)(*pauVar6 + 0x10) = puVar4[2];
      *(undefined8 *)(*pauVar6 + 0x18) = uVar3;
      uVar3 = puVar4[5];
      *(undefined8 *)pauVar6[1] = puVar4[4];
      *(undefined8 *)(pauVar6[1] + 8) = uVar3;
      uVar3 = puVar4[7];
      *(undefined8 *)(pauVar6[1] + 0x10) = puVar4[6];
      *(undefined8 *)(pauVar6[1] + 0x18) = uVar3;
      uVar3 = puVar4[9];
      *(undefined8 *)pauVar6[2] = puVar4[8];
      *(undefined8 *)(pauVar6[2] + 8) = uVar3;
      uVar3 = puVar4[0xb];
      *(undefined8 *)(pauVar6[2] + 0x10) = puVar4[10];
      *(undefined8 *)(pauVar6[2] + 0x18) = uVar3;
      uVar3 = puVar4[0xd];
      *(undefined8 *)pauVar6[3] = puVar4[0xc];
      *(undefined8 *)(pauVar6[3] + 8) = uVar3;
      pauVar5 = pauVar6 + 4;
      uVar3 = puVar4[0xf];
      *(undefined8 *)(pauVar6[3] + 0x10) = puVar4[0xe];
      *(undefined8 *)(pauVar6[3] + 0x18) = uVar3;
      puVar4 = puVar4 + 0x10;
      lVar7 = lVar7 + -1;
      pauVar6 = pauVar5;
    } while (lVar7 != 0);
    (*pauVar5)[0] = *(undefined1 *)puVar4;
  }
  lVar7 = 2;
  puVar4 = (undefined8 *)(*(longlong *)(*(longlong *)*param_3 + 0x88) + 0x119);
  if (DAT_1400d17d0 != (undefined1 (*) [32])0x0) {
    pauVar6 = DAT_1400d17d0;
    if (puVar4 != (undefined8 *)0x0) {
      do {
        uVar3 = puVar4[1];
        *(undefined8 *)*pauVar6 = *puVar4;
        *(undefined8 *)(*pauVar6 + 8) = uVar3;
        uVar3 = puVar4[3];
        *(undefined8 *)(*pauVar6 + 0x10) = puVar4[2];
        *(undefined8 *)(*pauVar6 + 0x18) = uVar3;
        uVar3 = puVar4[5];
        *(undefined8 *)pauVar6[1] = puVar4[4];
        *(undefined8 *)(pauVar6[1] + 8) = uVar3;
        uVar3 = puVar4[7];
        *(undefined8 *)(pauVar6[1] + 0x10) = puVar4[6];
        *(undefined8 *)(pauVar6[1] + 0x18) = uVar3;
        uVar3 = puVar4[9];
        *(undefined8 *)pauVar6[2] = puVar4[8];
        *(undefined8 *)(pauVar6[2] + 8) = uVar3;
        uVar3 = puVar4[0xb];
        *(undefined8 *)(pauVar6[2] + 0x10) = puVar4[10];
        *(undefined8 *)(pauVar6[2] + 0x18) = uVar3;
        uVar3 = puVar4[0xd];
        *(undefined8 *)pauVar6[3] = puVar4[0xc];
        *(undefined8 *)(pauVar6[3] + 8) = uVar3;
        uVar3 = puVar4[0xf];
        *(undefined8 *)(pauVar6[3] + 0x10) = puVar4[0xe];
        *(undefined8 *)(pauVar6[3] + 0x18) = uVar3;
        puVar4 = puVar4 + 0x10;
        lVar7 = lVar7 + -1;
        pauVar6 = pauVar6 + 4;
      } while (lVar7 != 0);
      goto LAB_14001913c;
    }
    FUN_1400237e0(DAT_1400d17d0,0,0x100);
  }
  puVar4 = FUN_140019fec();
  *(undefined4 *)puVar4 = 0x16;
  FUN_1400192c4();
LAB_14001913c:
  piVar2 = (int *)**(undefined8 **)param_3[1];
  LOCK();
  iVar1 = *piVar2;
  *piVar2 = *piVar2 + -1;
  UNLOCK();
  if ((iVar1 == 1) && ((undefined *)**(undefined8 **)param_3[1] != &DAT_1400d0340)) {
    FUN_1400191b0((LPVOID)**(undefined8 **)param_3[1]);
  }
  **(undefined8 **)param_3[1] = *(undefined8 *)(*(longlong *)*param_3 + 0x88);
  LOCK();
  **(int **)(*(longlong *)*param_3 + 0x88) = **(int **)(*(longlong *)*param_3 + 0x88) + 1;
  UNLOCK();
  FUN_140017cd0(*param_4);
  return;
}

