/* address=140024239 rva=0x24239 */

void FUN_140024239(undefined8 param_1,longlong param_2)

{
  FUN_140017cd0(**(int **)(param_2 + 0x68));
  return;
}

