/* address=140015280 rva=0x15280 */

undefined8 FUN_140015280(char param_1,char param_2)

{
  longlong in_RAX;
  uint7 extraout_var;
  
  if ((DAT_1400d0da0 == '\0') || (param_2 == '\0')) {
    FUN_140015ed0(param_1);
    FUN_140015d70(param_1);
    in_RAX = (ulonglong)extraout_var << 8;
  }
  return CONCAT71((int7)((ulonglong)in_RAX >> 8),1);
}

