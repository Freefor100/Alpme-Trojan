/* address=14001e4b0 rva=0x1e4b0 */

undefined4 FUN_14001e4b0(longlong param_1)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  
  if (param_1 == 0) {
    puVar2 = FUN_140019fec();
    *(undefined4 *)puVar2 = 0x16;
    FUN_1400192c4();
    uVar1 = 0xffffffff;
  }
  else {
    uVar1 = *(undefined4 *)(param_1 + 0x18);
  }
  return uVar1;
}

