/* address=140015f50 rva=0x15f50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_140015f50(ulonglong param_1)

{
  byte bVar1;
  
  bVar1 = 0x40 - ((byte)DAT_1400d02c0 & 0x3f) & 0x3f;
  _DAT_1400d0e60 = (param_1 >> bVar1 | param_1 << 0x40 - bVar1) ^ DAT_1400d02c0;
  return;
}

