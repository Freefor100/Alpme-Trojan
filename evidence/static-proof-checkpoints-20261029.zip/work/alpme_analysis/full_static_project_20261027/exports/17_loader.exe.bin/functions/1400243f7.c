/* address=1400243f7 rva=0x243f7 */

void FUN_1400243f7(void)

{
  FUN_140017cd0(8);
  return;
}

