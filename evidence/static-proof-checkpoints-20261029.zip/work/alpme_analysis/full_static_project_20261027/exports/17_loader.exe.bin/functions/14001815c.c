/* address=14001815c rva=0x1815c */

undefined8 * FUN_14001815c(void)

{
  DWORD dwErrCode;
  BOOL BVar1;
  undefined8 *lpFlsData;
  
  dwErrCode = GetLastError();
  BVar1 = FlsSetValue(DAT_1400d0338,(PVOID)0xffffffffffffffff);
  if (BVar1 != 0) {
    lpFlsData = FUN_14001ab80(1,0x3c8);
    if (lpFlsData != (undefined8 *)0x0) {
      BVar1 = FlsSetValue(DAT_1400d0338,lpFlsData);
      if (BVar1 == 0) {
        FlsSetValue(DAT_1400d0338,(PVOID)0x0);
        FUN_1400191b0(lpFlsData);
        lpFlsData = (undefined8 *)0x0;
      }
      else {
        FUN_140017f94(lpFlsData);
        FUN_1400191b0((LPVOID)0x0);
      }
      SetLastError(dwErrCode);
      return lpFlsData;
    }
    FlsSetValue(DAT_1400d0338,(PVOID)0x0);
    FUN_1400191b0((LPVOID)0x0);
  }
  SetLastError(dwErrCode);
  return (undefined8 *)0x0;
}

