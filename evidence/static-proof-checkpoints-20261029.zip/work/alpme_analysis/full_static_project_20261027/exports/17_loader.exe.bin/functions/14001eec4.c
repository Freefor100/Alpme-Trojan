/* address=14001eec4 rva=0x1eec4 */

void FUN_14001eec4(DWORD *param_1,uint param_2,short *param_3,ulonglong param_4,undefined1 param_5)

{
  short sVar1;
  uint uVar2;
  HANDLE hFile;
  ulonglong uVar3;
  uint nNumberOfBytesToWrite;
  BOOL BVar4;
  DWORD DVar5;
  longlong lVar6;
  short *psVar7;
  short *psVar8;
  undefined8 uStack_20;
  
  uStack_20 = 0x14001eedc;
  lVar6 = FUN_140014e00();
  lVar6 = -lVar6;
  *(ulonglong *)((longlong)register0x00000020 + lVar6 + 0x1428) =
       DAT_1400d02c0 ^ (longlong)register0x00000020 + lVar6 + -0x18;
  psVar8 = (short *)((param_4 & 0xffffffff) + (longlong)param_3);
  hFile = *(HANDLE *)
           ((&DAT_1400d13c0)[(longlong)(int)param_2 >> 6] + 0x28 +
           (ulonglong)(param_2 & 0x3f) * 0x48);
  param_1[0] = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  do {
    if (psVar8 <= param_3) break;
    psVar7 = (short *)(&param_5 + lVar6);
    do {
      if (psVar8 <= param_3) break;
      sVar1 = *param_3;
      param_3 = param_3 + 1;
      if (sVar1 == 10) {
        param_1[2] = param_1[2] + 2;
        *psVar7 = 0xd;
        psVar7 = psVar7 + 1;
      }
      *psVar7 = sVar1;
      psVar7 = psVar7 + 1;
    } while (psVar7 < (short *)((longlong)register0x00000020 + lVar6 + 0x1426));
    *(undefined4 *)((longlong)register0x00000020 + lVar6 + 0x18) = 0;
    *(undefined8 *)((longlong)register0x00000020 + lVar6 + 8) = 0;
    nNumberOfBytesToWrite = (int)((longlong)psVar7 - (longlong)(&param_5 + lVar6) >> 1) * 2;
    *(undefined8 *)((longlong)&uStack_20 + lVar6) = 0x14001ef96;
    BVar4 = WriteFile(hFile,&param_5 + lVar6,nNumberOfBytesToWrite,
                      (LPDWORD)((longlong)register0x00000020 + lVar6 + 0x18),
                      *(LPOVERLAPPED *)((longlong)register0x00000020 + lVar6 + 8));
    if (BVar4 == 0) {
      *(undefined8 *)((longlong)&uStack_20 + lVar6) = 0x14001efb2;
      DVar5 = GetLastError();
      *param_1 = DVar5;
      break;
    }
    uVar2 = *(uint *)((longlong)register0x00000020 + lVar6 + 0x18);
    param_1[1] = param_1[1] + uVar2;
  } while (nNumberOfBytesToWrite <= uVar2);
  uVar3 = *(ulonglong *)((longlong)register0x00000020 + lVar6 + 0x1428);
  *(undefined8 *)((longlong)&uStack_20 + lVar6) = 0x14001efc7;
  FUN_14001b4d0(uVar3 ^ (longlong)register0x00000020 + lVar6 + -0x18);
  return;
}

