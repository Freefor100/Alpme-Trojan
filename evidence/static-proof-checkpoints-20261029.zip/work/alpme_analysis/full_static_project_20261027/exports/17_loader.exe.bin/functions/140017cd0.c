/* address=140017cd0 rva=0x17cd0 */

void FUN_140017cd0(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x000140017ce2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  LeaveCriticalSection(&DAT_1400d1150 + (longlong)param_1 * 0x28);
  return;
}

