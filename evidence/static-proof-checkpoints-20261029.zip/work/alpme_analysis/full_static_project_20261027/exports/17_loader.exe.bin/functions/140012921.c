/* address=140012921 rva=0x12921 */

undefined1 FUN_140012921(void)

{
  return 0x2b;
}

