/* address=14000b9a0 rva=0xb9a0 */

uint FUN_14000b9a0(longlong param_1,uint param_2,char param_3)

{
  undefined8 uVar1;
  longlong lVar2;
  char cVar3;
  ushort uVar4;
  uint uVar5;
  uint uVar6;
  
  switch(*(uint *)(param_1 + 4) >> 0x1d & 3) {
  case 0:
    param_2 = 0;
    break;
  case 2:
    param_2 = (param_2 & 0xffff) >> 1;
    break;
  case 3:
    if (param_3 == '\0') {
      param_2 = 0;
    }
  }
  uVar6 = *(uint *)(param_1 + 4) & 0x1fffff;
  uVar1 = *(undefined8 *)(param_1 + 0x10);
  lVar2 = *(longlong *)(param_1 + 0x18);
  uVar5 = param_2 + 1;
  do {
    uVar4 = (short)uVar5 - 1;
    uVar5 = (uint)uVar4;
    if (uVar4 == 0) {
      return uVar6;
    }
    cVar3 = (**(code **)(lVar2 + 0x20))(uVar1,uVar6);
  } while (cVar3 == '\0');
  return 0xffffffff;
}

