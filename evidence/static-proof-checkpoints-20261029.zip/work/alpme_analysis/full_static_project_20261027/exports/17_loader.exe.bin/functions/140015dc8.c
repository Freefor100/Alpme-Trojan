/* address=140015dc8 rva=0x15dc8 */

undefined1 FUN_140015dc8(void)

{
  FUN_140016bc4();
  return 1;
}

