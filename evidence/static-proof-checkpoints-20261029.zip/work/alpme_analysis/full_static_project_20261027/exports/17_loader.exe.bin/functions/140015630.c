/* address=140015630 rva=0x15630 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Removing unreachable block (ram,0x000140015650) */
/* WARNING: Removing unreachable block (ram,0x000140015658) */
/* WARNING: Removing unreachable block (ram,0x00014001565e) */

void FUN_140015630(void)

{
  return;
}

