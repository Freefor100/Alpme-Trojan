/* address=14001edbc rva=0x1edbc */

void FUN_14001edbc(DWORD *param_1,uint param_2,char *param_3,ulonglong param_4,undefined1 param_5)

{
  char cVar1;
  uint uVar2;
  HANDLE hFile;
  ulonglong uVar3;
  BOOL BVar4;
  DWORD DVar5;
  longlong lVar6;
  uint nNumberOfBytesToWrite;
  char *pcVar7;
  char *pcVar8;
  undefined8 uStack_20;
  
  uStack_20 = 0x14001edd4;
  lVar6 = FUN_140014e00();
  lVar6 = -lVar6;
  *(ulonglong *)((longlong)register0x00000020 + lVar6 + 0x1428) =
       DAT_1400d02c0 ^ (longlong)register0x00000020 + lVar6 + -0x18;
  pcVar8 = param_3 + (param_4 & 0xffffffff);
  hFile = *(HANDLE *)
           ((&DAT_1400d13c0)[(longlong)(int)param_2 >> 6] + 0x28 +
           (ulonglong)(param_2 & 0x3f) * 0x48);
  param_1[0] = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  do {
    if (pcVar8 <= param_3) break;
    pcVar7 = &param_5 + lVar6;
    do {
      if (pcVar8 <= param_3) break;
      cVar1 = *param_3;
      param_3 = param_3 + 1;
      if (cVar1 == '\n') {
        param_1[2] = param_1[2] + 1;
        *pcVar7 = '\r';
        pcVar7 = pcVar7 + 1;
      }
      *pcVar7 = cVar1;
      pcVar7 = pcVar7 + 1;
    } while (pcVar7 < (char *)((longlong)register0x00000020 + lVar6 + 0x1427));
    *(undefined4 *)((longlong)register0x00000020 + lVar6 + 0x18) = 0;
    *(undefined8 *)((longlong)register0x00000020 + lVar6 + 8) = 0;
    nNumberOfBytesToWrite = (int)pcVar7 - ((int)&param_5 + (int)lVar6);
    *(undefined8 *)((longlong)&uStack_20 + lVar6) = 0x14001ee7a;
    BVar4 = WriteFile(hFile,&param_5 + lVar6,nNumberOfBytesToWrite,
                      (LPDWORD)((longlong)register0x00000020 + lVar6 + 0x18),
                      *(LPOVERLAPPED *)((longlong)register0x00000020 + lVar6 + 8));
    if (BVar4 == 0) {
      *(undefined8 *)((longlong)&uStack_20 + lVar6) = 0x14001ee96;
      DVar5 = GetLastError();
      *param_1 = DVar5;
      break;
    }
    uVar2 = *(uint *)((longlong)register0x00000020 + lVar6 + 0x18);
    param_1[1] = param_1[1] + uVar2;
  } while (nNumberOfBytesToWrite <= uVar2);
  uVar3 = *(ulonglong *)((longlong)register0x00000020 + lVar6 + 0x1428);
  *(undefined8 *)((longlong)&uStack_20 + lVar6) = 0x14001eeab;
  FUN_14001b4d0(uVar3 ^ (longlong)register0x00000020 + lVar6 + -0x18);
  return;
}

