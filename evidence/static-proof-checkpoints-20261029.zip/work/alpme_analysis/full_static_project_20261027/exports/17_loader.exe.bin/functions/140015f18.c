/* address=140015f18 rva=0x15f18 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 FUN_140015f18(void)

{
  DAT_1400d0e48 = GetCommandLineA();
  _DAT_1400d0e50 = GetCommandLineW();
  return 1;
}

