/* address=1400154f0 rva=0x154f0 */

bool FUN_1400154f0(void)

{
  HMODULE pHVar1;
  longlong lVar2;
  
  pHVar1 = GetModuleHandleW((LPCWSTR)0x0);
  if ((((pHVar1 == (HMODULE)0x0) || ((short)pHVar1->unused != 0x5a4d)) ||
      (lVar2 = (longlong)pHVar1[0xf].unused, *(int *)((longlong)&pHVar1->unused + lVar2) != 0x4550))
     || ((*(short *)((longlong)&pHVar1[6].unused + lVar2) != 0x20b ||
         (*(uint *)((longlong)&pHVar1[0x21].unused + lVar2) < 0xf)))) {
    return false;
  }
  return *(int *)((longlong)&pHVar1[0x3e].unused + lVar2) != 0;
}

