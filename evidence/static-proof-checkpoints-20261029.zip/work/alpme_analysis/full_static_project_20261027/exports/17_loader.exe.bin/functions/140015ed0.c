/* address=140015ed0 rva=0x15ed0 */

undefined8 FUN_140015ed0(char param_1)

{
  undefined4 uVar1;
  undefined8 in_RAX;
  undefined4 extraout_var;
  undefined8 uVar2;
  
  if (param_1 == '\0') {
    uVar2 = FUN_140019288(0x1400765a0,0x1400766a0);
    return uVar2;
  }
  if (DAT_1400d1828 != 0) {
    uVar1 = thunk_FUN_140019c78(param_1);
    in_RAX = CONCAT44(extraout_var,uVar1);
  }
  return CONCAT71((int7)((ulonglong)in_RAX >> 8),1);
}

