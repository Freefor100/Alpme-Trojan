/* address=14001a860 rva=0x1a860 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */

undefined8 FUN_14001a860(undefined4 *param_1,undefined8 param_2,undefined8 param_3)

{
  PVOID pvVar1;
  undefined4 *local_28;
  undefined8 local_20;
  
  local_28 = param_1;
  local_20 = param_3;
  pvVar1 = FUN_1400173f0();
  (**(code **)((longlong)pvVar1 + 0x10))(*param_1,&local_28);
  return 0;
}

