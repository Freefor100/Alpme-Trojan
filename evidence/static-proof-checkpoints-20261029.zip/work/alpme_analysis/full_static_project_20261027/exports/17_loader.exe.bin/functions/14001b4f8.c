/* address=14001b4f8 rva=0x1b4f8 */

ulonglong FUN_14001b4f8(undefined8 *param_1,undefined8 *param_2)

{
  uint uVar1;
  int iVar2;
  undefined8 *puVar3;
  byte *pbVar4;
  longlong *plVar5;
  LPVOID pvVar6;
  longlong lVar7;
  ulonglong uVar8;
  longlong *plVar9;
  longlong *plVar10;
  char *pcVar11;
  ulonglong uVar12;
  longlong lVar13;
  longlong local_res10;
  ulonglong local_res18;
  char *local_res20;
  longlong *local_58;
  longlong *plStack_50;
  undefined8 local_48;
  
  if (param_2 == (undefined8 *)0x0) {
    puVar3 = FUN_140019fec();
    *(undefined4 *)puVar3 = 0x16;
    FUN_1400192c4();
    uVar8 = 0x16;
  }
  else {
    *param_2 = 0;
    pbVar4 = (byte *)*param_1;
    local_58 = (longlong *)0x0;
    plStack_50 = (longlong *)0x0;
    local_48 = 0;
    while (plVar9 = plStack_50, plVar10 = local_58, pbVar4 != (byte *)0x0) {
      local_res10 = CONCAT53(local_res10._3_5_,0x3f2a);
      pbVar4 = FUN_140020f50(pbVar4,(byte *)&local_res10);
      if (pbVar4 == (byte *)0x0) {
        uVar12 = FUN_14001ba80((longlong)*param_1,0,0,(longlong *)&local_58);
        plVar10 = local_58;
        uVar8 = uVar12 & 0xffffffff;
        if ((int)uVar12 != 0) {
          plVar9 = local_58;
          if (local_58 != plStack_50) {
            do {
              FUN_1400191b0((LPVOID)*plVar9);
              plVar9 = plVar9 + 1;
            } while (plVar9 != plStack_50);
          }
          goto LAB_14001b647;
        }
      }
      else {
        uVar1 = FUN_14001bc04((byte *)*param_1,pbVar4,(longlong *)&local_58);
        plVar10 = local_58;
        uVar8 = (ulonglong)uVar1;
        if (uVar1 != 0) {
          plVar9 = local_58;
          if (local_58 != plStack_50) {
            do {
              FUN_1400191b0((LPVOID)*plVar9);
              plVar9 = plVar9 + 1;
            } while (plVar9 != plStack_50);
          }
          goto LAB_14001b647;
        }
      }
      param_1 = param_1 + 1;
      pbVar4 = (byte *)*param_1;
    }
    uVar8 = 0;
    local_res18 = 0;
    uVar12 = ((longlong)plStack_50 - (longlong)local_58 >> 3) + 1;
    plVar5 = local_58;
    if (local_58 != plStack_50) {
      do {
        lVar7 = -1;
        do {
          lVar7 = lVar7 + 1;
        } while (*(char *)(*plVar5 + lVar7) != '\0');
        plVar5 = plVar5 + 1;
        uVar8 = uVar8 + 1 + lVar7;
      } while (plVar5 != plStack_50);
      local_res18 = uVar8;
    }
    pvVar6 = FUN_14001650c(uVar12,local_res18,1);
    if (pvVar6 == (LPVOID)0x0) {
      FUN_1400191b0((LPVOID)0x0);
      for (plVar5 = plVar10; plVar5 != plVar9; plVar5 = plVar5 + 1) {
        FUN_1400191b0((LPVOID)*plVar5);
      }
      uVar8 = 0xffffffff;
LAB_14001b647:
      FUN_1400191b0(plVar10);
    }
    else {
      pcVar11 = (char *)((longlong)pvVar6 + uVar12 * 8);
      local_res20 = pcVar11;
      if (plVar10 != plVar9) {
        local_res10 = (longlong)pvVar6 - (longlong)plVar10;
        plVar5 = plVar10;
        do {
          lVar7 = -1;
          do {
            lVar13 = lVar7;
            lVar7 = lVar13 + 1;
          } while (*(char *)(*plVar5 + lVar7) != '\0');
          lVar13 = lVar13 + 2;
          iVar2 = FUN_140020e20(pcVar11,(longlong)(local_res20 + (local_res18 - (longlong)pcVar11)),
                                *plVar5,lVar13);
          if (iVar2 != 0) {
                    /* WARNING: Subroutine does not return */
            FUN_1400192e4();
          }
          *(char **)(local_res10 + (longlong)plVar5) = pcVar11;
          pcVar11 = pcVar11 + lVar13;
          plVar5 = plVar5 + 1;
        } while (plVar5 != plVar9);
      }
      *param_2 = pvVar6;
      FUN_1400191b0((LPVOID)0x0);
      for (plVar5 = plVar10; plVar5 != plVar9; plVar5 = plVar5 + 1) {
        FUN_1400191b0((LPVOID)*plVar5);
      }
      FUN_1400191b0(plVar10);
      uVar8 = 0;
    }
  }
  return uVar8;
}

