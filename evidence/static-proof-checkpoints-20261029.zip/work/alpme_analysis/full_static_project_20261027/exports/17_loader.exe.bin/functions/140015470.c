/* address=140015470 rva=0x15470 */

void FUN_140015470(void)

{
  ulonglong *puVar1;
  
  puVar1 = (ulonglong *)FUN_140015490();
  *puVar1 = *puVar1 | 0x24;
  puVar1 = (ulonglong *)FUN_1400154a0();
  *puVar1 = *puVar1 | 2;
  return;
}

