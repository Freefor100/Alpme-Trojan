/* address=140017d9c rva=0x17d9c */

undefined4 FUN_140017d9c(void)

{
  BOOL in_EAX;
  
  if (DAT_1400d0338 != 0xffffffff) {
    in_EAX = FlsFree(DAT_1400d0338);
    DAT_1400d0338 = 0xffffffff;
  }
  return CONCAT31((int3)((uint)in_EAX >> 8),1);
}

