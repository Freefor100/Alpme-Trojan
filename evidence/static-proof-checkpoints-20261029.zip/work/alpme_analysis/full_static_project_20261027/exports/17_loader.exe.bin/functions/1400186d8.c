/* address=1400186d8 rva=0x186d8 */

void FUN_1400186d8(UINT param_1,longlong param_2)

{
  byte *pbVar1;
  byte bVar2;
  int iVar3;
  UINT CodePage;
  BOOL BVar4;
  UINT *pUVar5;
  byte *pbVar6;
  wchar_t *pwVar7;
  longlong lVar8;
  BYTE *pBVar9;
  ulonglong uVar10;
  byte *pbVar11;
  undefined2 *puVar12;
  undefined4 uVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  byte *pbVar17;
  undefined1 auStack_68 [32];
  _cpinfo local_48;
  ulonglong local_30;
  
  local_30 = DAT_1400d02c0 ^ (ulonglong)auStack_68;
  local_48.MaxCharSize = 0;
  local_48.DefaultChar[0] = '\0';
  local_48.DefaultChar[1] = '\0';
  local_48.LeadByte[0] = '\0';
  local_48.LeadByte[1] = '\0';
  local_48.LeadByte[2] = '\0';
  local_48.LeadByte[3] = '\0';
  local_48.LeadByte[4] = '\0';
  local_48.LeadByte[5] = '\0';
  local_48.LeadByte[6] = '\0';
  local_48.LeadByte[7] = '\0';
  local_48.LeadByte[8] = '\0';
  local_48.LeadByte[9] = '\0';
  local_48.LeadByte[10] = '\0';
  local_48.LeadByte[0xb] = '\0';
  local_48._18_2_ = 0;
  CodePage = FUN_1400189a0(param_1);
  pwVar7 = (wchar_t *)0x0;
  if (CodePage != 0) {
    uVar16 = 0;
    pUVar5 = &DAT_1400d0790;
    uVar13 = 1;
LAB_14001872f:
    if (*pUVar5 != CodePage) goto code_r0x000140018737;
    FUN_1400237e0((undefined1 (*) [32])(param_2 + 0x18),0,0x101);
    pbVar17 = &DAT_1400d0780;
    lVar8 = 4;
    pbVar6 = &DAT_1400d07a0 + (ulonglong)uVar16 * 0x30;
    do {
      bVar2 = *pbVar6;
      pbVar11 = pbVar6;
      while ((bVar2 != 0 && (pbVar11[1] != 0))) {
        bVar2 = *pbVar11;
        uVar14 = (uint)bVar2;
        if (bVar2 <= pbVar11[1]) {
          uVar15 = (uint)bVar2;
          do {
            uVar15 = uVar15 + 1;
            if (0x100 < uVar15) break;
            uVar14 = uVar14 + 1;
            pbVar1 = (byte *)((ulonglong)uVar15 + 0x18 + param_2);
            *pbVar1 = *pbVar1 | *pbVar17;
          } while (uVar14 <= pbVar11[1]);
        }
        pbVar11 = pbVar11 + 2;
        bVar2 = *pbVar11;
      }
      pbVar6 = pbVar6 + 8;
      pbVar17 = pbVar17 + 1;
      lVar8 = lVar8 + -1;
    } while (lVar8 != 0);
    *(UINT *)(param_2 + 4) = CodePage;
    *(undefined4 *)(param_2 + 8) = 1;
    if (CodePage == 0x3a4) {
      pwVar7 = L"ja-JP";
    }
    else if (CodePage == 0x3a8) {
      pwVar7 = L"zh-CN";
    }
    else if (CodePage == 0x3b5) {
      pwVar7 = L"ko-KR";
    }
    else if (CodePage == 0x3b6) {
      pwVar7 = L"zh-TW";
    }
    *(wchar_t **)(param_2 + 0x220) = pwVar7;
    puVar12 = (undefined2 *)(param_2 + 0xc);
    lVar8 = 6;
    do {
      *puVar12 = *(undefined2 *)
                  (((ulonglong)uVar16 * 0x30 - param_2) + 0x1400d0788 + (longlong)puVar12);
      puVar12 = puVar12 + 1;
      lVar8 = lVar8 + -1;
    } while (lVar8 != 0);
    goto LAB_140018966;
  }
LAB_140018970:
  FUN_140018a20(param_2);
LAB_14001897a:
  FUN_14001b4d0(local_30 ^ (ulonglong)auStack_68);
  return;
code_r0x000140018737:
  uVar16 = uVar16 + 1;
  pUVar5 = pUVar5 + 0xc;
  if (4 < uVar16) goto code_r0x000140018744;
  goto LAB_14001872f;
code_r0x000140018744:
  if ((CodePage == 65000) || (BVar4 = IsValidCodePage(CodePage & 0xffff), BVar4 == 0))
  goto LAB_14001897a;
  if (CodePage == 0xfde9) {
    *(undefined8 *)(param_2 + 4) = 0xfde9;
    *(undefined8 *)(param_2 + 0x220) = 0;
    *(undefined4 *)(param_2 + 0x18) = 0;
    *(undefined2 *)(param_2 + 0x1c) = 0;
  }
  else {
    BVar4 = GetCPInfo(CodePage,&local_48);
    if (BVar4 == 0) {
      if (DAT_1400d17e0 == 0) goto LAB_14001897a;
      goto LAB_140018970;
    }
    FUN_1400237e0((undefined1 (*) [32])(param_2 + 0x18),0,0x101);
    *(UINT *)(param_2 + 4) = CodePage;
    *(undefined8 *)(param_2 + 0x220) = 0;
    if (local_48.MaxCharSize == 2) {
      pBVar9 = local_48.LeadByte;
      bVar2 = local_48.LeadByte[0];
      while ((bVar2 != 0 && (pBVar9[1] != 0))) {
        bVar2 = *pBVar9;
        if ((uint)bVar2 <= (uint)pBVar9[1]) {
          uVar16 = (uint)bVar2;
          uVar10 = (ulonglong)(((uint)pBVar9[1] - (uint)bVar2) + 1);
          do {
            uVar16 = uVar16 + 1;
            pbVar6 = (byte *)((ulonglong)uVar16 + 0x18 + param_2);
            *pbVar6 = *pbVar6 | 4;
            uVar10 = uVar10 - 1;
          } while (uVar10 != 0);
        }
        pBVar9 = pBVar9 + 2;
        bVar2 = *pBVar9;
      }
      pbVar6 = (byte *)(param_2 + 0x1a);
      lVar8 = 0xfe;
      do {
        *pbVar6 = *pbVar6 | 8;
        pbVar6 = pbVar6 + 1;
        lVar8 = lVar8 + -1;
      } while (lVar8 != 0);
      iVar3 = *(int *)(param_2 + 4);
      if (iVar3 == 0x3a4) {
        pwVar7 = L"ja-JP";
      }
      else if (iVar3 == 0x3a8) {
        pwVar7 = L"zh-CN";
      }
      else if (iVar3 == 0x3b5) {
        pwVar7 = L"ko-KR";
      }
      else if (iVar3 == 0x3b6) {
        pwVar7 = L"zh-TW";
      }
      else {
        pwVar7 = (wchar_t *)0x0;
      }
      *(wchar_t **)(param_2 + 0x220) = pwVar7;
    }
    else {
      uVar13 = 0;
    }
    *(undefined4 *)(param_2 + 8) = uVar13;
  }
  puVar12 = (undefined2 *)(param_2 + 0xc);
  for (lVar8 = 6; lVar8 != 0; lVar8 = lVar8 + -1) {
    *puVar12 = 0;
    puVar12 = puVar12 + 1;
  }
LAB_140018966:
  FUN_140018de0(param_2);
  goto LAB_14001897a;
}

