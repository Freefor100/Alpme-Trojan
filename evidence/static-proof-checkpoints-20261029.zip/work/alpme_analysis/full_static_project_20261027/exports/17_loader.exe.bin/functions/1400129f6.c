/* address=1400129f6 rva=0x129f6 */

ulonglong FUN_1400129f6(uint param_1)

{
  longlong lVar1;
  longlong lVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  uint uVar5;
  ulonglong uVar6;
  uint uVar7;
  
  uVar3 = 0xb;
  lVar1 = 0;
  do {
    lVar2 = lVar1 + (uVar3 >> 1);
    if (param_1 < ((&DAT_140073884)[lVar2] & 0x1fffff)) {
      lVar2 = lVar1;
    }
    uVar3 = uVar3 - (uVar3 >> 1);
    lVar1 = lVar2;
  } while (1 < uVar3);
  uVar6 = (ulonglong)((&DAT_140073884)[lVar2] * 0x800 == param_1 * 0x800) + lVar2 +
          (ulonglong)((uint)((&DAT_140073884)[lVar2] * 0x800) < param_1 * 0x800);
  uVar3 = (ulonglong)((uint)(&DAT_140073884)[uVar6] >> 0x15);
  uVar4 = 0x2b;
  if ((uVar6 < 10) &&
     (uVar4 = (ulonglong)(*(uint *)(&DAT_140073888 + uVar6 * 4) >> 0x15), uVar6 == 0)) {
    uVar7 = 0;
  }
  else {
    uVar7 = *(uint *)(&DAT_140073880 + uVar6 * 4) & 0x1fffff;
  }
  if (~uVar3 + uVar4 != 0) {
    uVar5 = 0;
    do {
      uVar5 = (byte)(&DAT_140074caa)[uVar3] + uVar5;
      if (param_1 - uVar7 < uVar5) break;
      uVar3 = uVar3 + 1;
    } while (uVar3 != uVar4 - 1);
  }
  return uVar3 & 0xffffffffffffff01;
}

