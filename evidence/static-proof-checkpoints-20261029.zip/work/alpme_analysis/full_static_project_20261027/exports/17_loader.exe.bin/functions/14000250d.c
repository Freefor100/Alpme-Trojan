/* address=14000250d rva=0x250d */

void FUN_14000250d(LPVOID param_1,longlong param_2,ulonglong param_3,longlong param_4)

{
  ulonglong *puVar1;
  longlong lVar2;
  ulonglong local_10;
  longlong local_8;
  
  puVar1 = &local_10;
  if (param_2 == 0) {
    lVar2 = 0;
  }
  else {
    lVar2 = param_2 * param_4;
    puVar1 = (ulonglong *)&local_8;
    local_10 = param_3;
  }
  *puVar1 = lVar2;
  if ((local_10 == 0) || (local_8 == 0)) {
    return;
  }
  FUN_14001305a(param_1,local_10);
  return;
}

