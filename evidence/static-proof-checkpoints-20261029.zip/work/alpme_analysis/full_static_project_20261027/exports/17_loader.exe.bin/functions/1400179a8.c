/* address=1400179a8 rva=0x179a8 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */

INT_PTR FUN_1400179a8(undefined8 param_1)

{
  FARPROC pFVar1;
  INT_PTR IVar2;
  
  pFVar1 = FUN_140017a48(0x1a,"AppPolicyGetProcessTerminationMethod",(uint *)&DAT_140077020,
                         (uint *)&DAT_140077024);
  if (pFVar1 == (FARPROC)0x0) {
    return 0xc0000225;
  }
  IVar2 = (*pFVar1)(0xfffffffffffffffa,param_1);
  return IVar2;
}

