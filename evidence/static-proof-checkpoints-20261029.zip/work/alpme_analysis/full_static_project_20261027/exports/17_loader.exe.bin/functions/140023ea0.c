/* address=140023ea0 rva=0x23ea0 */

void FUN_140023ea0(undefined8 param_1)

{
  undefined1 local_21;
  undefined8 *local_20;
  undefined8 local_18;
  undefined1 *local_10;
  undefined1 *local_8;
  
  local_8 = &local_21;
  if (DAT_1400cf788 != 0) {
    local_20 = &local_18;
    local_10 = &DAT_1400cf730;
    local_18 = param_1;
    FUN_140023fbe((uint *)&DAT_1400cf788,'\x01',&local_20,0x140073580);
  }
  return;
}

