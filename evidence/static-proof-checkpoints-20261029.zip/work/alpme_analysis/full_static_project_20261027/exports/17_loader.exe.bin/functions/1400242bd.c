/* address=1400242bd rva=0x242bd */

void FUN_1400242bd(undefined8 param_1,longlong param_2)

{
  FUN_140019e64(**(longlong **)(param_2 + 0x48));
  return;
}

