/* address=140022dac rva=0x22dac */

undefined8 FUN_140022dac(uint param_1,longlong param_2)

{
  BOOL BVar1;
  DWORD DVar2;
  longlong lVar3;
  longlong lVar4;
  HANDLE hObject;
  undefined8 uVar5;
  
  lVar3 = FUN_14001c920(param_1);
  if (lVar3 != -1) {
    if (((param_1 == 1) && ((*(byte *)(DAT_1400d13c0 + 200) & 1) != 0)) ||
       ((param_1 == 2 && ((*(byte *)(DAT_1400d13c0 + 0x80) & 1) != 0)))) {
      lVar3 = FUN_14001c920(2);
      lVar4 = FUN_14001c920(1);
      if (lVar4 == lVar3) goto LAB_140022dce;
    }
    hObject = (HANDLE)FUN_14001c920(param_1);
    BVar1 = CloseHandle(hObject);
    if (BVar1 == 0) {
      DVar2 = GetLastError();
      goto LAB_140022e2c;
    }
  }
LAB_140022dce:
  DVar2 = 0;
LAB_140022e2c:
  FUN_14001c998(param_1);
  *(undefined1 *)
   ((&DAT_1400d13c0)[(longlong)(int)param_1 >> 6] + 0x38 + (ulonglong)(param_1 & 0x3f) * 0x48) = 0;
  if (DVar2 == 0) {
    uVar5 = 0;
  }
  else {
    FUN_14001a12c(DVar2,param_2);
    uVar5 = 0xffffffff;
  }
  return uVar5;
}

