/* address=140016068 rva=0x16068 */

void FUN_140016068(uint param_1,char param_2)

{
  HANDLE hProcess;
  
  if (param_2 != '\0') {
    hProcess = GetCurrentProcess();
    TerminateProcess(hProcess,param_1);
  }
  FUN_140016004(param_1);
                    /* WARNING: Subroutine does not return */
  ExitProcess(param_1);
}

