/* address=140017a48 rva=0x17a48 */

FARPROC FUN_140017a48(uint param_1,LPCSTR param_2,uint *param_3,uint *param_4)

{
  longlong lVar1;
  uint uVar2;
  LPCWSTR lpLibFileName;
  DWORD DVar3;
  int iVar4;
  BOOL BVar5;
  HMODULE hLibModule;
  FARPROC pFVar6;
  FARPROC pFVar7;
  DWORD local_res18 [2];
  
  do {
    if (param_3 == param_4) {
      pFVar7 = (FARPROC)0x0;
LAB_140017b3a:
      FUN_140017cb4(0xe);
      local_res18[0] = 0;
      BVar5 = VirtualProtect(&DAT_14007e150,0x100,4,local_res18);
      if (BVar5 != 0) {
        pFVar6 = pFVar7;
        if (pFVar7 == (FARPROC)0x0) {
          pFVar6 = (FARPROC)0xffffffffffffffff;
        }
        LOCK();
        (&DAT_14007e150)[param_1] = pFVar6;
        UNLOCK();
        BVar5 = VirtualProtect(&DAT_14007e150,0x100,2,local_res18);
        if (BVar5 != 0) {
          FUN_140017cd0(0xe);
          return pFVar7;
        }
      }
                    /* WARNING: Subroutine does not return */
      FUN_1400172f8();
    }
    uVar2 = *param_3;
    hLibModule = (HMODULE)(&DAT_1400d1090)[uVar2];
    if (hLibModule == (HMODULE)0x0) {
      lpLibFileName = (LPCWSTR)(&PTR_u_api_ms_win_core_datetime_l1_1_1_140076f40)[uVar2];
      hLibModule = LoadLibraryExW(lpLibFileName,(HANDLE)0x0,0x800);
      if ((hLibModule != (HMODULE)0x0) ||
         ((((DVar3 = GetLastError(), DVar3 == 0x57 &&
            (iVar4 = FUN_14001ac60((ushort *)lpLibFileName,(ushort *)L"api-ms-",7), iVar4 != 0)) &&
           (iVar4 = FUN_14001ac60((ushort *)lpLibFileName,(ushort *)L"ext-ms-",7), iVar4 != 0)) &&
          (hLibModule = LoadLibraryExW(lpLibFileName,(HANDLE)0x0,0), hLibModule != (HMODULE)0x0))))
      {
        LOCK();
        lVar1 = (&DAT_1400d1090)[uVar2];
        (&DAT_1400d1090)[uVar2] = hLibModule;
        UNLOCK();
        if (lVar1 != 0) {
          FreeLibrary(hLibModule);
        }
        goto LAB_140017be0;
      }
      LOCK();
      (&DAT_1400d1090)[uVar2] = 0xffffffffffffffff;
      UNLOCK();
    }
    else if (hLibModule != (HMODULE)0xffffffffffffffff) {
LAB_140017be0:
      pFVar7 = GetProcAddress(hLibModule,param_2);
      goto LAB_140017b3a;
    }
    param_3 = param_3 + 1;
  } while( true );
}

