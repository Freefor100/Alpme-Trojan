/* address=140024270 rva=0x24270 */

void FUN_140024270(void)

{
  FUN_140017cd0(0);
  return;
}

