/* address=140016c98 rva=0x16c98 */

void FUN_140016c98(undefined8 *param_1)

{
  if ((undefined8 *)*param_1 != DAT_1400d0fc8) {
    FUN_140016cb4((undefined8 *)*param_1);
  }
  return;
}

