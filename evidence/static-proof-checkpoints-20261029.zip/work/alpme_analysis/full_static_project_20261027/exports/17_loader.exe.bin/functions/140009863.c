/* address=140009863 rva=0x9863 */

void FUN_140009863(int param_1,undefined8 param_2,int param_3,HMODULE param_4)

{
  undefined8 uVar1;
  HMODULE pHVar2;
  HMODULE pHVar3;
  
  uVar1 = *(undefined8 *)
           (*(longlong *)((longlong)ThreadLocalStoragePointer + (ulonglong)_tls_index * 8) + 0x98);
  pHVar3 = param_4;
  pHVar2 = (HMODULE)FUN_1400098d9();
  FUN_14000858c(((uint)uVar1 ^ 0x9db4d6ca) * param_1 + param_3,pHVar2,param_4,(uint *)pHVar3);
  return;
}

