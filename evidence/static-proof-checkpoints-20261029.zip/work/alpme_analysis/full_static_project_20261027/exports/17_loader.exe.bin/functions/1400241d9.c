/* address=1400241d9 rva=0x241d9 */

void FUN_1400241d9(undefined8 param_1,longlong param_2)

{
  FUN_140017cd0(**(int **)(param_2 + 0x58));
  return;
}

