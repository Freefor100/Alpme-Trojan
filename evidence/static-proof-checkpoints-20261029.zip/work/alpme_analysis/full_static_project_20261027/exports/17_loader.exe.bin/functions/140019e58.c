/* address=140019e58 rva=0x19e58 */

void FUN_140019e58(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x000140019e5c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  EnterCriticalSection(param_1 + 0x30);
  return;
}

