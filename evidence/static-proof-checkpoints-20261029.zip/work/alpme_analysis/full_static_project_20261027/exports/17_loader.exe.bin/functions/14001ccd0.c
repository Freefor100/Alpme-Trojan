/* address=14001ccd0 rva=0x1ccd0 */

void FUN_14001ccd0(longlong *param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_14001955c(param_1);
  param_1[3] = *(longlong *)(lVar1 + 0x90);
  param_1[4] = *(longlong *)(lVar1 + 0x88);
  FUN_14001e30c(lVar1,param_1 + 3,param_1[1]);
  FUN_14001e344(lVar1,param_1 + 4,param_1[1]);
  if ((*(uint *)(lVar1 + 0x3a8) & 2) == 0) {
    *(uint *)(lVar1 + 0x3a8) = *(uint *)(lVar1 + 0x3a8) | 2;
    *(undefined1 *)(param_1 + 5) = 2;
  }
  return;
}

