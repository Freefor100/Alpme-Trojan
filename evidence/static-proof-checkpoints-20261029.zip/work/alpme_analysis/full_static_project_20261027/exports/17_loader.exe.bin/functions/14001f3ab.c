/* address=14001f3ab rva=0x1f3ab */

undefined4 FUN_14001f3ab(undefined8 param_1,undefined8 param_2,longlong param_3,longlong param_4)

{
  longlong lVar1;
  uint uVar2;
  ulonglong uVar3;
  ulonglong *in_R11;
  
  lVar1 = param_4 + *(int *)(param_3 + 0x18);
  if (lVar1 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_1400172f8();
  }
  if (*(uint *)(param_3 + 0x14) != 0) {
    uVar3 = 0;
    do {
      if (*in_R11 < (ulonglong)(*(int *)(lVar1 + uVar3 * 8) + param_4)) break;
      uVar2 = (int)uVar3 + 1;
      uVar3 = (ulonglong)uVar2;
    } while (uVar2 < *(uint *)(param_3 + 0x14));
    if ((int)uVar3 != 0) {
      return *(undefined4 *)
              (param_4 + (ulonglong)((int)uVar3 - 1) * 8 + 4 + (longlong)*(int *)(param_3 + 0x18));
    }
  }
  return 0xffffffff;
}

