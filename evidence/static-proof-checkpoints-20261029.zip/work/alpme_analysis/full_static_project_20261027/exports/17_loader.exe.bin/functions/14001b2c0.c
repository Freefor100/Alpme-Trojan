/* address=14001b2c0 rva=0x1b2c0 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */

undefined8 FUN_14001b2c0(ulonglong param_1,longlong param_2,int *param_3)

{
  int iVar1;
  byte bVar2;
  undefined8 uVar3;
  longlong lVar4;
  code *pcVar5;
  byte bVar6;
  uint uVar7;
  byte *pbVar8;
  byte *pbVar9;
  ulonglong uVar10;
  uint *puVar11;
  uint uVar12;
  int *piVar13;
  ulonglong uVar14;
  longlong *unaff_R14;
  ULONG_PTR unaff_R15;
  undefined4 in_stack_00000090;
  undefined8 in_stack_00000098;
  byte in_stack_000000a0;
  
  if (((longlong)*param_3 & 4U) == 0) {
    uVar10 = param_1;
  }
  else {
    uVar10 = (longlong)param_3[1] + param_1 & (longlong)-param_3[2];
  }
  pbVar8 = (byte *)(*(longlong *)(param_2 + 8) +
                   (ulonglong)*(uint *)(*(longlong *)(param_2 + 0x10) + 8));
  bVar6 = pbVar8[3];
  if ((*pbVar8 & 7) < 3) {
    if ((bVar6 & 0xf) != 0) {
LAB_14001b431:
      uVar14 = (ulonglong)bVar6 & 0xfffffffffffffff0;
      goto LAB_14001b435;
    }
  }
  else {
    uVar12 = bVar6 & 0x1f;
    piVar13 = (int *)(ulonglong)uVar12;
    if ((bVar6 & 0x1f) != 0) {
      if ((*pbVar8 & 0x40) == 0) {
        lVar4 = (ulonglong)uVar12 + 4;
      }
      else {
        lVar4 = (longlong)piVar13 * 2 + 5;
      }
      pbVar8 = pbVar8 + lVar4;
      uVar14 = 0;
      uVar7 = 0;
      pbVar9 = pbVar8;
      if (bVar6 >> 5 != 0) {
        do {
          pbVar8 = pbVar9 + 3;
          bVar2 = *pbVar9 >> 3;
          if (bVar2 != 0) {
            if ((*pbVar9 & 2) == 0) {
              pbVar8 = pbVar9 + (ulonglong)bVar2 + 6;
            }
            else {
              pbVar8 = pbVar8 + (ulonglong)bVar2 * 2 + 4;
            }
          }
          uVar7 = uVar7 + 1;
          pbVar9 = pbVar8;
        } while (uVar7 < bVar6 >> 5);
      }
      uVar7 = 0;
      if ((bVar6 & 0x1f) != 0) {
        do {
          bVar6 = *pbVar8;
          if (bVar6 < 4) {
LAB_14001b3df:
            if (bVar6 == 0) {
              bVar6 = pbVar8[1];
              goto LAB_14001b431;
            }
            if (0x20 < bVar6) goto switchD_14001b3ff_caseD_4;
          }
          else {
            bVar2 = bVar6 & 0xf;
            if (((byte)((bVar6 & 0xf) - 8) < 3) || (bVar2 = bVar6 & 7, (byte)((bVar6 & 7) - 4) < 4))
            {
              bVar6 = bVar2;
              goto LAB_14001b3df;
            }
            if ((bVar6 & 0x3f) != 0x20) goto switchD_14001b3ff_caseD_4;
            bVar6 = 0x20;
          }
          bVar6 = *(byte *)((longlong)&UINT_14001b478 + (ulonglong)bVar6);
                    /* WARNING (jumptable): Sanity check requires truncation of jumptable */
                    /* WARNING: Could not find normalized switch variable to match jumptable */
          switch(bVar6) {
          case 0:
            lVar4 = 2;
            break;
          case 1:
            lVar4 = 5;
            break;
          case 2:
            lVar4 = 3;
            break;
          case 3:
            lVar4 = 1;
            break;
          case 4:
switchD_14001b3ff_caseD_4:
            FUN_14001ab70();
            pcVar5 = (code *)swi(3);
            uVar3 = (*pcVar5)();
            return uVar3;
          case 5:
            puVar11 = (uint *)(ulonglong)bVar6;
            *(uint *)(pbVar8 + 0x12) =
                 (*(int *)(pbVar8 + 0x12) - (int)param_1) -
                 (uint)(0xfffffffebfffffff <
                       (ulonglong)(&switchD_14001b3ff::switchdataD_14001b464)[bVar6]);
            uVar12 = puVar11[8];
            if (((uVar12 != 0) && (lVar4 = FUN_14001a6c0(), lVar4 + (int)uVar12 != 0)) ||
               ((0x19930521 < (*puVar11 & 0x1fffffff) && ((puVar11[9] & 4) != 0)))) {
              if ((((*piVar13 == -0x1f928c9d) && (2 < (uint)piVar13[6])) &&
                  (0x19930522 < (uint)piVar13[8])) &&
                 (iVar1 = *(int *)(*(longlong *)(piVar13 + 0xc) + 8), iVar1 != 0)) {
                lVar4 = FUN_14001a700();
                pcVar5 = (code *)(lVar4 + iVar1);
                if (pcVar5 != (code *)0x0) {
                  uVar3 = (*pcVar5)(piVar13);
                  return uVar3;
                }
              }
              FUN_140020200(piVar13,unaff_R14,unaff_R15,(ulonglong *)param_1,puVar11,
                            in_stack_000000a0,in_stack_00000090,in_stack_00000098);
            }
            return 1;
          }
          pbVar8 = pbVar8 + lVar4;
          uVar7 = uVar7 + 1;
        } while (uVar7 < uVar12);
      }
      goto LAB_14001b435;
    }
  }
  uVar14 = 0;
LAB_14001b435:
  uVar3 = FUN_14001b4d0(uVar14 + param_1 ^
                        *(ulonglong *)(((longlong)*param_3 & 0xfffffffffffffff8U) + uVar10));
  return uVar3;
}

