/* address=140022400 rva=0x22400 */

void _guard_check_icall(void)

{
  _guard_check_icall();
  return;
}

