/* address=14001783c rva=0x1783c */

void FUN_14001783c(void)

{
  (*(code *)0x0)();
  return;
}

