/* address=14001a700 rva=0x1a700 */

undefined8 FUN_14001a700(void)

{
  PVOID pvVar1;
  
  pvVar1 = FUN_1400173f0();
  return *(undefined8 *)((longlong)pvVar1 + 0x68);
}

