/* address=14001fa89 rva=0x1fa89 */

undefined1 FUN_14001fa89(void)

{
  int iVar1;
  int iVar2;
  uint *puVar3;
  longlong in_RAX;
  longlong lVar4;
  longlong lVar5;
  undefined8 uVar6;
  int iVar7;
  undefined8 unaff_RBX;
  undefined8 unaff_RBP;
  longlong unaff_RSI;
  undefined1 unaff_DIL;
  undefined8 unaff_R12;
  int *unaff_R13;
  undefined8 unaff_R14;
  int *piVar8;
  int unaff_R15D;
  longlong in_stack_00000060;
  undefined1 in_stack_00000068;
  
  *(undefined8 *)(in_RAX + 0x18) = unaff_RBX;
  *(undefined8 *)(in_RAX + -0x18) = unaff_RBP;
  *(undefined8 *)(in_RAX + -0x28) = unaff_R12;
  *(undefined8 *)(in_RAX + -0x30) = unaff_R14;
  do {
    iVar7 = *(int *)(*(longlong *)(unaff_RSI + 0x30) + 0xc);
    lVar4 = FUN_14001a700();
    piVar8 = (int *)((longlong)iVar7 + lVar4 + 4);
    iVar7 = *(int *)(*(longlong *)(unaff_RSI + 0x30) + 0xc);
    lVar4 = FUN_14001a700();
    iVar7 = *(int *)(lVar4 + iVar7);
    if (0 < iVar7) {
      do {
        iVar1 = *piVar8;
        lVar4 = FUN_14001a700();
        puVar3 = *(uint **)(unaff_RSI + 0x30);
        iVar2 = unaff_R13[1];
        lVar5 = FUN_14001a6c0();
        uVar6 = FUN_14001fc00((byte *)(lVar5 + (longlong)unaff_R15D * 0x14 + (longlong)iVar2),
                              (byte *)(iVar1 + lVar4),puVar3);
        unaff_RSI = in_stack_00000060;
        if ((int)uVar6 != 0) {
          unaff_DIL = 1;
          in_stack_00000068 = 1;
          goto LAB_14001fb1c;
        }
        iVar7 = iVar7 + -1;
        piVar8 = piVar8 + 1;
      } while (0 < iVar7);
      unaff_DIL = in_stack_00000068;
    }
LAB_14001fb1c:
    unaff_R15D = unaff_R15D + 1;
    if (*unaff_R13 <= unaff_R15D) {
      return unaff_DIL;
    }
  } while( true );
}

