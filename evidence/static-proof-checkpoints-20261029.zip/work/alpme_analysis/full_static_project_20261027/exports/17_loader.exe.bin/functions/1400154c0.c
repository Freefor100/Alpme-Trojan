/* address=1400154c0 rva=0x154c0 */

undefined * FUN_1400154c0(void)

{
  return &DAT_1400d0e00;
}

