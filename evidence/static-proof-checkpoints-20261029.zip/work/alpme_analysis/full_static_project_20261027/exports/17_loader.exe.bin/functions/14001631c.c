/* address=14001631c rva=0x1631c */

void FUN_14001631c(undefined8 param_1,int *param_2,undefined8 param_3,int *param_4)

{
  undefined **ppuVar1;
  longlong *plVar2;
  
  FUN_140017cb4(*param_2);
  for (plVar2 = &DAT_1400d1818; plVar2 != (longlong *)&DAT_1400d1820; plVar2 = plVar2 + 1) {
    if ((undefined **)*plVar2 != &PTR_DAT_1400d0880) {
      ppuVar1 = FUN_14001b258(plVar2,&PTR_DAT_1400d0880);
      *plVar2 = (longlong)ppuVar1;
    }
  }
  FUN_140017cd0(*param_4);
  return;
}

