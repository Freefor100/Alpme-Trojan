/* address=140017bfc rva=0x17bfc */

/* WARNING: Removing unreachable block (ram,0x000140017c11) */
/* WARNING: Removing unreachable block (ram,0x000140017c09) */

FARPROC FUN_140017bfc(void)

{
  FARPROC pFVar1;
  
  pFVar1 = FUN_140017a48(1,"CompareStringEx",(uint *)&DAT_140077000,(uint *)&DAT_140077008);
  return pFVar1;
}

