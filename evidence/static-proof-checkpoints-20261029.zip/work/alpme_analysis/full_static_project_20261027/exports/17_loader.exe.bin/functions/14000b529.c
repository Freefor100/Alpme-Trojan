/* address=14000b529 rva=0xb529 */

ulonglong FUN_14000b529(uint *param_1,ushort *param_2)

{
  undefined8 uVar1;
  bool bVar2;
  char cVar3;
  uint uVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong lVar7;
  ushort uVar8;
  uint uVar9;
  ushort uVar10;
  ushort uVar11;
  longlong lVar12;
  uint uVar13;
  ulonglong uVar14;
  undefined7 uVar15;
  ulonglong uVar16;
  undefined1 *puVar17;
  undefined1 uStack_5f;
  undefined2 uStack_5e;
  undefined1 auStack_5b [11];
  undefined8 local_50;
  undefined4 local_48;
  
  uVar4 = *param_1;
  uVar9 = -uVar4;
  if ((int)-uVar4 < 0) {
    uVar9 = uVar4;
  }
  lVar6 = 10;
  uVar13 = uVar9;
  if (999 < uVar9) {
    do {
      uVar9 = uVar13 / 10000;
      *(undefined2 *)(auStack_5b + lVar6 + -3) =
           *(undefined2 *)(&DAT_140074987 + (ulonglong)((uVar13 % 10000) / 100) * 2);
      *(undefined2 *)(auStack_5b + lVar6 + -1) =
           *(undefined2 *)(&DAT_140074987 + (ulonglong)((uVar13 % 10000) % 100) * 2);
      lVar6 = lVar6 + -4;
      bVar2 = 9999999 < uVar13;
      uVar13 = uVar13 / 10000;
    } while (bVar2);
  }
  uVar13 = uVar9;
  if (9 < uVar9) {
    uVar13 = (uVar9 & 0xffff) / 100;
    *(undefined2 *)(auStack_5b + lVar6 + -1) =
         *(undefined2 *)(&DAT_140074987 + (ulonglong)(uVar9 + uVar13 * -100 & 0xffff) * 2);
    lVar6 = lVar6 + -2;
  }
  if ((uVar4 == 0) || (uVar13 != 0)) {
    auStack_5b[lVar6] = (&DAT_140074988)[(ulonglong)(uVar13 & 0xf) * 2];
    lVar6 = lVar6 + -1;
  }
  lVar12 = 10 - lVar6;
  if ((int)uVar4 < 0) {
    uVar14 = 0xb - lVar6;
    uVar4 = *(uint *)(param_2 + 2);
    uVar9 = 0x2d;
  }
  else {
    uVar4 = *(uint *)(param_2 + 2);
    uVar9 = -(uint)((uVar4 & 0x200000) == 0) | 0x2b;
    uVar14 = (ulonglong)((uVar4 & 0x200000) >> 0x15) + lVar12;
  }
  uVar16 = (ulonglong)(uVar4 >> 0x17 & 1);
  puVar17 = auStack_5b + lVar6 + 1;
  uVar8 = *param_2;
  uVar15 = (undefined7)(uVar14 >> 8);
  if (uVar14 < uVar8) {
    if ((uVar4 >> 0x18 & 1) == 0) {
      uVar13 = (uint)uVar8 - (int)uVar14;
      uVar14 = CONCAT71(uVar15,1);
      uVar4 = FUN_14000b9a0((longlong)param_2,uVar13,'\x01');
      uVar8 = (ushort)uVar13;
      if (uVar4 != 0xffffffff) {
        uVar1 = *(undefined8 *)(param_2 + 8);
        lVar6 = *(longlong *)(param_2 + 0xc);
        uVar5 = FUN_140012e76(uVar1,lVar6,uVar9,uVar16);
        if (((char)uVar5 == '\0') &&
           (cVar3 = (**(code **)(lVar6 + 0x18))(uVar1,puVar17,lVar12), cVar3 == '\0')) {
          uVar10 = 0xffff;
          do {
            uVar11 = uVar8;
            if ((ushort)(uVar10 - uVar8) == -1) break;
            cVar3 = (**(code **)(lVar6 + 0x20))(uVar1,uVar4);
            uVar11 = uVar10 + 1;
            uVar10 = uVar11;
          } while (cVar3 == '\0');
          uVar14 = CONCAT71(uVar15,uVar11 < uVar8);
        }
      }
    }
    else {
      local_48 = *(undefined4 *)(param_2 + 4);
      local_50 = *(undefined8 *)param_2;
      *(uint *)(param_2 + 2) = uVar4 & 0x9fe00000 | 0x20000030;
      uVar1 = *(undefined8 *)(param_2 + 8);
      lVar6 = *(longlong *)(param_2 + 0xc);
      lVar7 = lVar6;
      uVar5 = FUN_140012e76(uVar1,lVar6,uVar9,uVar16);
      if ((char)uVar5 == '\0') {
        uVar9 = (uint)CONCAT62((int6)((ulonglong)lVar7 >> 0x10),uVar8 - (short)uVar14);
        uVar4 = FUN_14000b9a0((longlong)param_2,uVar9,'\x01');
        if (uVar4 != 0xffffffff) {
          cVar3 = (**(code **)(lVar6 + 0x18))(uVar1,puVar17,lVar12);
          if (cVar3 == '\0') {
            uVar9 = (uVar9 & 0xffff) + 1;
            do {
              uVar8 = (short)uVar9 - 1;
              uVar9 = (uint)uVar8;
              if (uVar8 == 0) {
                *(undefined4 *)(param_2 + 4) = local_48;
                *(undefined8 *)param_2 = local_50;
                uVar14 = 0;
                goto LAB_14000b734;
              }
              cVar3 = (**(code **)(lVar6 + 0x20))(uVar1,uVar4);
            } while (cVar3 == '\0');
          }
        }
      }
      uVar14 = CONCAT71(uVar15,1);
    }
  }
  else {
    uVar1 = *(undefined8 *)(param_2 + 8);
    lVar6 = *(longlong *)(param_2 + 0xc);
    uVar5 = FUN_140012e76(uVar1,lVar6,uVar9,uVar16);
    uVar14 = CONCAT71(uVar15,1);
    if ((char)uVar5 == '\0') {
      uVar4 = (**(code **)(lVar6 + 0x18))(uVar1,puVar17,lVar12);
      uVar14 = (ulonglong)uVar4;
    }
  }
LAB_14000b734:
  return uVar14 & 0xffffffff;
}

