/* address=1400017d8 rva=0x17d8 */

uint FUN_1400017d8(uint param_1)

{
  return param_1 >> 0x1f;
}

