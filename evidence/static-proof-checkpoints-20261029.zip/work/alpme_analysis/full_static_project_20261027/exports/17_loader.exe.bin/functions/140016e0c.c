/* address=140016e0c rva=0x16e0c */

undefined8 FUN_140016e0c(void)

{
  int iVar1;
  undefined8 uVar2;
  byte *pbVar3;
  longlong *plVar4;
  
  plVar4 = DAT_1400d0fc0;
  if (DAT_1400d0fc0 == (longlong *)0x0) {
LAB_140016e35:
    uVar2 = 0xffffffff;
  }
  else {
    for (; *plVar4 != 0; plVar4 = plVar4 + 1) {
      iVar1 = FUN_14001c2e8(0,0,*plVar4,0xffffffff);
      if (iVar1 == 0) goto LAB_140016e35;
      pbVar3 = FUN_14001ab80((longlong)iVar1,1);
      if (pbVar3 == (byte *)0x0) {
        pbVar3 = (byte *)0x0;
LAB_140016ee0:
        FUN_1400191b0(pbVar3);
        goto LAB_140016e35;
      }
      iVar1 = FUN_14001c2e8(0,0,*plVar4,0xffffffff);
      if (iVar1 == 0) goto LAB_140016ee0;
      thunk_FUN_14001c4e0(pbVar3,0);
      FUN_1400191b0((LPVOID)0x0);
    }
    uVar2 = 0;
  }
  return uVar2;
}

