/* address=14001b1b0 rva=0x1b1b0 */

void FUN_14001b1b0(undefined **param_1)

{
  if (((param_1 != (undefined **)0x0) && (param_1 != &PTR_DAT_1400770c0)) &&
     (*(int *)((longlong)param_1 + 0x15c) == 0)) {
    FUN_14001aa28(param_1);
    FUN_1400191b0(param_1);
  }
  return;
}

