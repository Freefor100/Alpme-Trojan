/* address=14001c1b8 rva=0x1c1b8 */

void FUN_14001c1b8(uint param_1)

{
  FUN_14001c1cc((undefined4 *)0x0,param_1,0,4);
  return;
}

