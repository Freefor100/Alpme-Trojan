/* address=14001a5da rva=0x1a5da */

void FUN_14001a5da(undefined8 param_1,uint param_2,undefined8 param_3,uint param_4,
                  undefined8 param_5)

{
  longlong lVar1;
  ulonglong uVar2;
  longlong unaff_RBX;
  uint unaff_EBP;
  int unaff_ESI;
  uint uVar3;
  longlong lVar4;
  uint uVar5;
  int in_R10D;
  longlong in_R11;
  undefined8 unaff_R12;
  undefined8 *unaff_R14;
  
  lVar1 = in_R11 + unaff_RBX;
  while( true ) {
    uVar3 = param_2 - 1;
    if ((*(int *)(in_R11 + (ulonglong)uVar3 * 0x14 + 4 + unaff_RBX) < in_R10D) &&
       (in_R10D <= *(int *)(lVar1 + 8 + (ulonglong)uVar3 * 0x14))) break;
    param_2 = uVar3;
    if (uVar3 == 0) {
      lVar4 = 0;
LAB_14001a61c:
      uVar3 = 0;
      uVar5 = param_4;
      do {
        uVar2 = (ulonglong)uVar3;
        if ((((lVar4 == 0) ||
             ((*(int *)(lVar4 + 4) < *(int *)(lVar1 + uVar2 * 0x14) &&
              (*(int *)(lVar1 + 4 + uVar2 * 0x14) <= *(int *)(lVar4 + 8))))) &&
            (*(int *)(lVar1 + uVar2 * 0x14) <= unaff_ESI)) &&
           (unaff_ESI <= *(int *)(lVar1 + 4 + uVar2 * 0x14))) {
          param_4 = uVar3;
          if (uVar5 == 0xffffffff) {
            uVar5 = uVar3;
          }
        }
        uVar3 = uVar3 + 1;
      } while (uVar3 < unaff_EBP);
      *unaff_R14 = unaff_R12;
      unaff_R14[2] = unaff_R12;
      uVar3 = 0;
      if (uVar5 != 0xffffffff) {
        uVar3 = uVar5;
      }
      *(uint *)(unaff_R14 + 1) = uVar3;
      *(undefined4 *)((longlong)unaff_R14 + 0xc) = param_5._4_4_;
      uVar3 = 0;
      if (uVar5 != 0xffffffff) {
        uVar3 = param_4 + 1;
      }
      *(undefined4 *)((longlong)unaff_R14 + 0x1c) = param_5._4_4_;
      *(uint *)(unaff_R14 + 3) = uVar3;
      return;
    }
  }
  lVar4 = in_R11 + (ulonglong)(param_2 - 1) * 0x14 + unaff_RBX;
  goto LAB_14001a61c;
}

