/* address=140016ab8 rva=0x16ab8 */

ulonglong FUN_140016ab8(undefined8 param_1,int *param_2,undefined8 *param_3,int *param_4)

{
  ulonglong uVar1;
  
  FUN_140017cb4(*param_2);
  uVar1 = FUN_1400167f0(param_3);
  FUN_140017cd0(*param_4);
  return uVar1 & 0xffffffff;
}

