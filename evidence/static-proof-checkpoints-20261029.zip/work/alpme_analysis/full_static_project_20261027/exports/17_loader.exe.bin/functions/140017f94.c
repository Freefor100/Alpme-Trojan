/* address=140017f94 rva=0x17f94 */

void FUN_140017f94(undefined8 *param_1)

{
  undefined1 local_res10 [8];
  int local_res18 [2];
  int local_res20 [2];
  int local_38 [2];
  undefined8 *local_30;
  undefined8 *local_28;
  undefined8 **local_20;
  undefined8 **local_18;
  undefined8 **local_10;
  
  local_20 = &local_30;
  local_res18[0] = 5;
  local_res20[0] = 5;
  local_18 = &local_30;
  local_10 = &local_28;
  local_38[0] = 4;
  local_38[1] = 4;
  local_28 = &DAT_1400d1818;
  *(undefined4 *)(param_1 + 5) = 1;
  *param_1 = &DAT_140076740;
  *(undefined4 *)(param_1 + 0x75) = 1;
  param_1[0x11] = &DAT_1400d0340;
  *(undefined2 *)((longlong)param_1 + 0xbc) = 0x43;
  *(undefined2 *)((longlong)param_1 + 0x1c2) = 0x43;
  param_1[0x74] = 0;
  local_30 = param_1;
  FUN_140018214(local_res10,local_res20,&local_20,local_res18);
  FUN_140018254(local_res10,local_38 + 1,&local_18,local_38);
  return;
}

