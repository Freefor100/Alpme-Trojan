/* address=140017650 rva=0x17650 */

undefined1 FUN_140017650(void)

{
  uint uVar1;
  ulonglong uVar2;
  
  uVar2 = (ulonglong)DAT_1400d1088;
  uVar1 = DAT_1400d1088;
  while (uVar1 != 0) {
    uVar1 = (int)uVar2 - 1;
    uVar2 = (ulonglong)uVar1;
    DeleteCriticalSection((LPCRITICAL_SECTION)(&DAT_1400d1060 + uVar2 * 0x28));
    DAT_1400d1088 = DAT_1400d1088 - 1;
  }
  return 1;
}

