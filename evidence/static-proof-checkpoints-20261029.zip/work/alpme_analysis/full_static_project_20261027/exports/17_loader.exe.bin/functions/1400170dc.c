/* address=1400170dc rva=0x170dc */

undefined8 FUN_1400170dc(int param_1)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  if (((param_1 - 0x4000U & 0xffff3fff) == 0) && (param_1 != 0xc000)) {
    LOCK();
    UNLOCK();
    uVar2 = 0;
    DAT_1400d1848 = param_1;
  }
  else {
    puVar1 = FUN_140019fec();
    *(undefined4 *)puVar1 = 0x16;
    FUN_1400192c4();
    uVar2 = 0x16;
  }
  return uVar2;
}

