/* address=140017d58 rva=0x17d58 */

ulonglong FUN_140017d58(void)

{
  undefined4 uVar1;
  undefined4 extraout_var;
  ulonglong uVar2;
  undefined8 *puVar3;
  undefined4 extraout_var_00;
  
  DAT_1400d13b8 = FUN_140017a04();
  DAT_1400d0338 = FlsAlloc(FUN_140017f0c);
  uVar2 = CONCAT44(extraout_var,DAT_1400d0338);
  if (DAT_1400d0338 != 0xffffffff) {
    puVar3 = FUN_140017e20();
    if (puVar3 != (undefined8 *)0x0) {
      return CONCAT71((int7)((ulonglong)puVar3 >> 8),1);
    }
    uVar1 = FUN_140017d9c();
    uVar2 = CONCAT44(extraout_var_00,uVar1);
  }
  return uVar2 & 0xffffffffffffff00;
}

