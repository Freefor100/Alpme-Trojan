/* address=140022450 rva=0x22450 */

void FUN_140022450(void)

{
  code *pcVar1;
  
  pcVar1 = (code *)FUN_140017280();
  (*pcVar1)();
  FUN_1400172b0();
  FUN_140017280();
  return;
}

