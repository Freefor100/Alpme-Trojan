/* address=140018064 rva=0x18064 */

void FUN_140018064(undefined8 *param_1)

{
  undefined1 local_res10 [8];
  int local_res18 [2];
  int local_res20 [2];
  int local_28 [2];
  undefined8 *local_20;
  undefined8 **local_18;
  undefined8 **local_10;
  
  local_18 = &local_20;
  local_res18[0] = 5;
  local_res20[0] = 5;
  local_10 = &local_20;
  local_28[0] = 4;
  local_28[1] = 4;
  local_20 = param_1;
  if ((undefined *)*param_1 != &DAT_140076740) {
    FUN_1400191b0((undefined *)*param_1);
  }
  FUN_1400191b0((LPVOID)local_20[0xe]);
  FUN_1400191b0((LPVOID)local_20[0xb]);
  FUN_1400191b0((LPVOID)local_20[0xc]);
  FUN_1400191b0((LPVOID)local_20[0xd]);
  FUN_1400191b0((LPVOID)local_20[9]);
  FUN_1400191b0((LPVOID)local_20[10]);
  FUN_1400191b0((LPVOID)local_20[0xf]);
  FUN_1400191b0((LPVOID)local_20[0x10]);
  FUN_1400191b0((LPVOID)local_20[0x78]);
  FUN_14001829c(local_res10,local_res20,&local_18,local_res18);
  FUN_1400182fc(local_res10,local_28 + 1,&local_10,local_28);
  return;
}

