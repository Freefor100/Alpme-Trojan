/* address=14001b4d0 rva=0x1b4d0 */

void FUN_14001b4d0(longlong param_1)

{
  if ((param_1 == DAT_1400d02c0) && ((short)((ulonglong)param_1 >> 0x30) == 0)) {
    return;
  }
  FUN_14001ab70();
  return;
}

