/* address=140017c34 rva=0x17c34 */

ulonglong FUN_140017c34(void)

{
  BOOL BVar1;
  undefined4 extraout_var;
  ulonglong uVar2;
  uint uVar3;
  
  uVar2 = 0;
  do {
    BVar1 = InitializeCriticalSectionEx((LPCRITICAL_SECTION)(&DAT_1400d1150 + uVar2 * 0x28),4000,0);
    if (BVar1 == 0) {
      uVar2 = FUN_140017c7c();
      return uVar2 & 0xffffffffffffff00;
    }
    DAT_1400d13a8 = DAT_1400d13a8 + 1;
    uVar3 = (int)uVar2 + 1;
    uVar2 = (ulonglong)uVar3;
  } while (uVar3 < 0xf);
  return CONCAT71((int7)(CONCAT44(extraout_var,BVar1) >> 8),1);
}

