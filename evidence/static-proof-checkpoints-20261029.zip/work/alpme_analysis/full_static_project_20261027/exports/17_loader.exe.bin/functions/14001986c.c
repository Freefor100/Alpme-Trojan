/* address=14001986c rva=0x1986c */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */

undefined8 FUN_14001986c(uint param_1)

{
  bool bVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  byte bVar7;
  code *pcVar8;
  ulonglong *puVar9;
  undefined4 local_res10;
  
  plVar2 = (longlong *)0x0;
  local_res10 = 0;
  bVar1 = true;
  if (param_1 == 2) {
LAB_1400198c3:
    if (param_1 == 2) {
      puVar9 = (ulonglong *)&DAT_1400d17f8;
    }
    else if (param_1 == 6) {
LAB_140019965:
      puVar9 = &DAT_1400d1808;
    }
    else if (param_1 == 0xf) {
      puVar9 = (ulonglong *)&DAT_1400d1810;
    }
    else if (param_1 == 0x15) {
      puVar9 = (ulonglong *)&DAT_1400d1800;
    }
    else {
      if (param_1 == 0x16) goto LAB_140019965;
      puVar9 = (ulonglong *)0x0;
    }
  }
  else {
    if (param_1 != 4) {
      if (param_1 != 6) {
        if ((param_1 == 8) || (param_1 == 0xb)) goto LAB_1400198f3;
        if ((param_1 != 0xf) && ((param_1 != 0x15 && (param_1 != 0x16)))) goto LAB_140019945;
      }
      goto LAB_1400198c3;
    }
LAB_1400198f3:
    plVar2 = FUN_140017e20();
    if (plVar2 == (longlong *)0x0) {
      return 0xffffffff;
    }
    lVar6 = *plVar2;
    lVar4 = lVar6 + 0xc0;
    for (; lVar6 != lVar4; lVar6 = lVar6 + 0x10) {
      if (*(uint *)(lVar6 + 4) == param_1) goto LAB_140019940;
    }
    lVar6 = 0;
LAB_140019940:
    if (lVar6 == 0) {
LAB_140019945:
      puVar3 = FUN_140019fec();
      *(undefined4 *)puVar3 = 0x16;
      FUN_1400192c4();
      return 0xffffffff;
    }
    puVar9 = (ulonglong *)(lVar6 + 8);
    bVar1 = false;
  }
  lVar6 = 0;
  if (bVar1) {
    FUN_140017cb4(3);
  }
  pcVar8 = (code *)*puVar9;
  if (bVar1) {
    bVar7 = (byte)DAT_1400d02c0 & 0x3f;
    pcVar8 = (code *)(((ulonglong)pcVar8 ^ DAT_1400d02c0) >> bVar7 |
                     ((ulonglong)pcVar8 ^ DAT_1400d02c0) << 0x40 - bVar7);
  }
  if (pcVar8 == (code *)0x1) goto LAB_140019a4e;
  if (pcVar8 == (code *)0x0) {
    if (bVar1) {
      FUN_140017cd0(3);
    }
                    /* WARNING: Subroutine does not return */
    FUN_140015f94(3);
  }
  if ((param_1 < 0xc) && ((0x910U >> (param_1 & 0x1f) & 1) != 0)) {
    lVar6 = plVar2[1];
    plVar2[1] = 0;
    if (param_1 == 8) {
      lVar4 = FUN_140017dc0();
      local_res10 = *(undefined4 *)(lVar4 + 0x10);
      lVar4 = FUN_140017dc0();
      *(undefined4 *)(lVar4 + 0x10) = 0x8c;
      goto LAB_140019a06;
    }
  }
  else {
LAB_140019a06:
    if (param_1 == 8) {
      lVar4 = *plVar2;
      for (lVar5 = lVar4 + 0x30; lVar5 != lVar4 + 0xc0; lVar5 = lVar5 + 0x10) {
        *(undefined8 *)(lVar5 + 8) = 0;
      }
      goto LAB_140019a4e;
    }
  }
  *puVar9 = DAT_1400d02c0;
LAB_140019a4e:
  if (bVar1) {
    FUN_140017cd0(3);
  }
  if (pcVar8 != (code *)0x1) {
    if (param_1 == 8) {
      lVar4 = FUN_140017dc0();
      (*pcVar8)(8,*(undefined4 *)(lVar4 + 0x10));
    }
    else {
      (*pcVar8)(param_1);
    }
    if (((param_1 < 0xc) && ((0x910U >> (param_1 & 0x1f) & 1) != 0)) &&
       (plVar2[1] = lVar6, param_1 == 8)) {
      lVar6 = FUN_140017dc0();
      *(undefined4 *)(lVar6 + 0x10) = local_res10;
    }
  }
  return 0;
}

