/* address=140019f90 rva=0x19f90 */

void FUN_140019f90(char param_1)

{
  longlong lVar1;
  
  thunk_FUN_140019c78(param_1);
  FUN_14001f154();
  lVar1 = 0;
  do {
    FUN_14001f208(*(undefined8 **)(lVar1 + (longlong)DAT_1400d1828));
    DeleteCriticalSection
              ((LPCRITICAL_SECTION)(*(longlong *)(lVar1 + (longlong)DAT_1400d1828) + 0x30));
    lVar1 = lVar1 + 8;
  } while (lVar1 != 0x18);
  FUN_1400191b0(DAT_1400d1828);
  DAT_1400d1828 = (LPVOID)0x0;
  return;
}

