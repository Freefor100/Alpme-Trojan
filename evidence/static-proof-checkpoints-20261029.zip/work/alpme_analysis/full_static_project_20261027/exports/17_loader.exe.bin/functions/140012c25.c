/* address=140012c25 rva=0x12c25 */

undefined8 FUN_140012c25(HANDLE param_1,LPCSTR param_2,ulonglong param_3)

{
  code *pcVar1;
  uint uVar2;
  longlong lVar3;
  ulonglong uVar4;
  longlong lVar5;
  undefined8 uVar6;
  void *pvVar7;
  void *pvVar8;
  void *pvVar9;
  int aiStackX_8 [4];
  ushort auStackX_18 [8];
  undefined8 uStack_28;
  
  uStack_28 = 0x140012c34;
  lVar3 = FUN_140014e00();
  lVar3 = -lVar3;
  if (((0x1000 < param_3) && (param_3 = 0x1000, param_2[0x1000] < -0x40)) &&
     (param_3 = 0xfff, param_2[0xfff] < -0x40)) {
    if (param_2[(ulonglong)(-0x41 < param_2[0xffe]) + 0xffd] < -0x40) goto LAB_140012dad;
    param_3 = (ulonglong)(-0x41 < param_2[0xffe]) + 0xffd;
  }
  *(longlong *)((longlong)aiStackX_8 + lVar3 + -8) = (longlong)auStackX_18 + lVar3;
  *(undefined4 *)((longlong)aiStackX_8 + lVar3) = 0x1000;
  *(undefined8 *)((longlong)auStackX_18 + lVar3 + -0x40) = 0x140012cb0;
  uVar2 = MultiByteToWideChar(0xfde9,8,param_2,(int)param_3,
                              *(LPWSTR *)((longlong)aiStackX_8 + lVar3 + -8),
                              *(int *)((longlong)aiStackX_8 + lVar3));
  if ((uVar2 == 0) || (0x1000 < uVar2)) goto LAB_140012dad;
  pvVar9 = (void *)(longlong)(int)uVar2;
  pvVar8 = (void *)((longlong)auStackX_18 + lVar3);
  *(undefined8 *)((longlong)auStackX_18 + lVar3 + -0x40) = 0x140012cd7;
  uVar4 = FUN_140001934(param_1,pvVar8,uVar2);
  if ((uVar4 & 1) == 0) {
    if (pvVar9 != pvVar8) {
      if (pvVar9 <= pvVar8) {
LAB_140012dad:
                    /* WARNING: Does not return */
        pcVar1 = (code *)invalidInstructionException();
        (*pcVar1)();
      }
      pvVar7 = (void *)((longlong)auStackX_18 + (longlong)pvVar8 * 2 + lVar3);
      if ((*(ushort *)((longlong)auStackX_18 + (longlong)pvVar8 * 2 + lVar3) & 0xfc00) == 0xdc00) {
        pvVar8 = (void *)((longlong)pvVar8 + 1);
        *(undefined8 *)((longlong)auStackX_18 + lVar3 + -0x40) = 0x140012d1b;
        lVar5 = FUN_140001934(param_1,pvVar7,1);
        if (((lVar5 != 0) && (1 < ((uint)pvVar7 & 3) - 2)) && (((ulonglong)pvVar7 & 3) != 0)) {
          pcVar1 = *(code **)((longlong)pvVar7 + 7);
          *(undefined8 *)((longlong)auStackX_18 + lVar3 + -0x40) = 0x140012d39;
          (*pcVar1)();
        }
      }
      if (pvVar9 < pvVar8) goto LAB_140012dad;
      if (pvVar8 != (void *)0x0) {
        lVar3 = 0;
        do {
          lVar3 = lVar3 + 2;
        } while ((longlong)pvVar8 * 2 != lVar3);
      }
    }
    uVar6 = 0;
  }
  else {
    uVar6 = 1;
  }
  return uVar6;
}

