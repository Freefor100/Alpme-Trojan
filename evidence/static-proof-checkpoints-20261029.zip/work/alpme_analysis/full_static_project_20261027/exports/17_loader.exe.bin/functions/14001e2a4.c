/* address=14001e2a4 rva=0x1e2a4 */

void FUN_14001e2a4(longlong param_1,longlong *param_2)

{
  undefined **ppuVar1;
  
  if ((*param_2 != DAT_1400d1818) && ((DAT_1400d0ba0 & *(uint *)(param_1 + 0x3a8)) == 0)) {
    ppuVar1 = FUN_14001b1e8();
    *param_2 = (longlong)ppuVar1;
  }
  return;
}

