/* address=140015420 rva=0x15420 */

undefined8 FUN_140015420(void)

{
  return 1;
}

