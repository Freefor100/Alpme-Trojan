/* address=14001a6c0 rva=0x1a6c0 */

undefined8 FUN_14001a6c0(void)

{
  PVOID pvVar1;
  
  pvVar1 = FUN_1400173f0();
  return *(undefined8 *)((longlong)pvVar1 + 0x60);
}

