/* address=14001638c rva=0x1638c */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_14001638c(int param_1)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  ulonglong uVar5;
  char *pcVar6;
  int iVar7;
  longlong *local_res10;
  ulonglong local_res18;
  ulonglong local_res20;
  
  iVar7 = 0;
  if (param_1 == 0) {
    return 0;
  }
  if (1 < param_1 - 1U) {
    puVar3 = FUN_140019fec();
    *(undefined4 *)puVar3 = 0x16;
    FUN_1400192c4();
    return 0x16;
  }
  FUN_1400185dc();
  FUN_14001bf78((HMODULE)0x0,&DAT_1400d0e80,0x104);
  _DAT_1400d0e28 = &DAT_1400d0e80;
  if ((DAT_1400d0e48 == (char *)0x0) || (pcVar6 = DAT_1400d0e48, *DAT_1400d0e48 == '\0')) {
    pcVar6 = &DAT_1400d0e80;
  }
  local_res18 = 0;
  local_res20 = 0;
  FUN_14001656c(pcVar6,(undefined8 *)0x0,(char *)0x0,(longlong *)&local_res18,
                (longlong *)&local_res20);
  uVar5 = local_res18;
  plVar4 = FUN_14001650c(local_res18,local_res20,1);
  if (plVar4 == (longlong *)0x0) {
    puVar3 = FUN_140019fec();
    iVar7 = 0xc;
    *(undefined4 *)puVar3 = 0xc;
  }
  else {
    FUN_14001656c(pcVar6,plVar4,(char *)(plVar4 + uVar5),(longlong *)&local_res18,
                  (longlong *)&local_res20);
    if (param_1 != 1) {
      local_res10 = (longlong *)0x0;
      uVar5 = thunk_FUN_14001b4f8(plVar4,&local_res10);
      plVar2 = local_res10;
      if ((int)uVar5 != 0) {
        FUN_1400191b0(local_res10);
        local_res10 = (longlong *)0x0;
        FUN_1400191b0(plVar4);
        return (int)uVar5;
      }
      _DAT_1400d0e30 = 0;
      lVar1 = *local_res10;
      while (lVar1 != 0) {
        local_res10 = local_res10 + 1;
        _DAT_1400d0e30 = _DAT_1400d0e30 + 1;
        lVar1 = *local_res10;
      }
      local_res10 = (longlong *)0x0;
      DAT_1400d0e38 = plVar2;
      FUN_1400191b0((LPVOID)0x0);
      local_res10 = (longlong *)0x0;
      goto LAB_1400164f1;
    }
    _DAT_1400d0e30 = (int)local_res18 + -1;
    DAT_1400d0e38 = plVar4;
  }
  plVar4 = (longlong *)0x0;
LAB_1400164f1:
  FUN_1400191b0(plVar4);
  return iVar7;
}

