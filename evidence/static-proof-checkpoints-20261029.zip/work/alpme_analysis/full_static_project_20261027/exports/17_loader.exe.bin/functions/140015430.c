/* address=140015430 rva=0x15430 */

undefined8 FUN_140015430(void)

{
  return 0x4000;
}

