/* address=14001f3fc rva=0x1f3fc */

undefined8 FUN_14001f3fc(void)

{
  return 0xffffffff;
}

