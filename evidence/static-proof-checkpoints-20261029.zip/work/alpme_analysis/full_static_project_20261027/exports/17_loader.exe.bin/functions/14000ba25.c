/* address=14000ba25 rva=0xba25 */

ulonglong FUN_14000ba25(undefined8 *param_1,ushort *param_2)

{
  ulonglong *puVar1;
  byte bVar2;
  byte *pbVar3;
  undefined8 uVar4;
  char cVar5;
  byte *pbVar6;
  ushort uVar7;
  uint uVar8;
  ulonglong uVar9;
  byte *pbVar10;
  byte *pbVar11;
  ushort uVar12;
  ulonglong uVar13;
  longlong lVar14;
  longlong lVar15;
  byte *pbVar16;
  ulonglong uVar17;
  ulonglong unaff_R12;
  undefined7 uVar18;
  uint uVar19;
  
  pbVar3 = (byte *)*param_1;
  pbVar10 = (byte *)param_1[2];
  if ((*(uint *)(param_2 + 2) & 0x18000000) != 0) {
    if ((*(uint *)(param_2 + 2) >> 0x1c & 1) == 0) {
      if (pbVar10 < (byte *)0x20) {
        uVar17 = 0;
        if (pbVar10 != (byte *)0x0) {
          pbVar6 = (byte *)0x0;
          do {
            uVar17 = uVar17 + (-0x41 < (char)pbVar3[(longlong)pbVar6]);
            pbVar6 = pbVar6 + 1;
          } while (pbVar6 != pbVar10);
        }
      }
      else {
        pbVar6 = (byte *)((ulonglong)(pbVar3 + 7) & 0xfffffffffffffff8);
        uVar9 = (longlong)pbVar10 - ((longlong)pbVar6 - (longlong)pbVar3);
        uVar17 = (ulonglong)((uint)uVar9 & 7);
        lVar15 = 0;
        if (pbVar6 != pbVar3) {
          lVar14 = 0;
          do {
            lVar15 = lVar15 + (ulonglong)(-0x41 < (char)pbVar3[lVar14]);
            lVar14 = lVar14 + 1;
          } while (lVar14 != (longlong)pbVar6 - (longlong)pbVar3);
        }
        if (uVar17 == 0) {
          lVar14 = 0;
        }
        else {
          lVar14 = 0;
          uVar13 = 0;
          do {
            lVar14 = lVar14 + (ulonglong)
                              (-0x41 < (char)pbVar6[uVar13 + (uVar9 & 0x7ffffffffffffff8)]);
            uVar13 = uVar13 + 1;
          } while (uVar13 != uVar17);
        }
        uVar17 = lVar14 + lVar15;
        uVar9 = uVar9 >> 3;
        do {
          pbVar11 = pbVar6;
          if (uVar9 == 0) goto LAB_14000bcc2;
          unaff_R12 = uVar9;
          if (0xbf < uVar9) {
            unaff_R12 = 0xc0;
          }
          uVar8 = (uint)unaff_R12;
          uVar19 = uVar8 * 8 & 0x7e0;
          if (uVar19 == 0) {
            uVar13 = 0;
          }
          else {
            uVar13 = 0;
            pbVar6 = pbVar11;
            do {
              lVar15 = 0;
              do {
                puVar1 = (ulonglong *)(pbVar6 + lVar15);
                lVar15 = lVar15 + 8;
                uVar13 = uVar13 + ((~*puVar1 >> 7 | *puVar1 >> 6) & 0x101010101010101);
              } while (lVar15 != 0x20);
              pbVar6 = pbVar6 + 0x20;
            } while (pbVar6 != pbVar11 + uVar19);
          }
          uVar9 = uVar9 - unaff_R12;
          uVar17 = (((uVar13 >> 8 & 0xff00ff00ff00ff) + (uVar13 & 0xff00ff00ff00ff)) *
                    0x1000100010001 >> 0x30) + uVar17;
          pbVar6 = pbVar11 + uVar8 * 8;
        } while ((unaff_R12 & 3) == 0);
        unaff_R12 = (ulonglong)(uVar8 & 0xfc);
        uVar9 = 0;
        uVar13 = 0;
        do {
          uVar9 = uVar9 + ((*(ulonglong *)(pbVar11 + uVar13 + unaff_R12 * 8) >> 6 |
                           ~*(ulonglong *)(pbVar11 + uVar13 + unaff_R12 * 8) >> 7) &
                          0x101010101010101);
          uVar13 = uVar13 + 8;
        } while ((uVar8 & 3) << 3 != uVar13);
        uVar17 = (((uVar9 & 0xff00ff00ff00ff) + (uVar9 >> 8 & 0xff00ff00ff00ff)) * 0x1000100010001
                 >> 0x30) + uVar17;
      }
    }
    else {
      uVar17 = (ulonglong)param_2[4];
      if (uVar17 == 0) {
        pbVar10 = (byte *)0x0;
      }
      else {
        pbVar11 = pbVar10 + (longlong)pbVar3;
        pbVar10 = (byte *)0x0;
        uVar9 = uVar17;
        pbVar6 = pbVar3;
        do {
          if (pbVar11 == pbVar6) goto LAB_14000bb59;
          bVar2 = *pbVar6;
          if ((char)bVar2 < '\0') {
            if (bVar2 < 0xe0) {
              pbVar16 = pbVar6 + 2;
            }
            else {
              pbVar16 = pbVar6 + (4 - (ulonglong)(bVar2 < 0xf0));
            }
          }
          else {
            pbVar16 = pbVar6 + 1;
          }
          pbVar10 = pbVar16 + ((longlong)pbVar10 - (longlong)pbVar6);
          uVar9 = uVar9 - 1;
          pbVar6 = pbVar16;
        } while (uVar9 != 0);
      }
      uVar9 = 0;
LAB_14000bb59:
      uVar17 = uVar17 - uVar9;
    }
LAB_14000bcc2:
    if (uVar17 < *param_2) {
      uVar8 = (uint)*param_2 - (int)uVar17;
      uVar7 = (ushort)uVar8;
      uVar8 = FUN_14000b9a0((longlong)param_2,uVar8,'\0');
      uVar18 = (undefined7)(unaff_R12 >> 8);
      uVar17 = CONCAT71(uVar18,1);
      if (uVar8 != 0xffffffff) {
        uVar4 = *(undefined8 *)(param_2 + 8);
        lVar15 = *(longlong *)(param_2 + 0xc);
        cVar5 = (**(code **)(lVar15 + 0x18))(uVar4,pbVar3,pbVar10);
        if (cVar5 == '\0') {
          uVar12 = 0xffff;
          do {
            if ((ushort)(uVar12 - uVar7) == -1) {
              uVar12 = uVar7;
              break;
            }
            cVar5 = (**(code **)(lVar15 + 0x20))(uVar4,uVar8);
            uVar12 = uVar12 + 1;
          } while (cVar5 == '\0');
          uVar17 = CONCAT71(uVar18,uVar12 < uVar7);
        }
      }
      return uVar17 & 0xffffffff;
    }
  }
                    /* WARNING: Could not recover jumptable at 0x00014000baff. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar17 = (**(code **)(*(longlong *)(param_2 + 0xc) + 0x18))
                     (*(undefined8 *)(param_2 + 8),pbVar3,pbVar10);
  return uVar17;
}

