/* address=1400240e0 rva=0x240e0 */

bool FUN_1400240e0(undefined8 *param_1)

{
  return *(int *)*param_1 == -0x3ffffffb;
}

