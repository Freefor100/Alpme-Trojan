/* address=140015c30 rva=0x15c30 */

longlong FUN_140015c30(void)

{
  PVOID pvVar1;
  
  pvVar1 = FUN_1400173f0();
  return (longlong)pvVar1 + 0x20;
}

