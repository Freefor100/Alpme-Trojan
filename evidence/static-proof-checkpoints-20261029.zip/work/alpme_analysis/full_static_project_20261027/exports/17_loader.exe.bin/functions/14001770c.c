/* address=14001770c rva=0x1770c */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */

INT_PTR FUN_14001770c(void)

{
  FARPROC pFVar1;
  INT_PTR IVar2;
  
  pFVar1 = FUN_140017a48(0,"AreFileApisANSI",(uint *)&DAT_140076ff8,(uint *)&DAT_140076ffc);
  if (pFVar1 == (FARPROC)0x0) {
    return 1;
  }
  IVar2 = (*pFVar1)();
  return IVar2;
}

