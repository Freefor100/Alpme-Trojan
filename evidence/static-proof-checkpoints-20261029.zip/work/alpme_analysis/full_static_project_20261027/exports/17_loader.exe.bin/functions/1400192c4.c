/* address=1400192c4 rva=0x192c4 */

void FUN_1400192c4(void)

{
  FUN_14001967c(0,0,0,0,0);
  return;
}

