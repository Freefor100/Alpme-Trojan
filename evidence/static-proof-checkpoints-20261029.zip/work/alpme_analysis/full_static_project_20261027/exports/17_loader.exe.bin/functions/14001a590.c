/* address=14001a590 rva=0x1a590 */

undefined8 *
FUN_14001a590(undefined8 *param_1,undefined8 param_2,int param_3,ulonglong *param_4,longlong param_5
             )

{
  longlong lVar1;
  int iVar2;
  uint uVar3;
  ulonglong uVar4;
  uint uVar5;
  longlong lVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  undefined4 uStack_3c;
  
  uVar3 = *(uint *)(param_5 + 0xc);
  iVar2 = FUN_14001f2b0(param_5,param_4);
  if (uVar3 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_1400172f8();
  }
  uVar4 = param_4[1];
  uVar7 = 0xffffffff;
  lVar6 = (longlong)*(int *)(param_5 + 0x10);
  uVar9 = 0xffffffff;
  lVar1 = uVar4 + lVar6;
  uVar5 = uVar3;
  while( true ) {
    uVar8 = uVar5 - 1;
    if ((*(int *)(uVar4 + (ulonglong)uVar8 * 0x14 + 4 + lVar6) < iVar2) &&
       (iVar2 <= *(int *)(lVar1 + 8 + (ulonglong)uVar8 * 0x14))) break;
    uVar5 = uVar8;
    if (uVar8 == 0) {
      lVar6 = 0;
LAB_14001a61c:
      uVar8 = 0;
      uVar5 = uVar8;
      do {
        uVar4 = (ulonglong)uVar5;
        if ((((lVar6 == 0) ||
             ((*(int *)(lVar6 + 4) < *(int *)(lVar1 + uVar4 * 0x14) &&
              (*(int *)(lVar1 + 4 + uVar4 * 0x14) <= *(int *)(lVar6 + 8))))) &&
            (*(int *)(lVar1 + uVar4 * 0x14) <= param_3)) &&
           (param_3 <= *(int *)(lVar1 + 4 + uVar4 * 0x14))) {
          uVar9 = uVar5;
          if (uVar7 == 0xffffffff) {
            uVar7 = uVar5;
          }
        }
        uVar5 = uVar5 + 1;
      } while (uVar5 < uVar3);
      *param_1 = param_2;
      param_1[2] = param_2;
      uVar3 = uVar8;
      if (uVar7 != 0xffffffff) {
        uVar3 = uVar7;
      }
      *(uint *)(param_1 + 1) = uVar3;
      *(undefined4 *)((longlong)param_1 + 0xc) = uStack_3c;
      if (uVar7 != 0xffffffff) {
        uVar8 = uVar9 + 1;
      }
      *(undefined4 *)((longlong)param_1 + 0x1c) = uStack_3c;
      *(uint *)(param_1 + 3) = uVar8;
      return param_1;
    }
  }
  lVar6 = uVar4 + (ulonglong)(uVar5 - 1) * 0x14 + lVar6;
  goto LAB_14001a61c;
}

