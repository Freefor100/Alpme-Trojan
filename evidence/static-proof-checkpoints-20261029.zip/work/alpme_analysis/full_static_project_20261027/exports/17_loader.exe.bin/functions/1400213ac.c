/* address=1400213ac rva=0x213ac */

void FUN_1400213ac(byte *param_1,byte *param_2)

{
  FUN_1400213b4(param_1,param_2,(undefined4 *)0x0);
  return;
}

