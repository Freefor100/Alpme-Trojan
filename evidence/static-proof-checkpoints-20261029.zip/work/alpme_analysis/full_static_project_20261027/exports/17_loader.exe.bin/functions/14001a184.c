/* address=14001a184 rva=0x1a184 */

bool FUN_14001a184(void)

{
  uint uVar1;
  int local_res8 [8];
  
  local_res8[0] = 0;
  uVar1 = FUN_14001a16c();
  if ((char)uVar1 == '\0') {
    FUN_1400179a8(local_res8);
  }
  return local_res8[0] != 1;
}

