/* address=1400019bd rva=0x19bd */

void FUN_1400019bd(longlong *param_1,undefined8 *param_2,undefined8 *param_3)

{
  code *pcVar1;
  longlong lVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  
  uVar3 = (ulonglong)((longlong)param_3 - (longlong)param_2) >> 1;
  uVar4 = param_1[2];
  if (param_1[1] - uVar4 < uVar3) {
    lVar2 = FUN_14000965c(param_1,uVar4,uVar3,(LPVOID)0x2,2);
    if (lVar2 != -1) {
                    /* WARNING: Does not return */
      pcVar1 = (code *)invalidInstructionException();
      (*pcVar1)();
    }
    uVar4 = param_1[2];
  }
  else if (param_3 == param_2) goto LAB_140001a01;
  FUN_140023130((undefined8 *)(uVar4 * 2 + *param_1),param_2,(longlong)param_3 - (longlong)param_2);
LAB_140001a01:
  param_1[2] = uVar4 + uVar3;
  return;
}

