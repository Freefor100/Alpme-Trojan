/* address=140022fe0 rva=0x22fe0 */

/* WARNING: Removing unreachable block (ram,0x000140023060) */
/* WARNING: Removing unreachable block (ram,0x000140023052) */
/* WARNING: Removing unreachable block (ram,0x000140022ff7) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_140022fe0(void)

{
  longlong lVar1;
  int *piVar2;
  undefined8 uVar3;
  byte in_XCR0;
  
  _DAT_1400d1868 = 0;
  DAT_1400d186c = 0;
  lVar1 = cpuid_Version_info(1);
  if ((*(uint *)(lVar1 + 0xc) & 0x18001000) == 0x18001000) {
    uVar3 = xinuse(0);
    if ((in_XCR0 & (byte)uVar3 & 6) == 6) {
      _DAT_1400d1868 = 1;
      DAT_1400d186c = 1;
    }
    else {
      _DAT_1400d1868 = 0;
    }
  }
  if ((_DAT_1400d1868 != 0) && (piVar2 = (int *)cpuid_basic_info(0), 6 < *piVar2)) {
    lVar1 = cpuid_Extended_Feature_Enumeration_info(7);
    if ((*(uint *)(lVar1 + 4) & 0x20) != 0) {
      DAT_1400d186c = 3;
      _DAT_1400d1868 = 3;
      return 0;
    }
  }
  return 0;
}

