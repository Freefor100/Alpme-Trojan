/* address=140012924 rva=0x12924 */

ulonglong FUN_140012924(uint param_1)

{
  longlong lVar1;
  longlong lVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  uint uVar5;
  ulonglong uVar6;
  uint uVar7;
  
  uVar3 = 0x21;
  lVar1 = 0;
  do {
    lVar2 = lVar1 + (uVar3 >> 1);
    if (param_1 < ((&DAT_140073800)[lVar2] & 0x1fffff)) {
      lVar2 = lVar1;
    }
    uVar3 = uVar3 - (uVar3 >> 1);
    lVar1 = lVar2;
  } while (1 < uVar3);
  uVar6 = (ulonglong)((&DAT_140073800)[lVar2] * 0x800 == param_1 * 0x800) + lVar2 +
          (ulonglong)((uint)((&DAT_140073800)[lVar2] * 0x800) < param_1 * 0x800);
  uVar3 = (ulonglong)((uint)(&DAT_140073800)[uVar6] >> 0x15);
  uVar4 = 0x30b;
  if ((uVar6 < 0x20) &&
     (uVar4 = (ulonglong)(*(uint *)(&DAT_140073804 + uVar6 * 4) >> 0x15), uVar6 == 0)) {
    uVar7 = 0;
  }
  else {
    uVar7 = *(uint *)(&DAT_1400737fc + uVar6 * 4) & 0x1fffff;
  }
  if (~uVar3 + uVar4 != 0) {
    uVar5 = 0;
    do {
      uVar5 = (byte)"cMBE5f85beeqTJFBaSMaiOgpDGMDvzDDBbKpfcqFYv7tvIOTemo6Up-sf_EMyB2yMNx-2R4U-LzrDjZlHnlF15Z1oZfs-xq40XuyZuFYmcZ3au_r_sEroschilAvGE6MfLH7ElnTcrGXBRf-BrsDmpvv27GLfS6Tokens exhausted Private State Token params main frameeiyVXhHwH8H5uVRIfkPrZvy0Gw3lewqx5hyv0DqzRsCtlB77PjS8ertYqu6Y_zdxsS4y0oxaNlNTT72UED2Gb4dWGFHoPcallback intends evaluate module entry load time snapshot exports correctlymTeCSSCFq2zmdv0pSMSBnNWrJYZrnyTILCOXenhfwGmOalms3oyEIsqArE-agyC9BEZ0ErOCMmh8ZW16gTin.cdNjZMyt0-stl archive timestamp from deltaqJn49VYGTCmNhF9AhynDoleQINxaveCWXXeKAr_phDhsA-yPBz_e5ics9b6_BkarJJwybnAbZ2rxjzXUJeZZ-Udd01G6XJp14x0igKGDae-3wvJMsdZS2Pk4bsOHD9KUNZ4KrgcQySdtSa0dFDPR8h2j-P5TNFOgmAKthrough may little line had end eE9F-_gg5ofUHmLMfsJchdqV30mN8IrQx2mPktqiGvCMKI08h7hPYKAMf7R6h5BOHhizQvDdXypmaEDRsOAdpPMsZvL"
                    [uVar3 + 0x31a] + uVar5;
      if (param_1 - uVar7 < uVar5) break;
      uVar3 = uVar3 + 1;
    } while (uVar3 != uVar4 - 1);
  }
  return uVar3 & 0xffffffffffffff01;
}

