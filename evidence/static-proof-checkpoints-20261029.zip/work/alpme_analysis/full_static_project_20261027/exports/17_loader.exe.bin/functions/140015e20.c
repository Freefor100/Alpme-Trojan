/* address=140015e20 rva=0x15e20 */

undefined8 FUN_140015e20(void)

{
  uint uVar1;
  ulonglong uVar2;
  
  LOCK();
  uVar1 = *DAT_1400d17d8;
  uVar2 = (ulonglong)uVar1;
  *DAT_1400d17d8 = *DAT_1400d17d8 - 1;
  UNLOCK();
  if ((uVar1 == 1) && (DAT_1400d17d8 != (uint *)&DAT_1400d0340)) {
    uVar2 = FUN_1400191b0(DAT_1400d17d8);
    DAT_1400d17d8 = (uint *)&DAT_1400d0340;
  }
  return CONCAT71((int7)(uVar2 >> 8),1);
}

