/* address=1400242d8 rva=0x242d8 */

void FUN_1400242d8(undefined8 param_1,longlong param_2)

{
  FUN_140017cd0(**(int **)(param_2 + 0x98));
  return;
}

