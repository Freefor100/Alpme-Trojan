/* address=1400222d8 rva=0x222d8 */

ulonglong FUN_1400222d8(int *param_1,longlong *param_2)

{
  uint uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  
  if (param_1 == (int *)0x0) {
    *(undefined1 *)(param_2 + 6) = 1;
    *(undefined4 *)((longlong)param_2 + 0x2c) = 0x16;
    FUN_1400194a4(0,0,0,0,0,param_2);
    uVar2 = 0xffffffff;
  }
  else {
    uVar2 = 0xffffffff;
    if (((uint)param_1[5] >> 0xd & 1) != 0) {
      uVar2 = FUN_140019bec(param_1,param_2);
      uVar2 = uVar2 & 0xffffffff;
      FUN_14001f208((undefined8 *)param_1);
      uVar1 = FUN_14001e4b0((longlong)param_1);
      uVar3 = FUN_140022e7c(uVar1,param_2);
      if ((int)uVar3 < 0) {
        uVar2 = 0xffffffff;
      }
      else if (*(LPVOID *)(param_1 + 10) != (LPVOID)0x0) {
        FUN_1400191b0(*(LPVOID *)(param_1 + 10));
        param_1[10] = 0;
        param_1[0xb] = 0;
      }
    }
    FUN_140022fb8((undefined8 *)param_1);
  }
  return uVar2;
}

