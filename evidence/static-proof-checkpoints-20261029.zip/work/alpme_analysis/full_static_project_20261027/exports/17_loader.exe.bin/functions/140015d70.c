/* address=140015d70 rva=0x15d70 */

undefined1 FUN_140015d70(char param_1)

{
  if (param_1 == '\0') {
    FUN_1400173c0();
    FUN_140017650();
  }
  return 1;
}

