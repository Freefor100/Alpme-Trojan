/* address=140015580 rva=0x15580 */

undefined8 FUN_140015580(undefined8 *param_1)

{
  int *piVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  
  piVar1 = (int *)*param_1;
  if (((*piVar1 == -0x1f928c9d) && (piVar1[6] == 4)) &&
     ((piVar1[8] + 0xe66cfae0U < 3 || (piVar1[8] == 0x1994000)))) {
    puVar3 = (undefined8 *)FUN_140015c30();
    *puVar3 = piVar1;
    uVar2 = param_1[1];
    puVar3 = (undefined8 *)FUN_140015c50();
    *puVar3 = uVar2;
                    /* WARNING: Subroutine does not return */
    FUN_14001715c();
  }
  return 0;
}

