/* address=140018214 rva=0x18214 */

void FUN_140018214(undefined8 param_1,int *param_2,undefined8 *param_3,int *param_4)

{
  FUN_140017cb4(*param_2);
  LOCK();
  **(int **)(*(longlong *)*param_3 + 0x88) = **(int **)(*(longlong *)*param_3 + 0x88) + 1;
  UNLOCK();
  FUN_140017cd0(*param_4);
  return;
}

