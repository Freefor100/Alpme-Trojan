/* address=140012e76 rva=0x12e76 */

undefined8 FUN_140012e76(undefined8 param_1,longlong param_2,int param_3,longlong param_4)

{
  undefined8 uVar1;
  
  if (param_3 != -1) {
    uVar1 = (**(code **)(param_2 + 0x20))(param_1,param_3);
    if ((char)uVar1 != '\0') {
      return CONCAT71((int7)((ulonglong)uVar1 >> 8),1);
    }
  }
  if (param_4 == 0) {
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140012eb9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(param_2 + 0x18))(param_1,param_4,0);
  return uVar1;
}

