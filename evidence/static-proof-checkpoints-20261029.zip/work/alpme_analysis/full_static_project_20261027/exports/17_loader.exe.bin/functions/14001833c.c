/* address=14001833c rva=0x1833c */

bool FUN_14001833c(void)

{
  int iVar1;
  
  FUN_140017cb4(7);
  iVar1 = FUN_14001cb4c(0);
  if (iVar1 == 0) {
    FUN_1400183b8();
    FUN_1400184b8();
  }
  FUN_140017cd0(7);
  return iVar1 == 0;
}

