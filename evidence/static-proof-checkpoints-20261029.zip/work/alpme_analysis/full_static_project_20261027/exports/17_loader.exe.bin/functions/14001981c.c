/* address=14001981c rva=0x1981c */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14001981c(undefined8 param_1)

{
  _DAT_1400d17f8 = param_1;
  _DAT_1400d1800 = param_1;
  DAT_1400d1808 = param_1;
  _DAT_1400d1810 = param_1;
  return;
}

