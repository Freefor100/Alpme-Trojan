/* address=1400185dc rva=0x185dc */

undefined8 FUN_1400185dc(void)

{
  int iVar1;
  undefined8 in_RAX;
  longlong lVar2;
  undefined4 extraout_var;
  
  if (DAT_1400d17e4 == '\0') {
    DAT_1400d17d0 = &DAT_1400d0680;
    DAT_1400d17d8 = &DAT_1400d0340;
    DAT_1400d17c8 = &DAT_1400d0570;
    lVar2 = FUN_140017ddc();
    iVar1 = FUN_140018b70(0xfffffffd,'\x01',lVar2,&DAT_1400d17d8);
    in_RAX = CONCAT44(extraout_var,iVar1);
    DAT_1400d17e4 = '\x01';
  }
  return CONCAT71((int7)((ulonglong)in_RAX >> 8),1);
}

