/* address=1400170d4 rva=0x170d4 */

void FUN_1400170d4(undefined4 param_1)

{
  DAT_1400d0fd8 = param_1;
  return;
}

