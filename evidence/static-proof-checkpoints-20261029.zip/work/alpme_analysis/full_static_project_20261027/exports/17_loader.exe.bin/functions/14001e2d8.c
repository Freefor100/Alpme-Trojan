/* address=14001e2d8 rva=0x1e2d8 */

void FUN_14001e2d8(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  
  if ((*param_2 != DAT_1400d17d8) && ((DAT_1400d0ba0 & *(uint *)(param_1 + 0x3a8)) == 0)) {
    lVar1 = FUN_1400185c0();
    *param_2 = lVar1;
  }
  return;
}

