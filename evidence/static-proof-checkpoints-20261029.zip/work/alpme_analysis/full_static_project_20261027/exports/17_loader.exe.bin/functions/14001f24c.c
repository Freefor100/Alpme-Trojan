/* address=14001f24c rva=0x1f24c */

byte FUN_14001f24c(uint param_1)

{
  undefined8 *puVar1;
  
  if (param_1 == 0xfffffffe) {
    puVar1 = FUN_140019fec();
    *(undefined4 *)puVar1 = 9;
  }
  else {
    if ((-1 < (int)param_1) && (param_1 < DAT_1400d17c0)) {
      return *(byte *)((&DAT_1400d13c0)[(ulonglong)(longlong)(int)param_1 >> 6] + 0x38 +
                      (ulonglong)(param_1 & 0x3f) * 0x48) & 0x40;
    }
    puVar1 = FUN_140019fec();
    *(undefined4 *)puVar1 = 9;
    FUN_1400192c4();
  }
  return 0;
}

