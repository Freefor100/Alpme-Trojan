/* address=14001a9bc rva=0x1a9bc */

void FUN_14001a9bc(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    if ((undefined *)*param_1 != PTR_DAT_1400d0b00) {
      FUN_1400191b0((undefined *)*param_1);
    }
    if ((undefined *)param_1[1] != PTR_DAT_1400d0b08) {
      FUN_1400191b0((undefined *)param_1[1]);
    }
    if ((undefined *)param_1[2] != PTR_DAT_1400d0b10) {
      FUN_1400191b0((undefined *)param_1[2]);
    }
    if ((undefined *)param_1[0xb] != PTR_DAT_1400d0b58) {
      FUN_1400191b0((undefined *)param_1[0xb]);
    }
    if ((undefined *)param_1[0xc] != PTR_DAT_1400d0b60) {
      FUN_1400191b0((undefined *)param_1[0xc]);
    }
  }
  return;
}

