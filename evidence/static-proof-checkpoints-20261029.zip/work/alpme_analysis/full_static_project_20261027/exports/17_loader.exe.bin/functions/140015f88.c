/* address=140015f88 rva=0x15f88 */

void FUN_140015f88(uint param_1)

{
  FUN_140016098(param_1,0,0);
  return;
}

