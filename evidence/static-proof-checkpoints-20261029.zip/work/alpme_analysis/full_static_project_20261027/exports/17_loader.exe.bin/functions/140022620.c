/* address=140022620 rva=0x22620 */

ulonglong FUN_140022620(byte *param_1,byte *param_2,ulonglong param_3)

{
  byte bVar1;
  byte bVar2;
  int iVar3;
  ulonglong uVar4;
  undefined4 extraout_var;
  uint uVar5;
  uint uVar6;
  
  if (DAT_1400d0e78 != 0) {
    iVar3 = FUN_1400226b0(param_1,param_2,param_3,(undefined8 *)0x0);
    return CONCAT44(extraout_var,iVar3);
  }
  if (((param_1 == (byte *)0x0) || (param_2 == (byte *)0x0)) || (0x7fffffff < param_3)) {
    uVar4 = FUN_140022810((longlong)param_1,(longlong)param_2,param_3);
    return uVar4;
  }
  if (param_3 == 0) {
    return 0;
  }
  while( true ) {
    bVar1 = *param_1;
    uVar5 = (uint)bVar1;
    param_1 = param_1 + 1;
    bVar2 = *param_2;
    uVar6 = (uint)bVar2;
    param_2 = param_2 + 1;
    if ((uint)bVar1 != (uint)bVar2) {
      uVar5 = bVar1 + 0x20;
      if (0x19 < bVar1 - 0x41) {
        uVar5 = (uint)bVar1;
      }
      if (bVar2 - 0x41 < 0x1a) {
        uVar6 = bVar2 + 0x20;
      }
    }
    uVar4 = (ulonglong)(uVar5 - uVar6);
    if ((uVar5 - uVar6 != 0) || (uVar5 == 0)) break;
    param_3 = param_3 - 1;
    if (param_3 == 0) {
      return uVar4;
    }
  }
  return uVar4;
}

