/* address=14001650c rva=0x1650c */

LPVOID FUN_14001650c(ulonglong param_1,ulonglong param_2,ulonglong param_3)

{
  LPVOID pvVar1;
  
  if ((param_1 < 0x1fffffffffffffff) && (param_2 < 0xffffffffffffffff / param_3)) {
    if (param_2 * param_3 < ~(param_1 * 8)) {
      pvVar1 = FUN_14001ab80(param_1 * 8 + param_2 * param_3,1);
      FUN_1400191b0((LPVOID)0x0);
      return pvVar1;
    }
  }
  return (LPVOID)0x0;
}

