/* address=140017130 rva=0x17130 */

uint FUN_140017130(uint param_1)

{
  uint uVar1;
  undefined8 *puVar2;
  
  if (param_1 < 2) {
    LOCK();
    UNLOCK();
    uVar1 = DAT_1400d0fdc;
    DAT_1400d0fdc = param_1;
  }
  else {
    puVar2 = FUN_140019fec();
    *(undefined4 *)puVar2 = 0x16;
    FUN_1400192c4();
    uVar1 = 0xffffffff;
  }
  return uVar1;
}

