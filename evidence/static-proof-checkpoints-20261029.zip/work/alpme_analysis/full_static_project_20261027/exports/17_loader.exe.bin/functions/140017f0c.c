/* address=140017f0c rva=0x17f0c */

void FUN_140017f0c(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    FUN_140018064(param_1);
    FUN_1400191b0(param_1);
  }
  return;
}

