/* address=14001672c rva=0x1672c */

undefined8 FUN_14001672c(longlong *param_1)

{
  longlong lVar1;
  
  lVar1 = DAT_1400d02c0;
  if (param_1 == (longlong *)0x0) {
    return 0xffffffff;
  }
  if (*param_1 == param_1[2]) {
    *param_1 = DAT_1400d02c0;
    param_1[1] = lVar1;
    param_1[2] = lVar1;
  }
  return 0;
}

