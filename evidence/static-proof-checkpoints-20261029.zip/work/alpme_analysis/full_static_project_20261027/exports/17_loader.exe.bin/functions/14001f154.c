/* address=14001f154 rva=0x1f154 */

int FUN_14001f154(void)

{
  longlong lVar1;
  ulonglong uVar2;
  int iVar3;
  longlong lVar4;
  int local_18;
  
  local_18 = 0;
  FUN_140017cb4(8);
  for (iVar3 = 3; iVar3 != DAT_1400d1820; iVar3 = iVar3 + 1) {
    lVar4 = (longlong)iVar3;
    lVar1 = *(longlong *)(DAT_1400d1828 + lVar4 * 8);
    if (lVar1 != 0) {
      if (((*(uint *)(lVar1 + 0x14) >> 0xd & 1) != 0) &&
         (uVar2 = FUN_140022240(*(int **)(DAT_1400d1828 + lVar4 * 8)), (int)uVar2 != -1)) {
        local_18 = local_18 + 1;
      }
      DeleteCriticalSection((LPCRITICAL_SECTION)(*(longlong *)(DAT_1400d1828 + lVar4 * 8) + 0x30));
      FUN_1400191b0(*(LPVOID *)(DAT_1400d1828 + lVar4 * 8));
      *(undefined8 *)(DAT_1400d1828 + lVar4 * 8) = 0;
    }
  }
  FUN_140017cd0(8);
  return local_18;
}

