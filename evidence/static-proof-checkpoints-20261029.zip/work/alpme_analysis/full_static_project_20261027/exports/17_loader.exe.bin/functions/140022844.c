/* address=140022844 rva=0x22844 */

void FUN_140022844(undefined4 *param_1,ushort *param_2,uint param_3,byte *param_4,int param_5,
                  byte *param_6,int param_7,UINT param_8)

{
  longlong local_28;
  longlong local_20 [2];
  char local_10;
  
  FUN_14001863c(&local_28,param_1);
  FUN_1400228d0(local_20,param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  if (local_10 != '\0') {
    *(uint *)(local_28 + 0x3a8) = *(uint *)(local_28 + 0x3a8) & 0xfffffffd;
  }
  return;
}

