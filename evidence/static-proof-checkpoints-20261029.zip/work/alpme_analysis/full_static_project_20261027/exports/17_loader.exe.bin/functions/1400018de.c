/* address=1400018de rva=0x18de */

void FUN_1400018de(undefined8 *param_1)

{
  undefined8 local_8;
  
  local_8 = *param_1;
  FUN_140001dfe(&local_8);
  return;
}

