/* address=14000b2d9 rva=0xb2d9 */

void FUN_14000b2d9(LPVOID param_1,undefined8 *param_2)

{
  if ((code *)*param_2 != (code *)0x0) {
    (*(code *)*param_2)(param_1);
  }
  if (param_2[1] == 0) {
    return;
  }
  FUN_14001305a(param_1,param_2[2]);
  return;
}

