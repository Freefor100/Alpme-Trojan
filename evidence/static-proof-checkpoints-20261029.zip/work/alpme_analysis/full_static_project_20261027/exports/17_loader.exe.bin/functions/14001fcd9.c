/* address=14001fcd9 rva=0x1fcd9 */

undefined8 FUN_14001fcd9(void)

{
  uint uVar1;
  byte *unaff_RBP;
  byte *unaff_RDI;
  uint *unaff_R14;
  
  if ((((((*unaff_RBP & 2) == 0) || ((*unaff_RDI & 8) != 0)) &&
       ((uVar1 = *unaff_R14, (uVar1 & 1) == 0 || ((*unaff_RDI & 1) != 0)))) &&
      (((uVar1 & 4) == 0 || ((*unaff_RDI & 4) != 0)))) &&
     (((uVar1 & 2) == 0 || ((*unaff_RDI & 2) != 0)))) {
    return 1;
  }
  return 0;
}

