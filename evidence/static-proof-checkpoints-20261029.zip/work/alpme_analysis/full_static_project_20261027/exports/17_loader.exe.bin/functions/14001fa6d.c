/* address=14001fa6d rva=0x1fa6d */

undefined1 FUN_14001fa6d(undefined8 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  uint *puVar3;
  longlong in_RAX;
  longlong lVar4;
  longlong lVar5;
  undefined8 uVar6;
  int iVar7;
  undefined8 unaff_RBX;
  undefined8 unaff_RBP;
  longlong unaff_RSI;
  undefined1 uVar8;
  undefined8 unaff_RDI;
  undefined8 unaff_R12;
  int *unaff_R13;
  undefined8 unaff_R14;
  int *piVar9;
  int iVar10;
  undefined8 unaff_R15;
  longlong in_stack_00000060;
  undefined1 uStack0000000000000068;
  
  *(undefined8 *)(in_RAX + -0x20) = unaff_RDI;
  uVar8 = 0;
  *(undefined8 *)(in_RAX + -0x38) = unaff_R15;
  iVar10 = 0;
  uStack0000000000000068 = 0;
  if (0 < *param_2) {
    *(undefined8 *)(in_RAX + 0x18) = unaff_RBX;
    *(undefined8 *)(in_RAX + -0x18) = unaff_RBP;
    *(undefined8 *)(in_RAX + -0x28) = unaff_R12;
    *(undefined8 *)(in_RAX + -0x30) = unaff_R14;
    do {
      iVar7 = *(int *)(*(longlong *)(unaff_RSI + 0x30) + 0xc);
      lVar4 = FUN_14001a700();
      piVar9 = (int *)((longlong)iVar7 + lVar4 + 4);
      iVar7 = *(int *)(*(longlong *)(unaff_RSI + 0x30) + 0xc);
      lVar4 = FUN_14001a700();
      iVar7 = *(int *)(lVar4 + iVar7);
      if (0 < iVar7) {
        do {
          iVar1 = *piVar9;
          lVar4 = FUN_14001a700();
          puVar3 = *(uint **)(unaff_RSI + 0x30);
          iVar2 = unaff_R13[1];
          lVar5 = FUN_14001a6c0();
          uVar6 = FUN_14001fc00((byte *)(lVar5 + (longlong)iVar10 * 0x14 + (longlong)iVar2),
                                (byte *)(iVar1 + lVar4),puVar3);
          unaff_RSI = in_stack_00000060;
          if ((int)uVar6 != 0) {
            uVar8 = 1;
            uStack0000000000000068 = 1;
            goto LAB_14001fb1c;
          }
          iVar7 = iVar7 + -1;
          piVar9 = piVar9 + 1;
        } while (0 < iVar7);
        uVar8 = uStack0000000000000068;
      }
LAB_14001fb1c:
      iVar10 = iVar10 + 1;
    } while (iVar10 < *unaff_R13);
  }
  return uVar8;
}

