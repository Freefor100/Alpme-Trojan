/* address=14001a6a1 rva=0x1a6a1 */

void FUN_14001a6a1(undefined8 param_1,int param_2,undefined8 param_3,int param_4,undefined8 param_5)

{
  int iVar1;
  uint uVar2;
  longlong unaff_RBX;
  uint unaff_EBP;
  int unaff_ESI;
  longlong unaff_RDI;
  longlong lVar3;
  ulonglong uVar4;
  longlong in_R11;
  undefined8 unaff_R12;
  undefined8 *unaff_R14;
  ulonglong unaff_R15;
  
  lVar3 = in_R11 + (ulonglong)(param_2 - 1) * 0x14 + unaff_RBX;
  uVar4 = 0;
  do {
    if ((((lVar3 == 0) ||
         ((*(int *)(lVar3 + 4) < *(int *)(unaff_RDI + uVar4 * 0x14) &&
          (*(int *)(unaff_RDI + 4 + uVar4 * 0x14) <= *(int *)(lVar3 + 8))))) &&
        (*(int *)(unaff_RDI + uVar4 * 0x14) <= unaff_ESI)) &&
       ((unaff_ESI <= *(int *)(unaff_RDI + 4 + uVar4 * 0x14) && (unaff_R15 = uVar4, param_4 == -1)))
       ) {
      param_4 = (int)uVar4;
    }
    uVar2 = (int)uVar4 + 1;
    uVar4 = (ulonglong)uVar2;
  } while (uVar2 < unaff_EBP);
  *unaff_R14 = unaff_R12;
  unaff_R14[2] = unaff_R12;
  iVar1 = 0;
  if (param_4 != -1) {
    iVar1 = param_4;
  }
  *(int *)(unaff_R14 + 1) = iVar1;
  *(undefined4 *)((longlong)unaff_R14 + 0xc) = param_5._4_4_;
  iVar1 = 0;
  if (param_4 != -1) {
    iVar1 = (int)unaff_R15 + 1;
  }
  *(undefined4 *)((longlong)unaff_R14 + 0x1c) = param_5._4_4_;
  *(int *)(unaff_R14 + 3) = iVar1;
  return;
}

