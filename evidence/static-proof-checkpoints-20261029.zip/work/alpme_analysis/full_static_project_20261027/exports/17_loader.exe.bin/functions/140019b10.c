/* address=140019b10 rva=0x19b10 */

undefined4 thunk_FUN_140019c78(char param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_140019c78('\x01');
  return uVar1;
}

