/* address=140001905 rva=0x1905 */

void FUN_140001905(undefined8 *param_1)

{
  code *pcVar1;
  longlong lVar2;
  
  lVar2 = FUN_14000965c(param_1,param_1[1],1,(LPVOID)0x8,0x10);
  if (lVar2 != -1) {
                    /* WARNING: Does not return */
    pcVar1 = (code *)invalidInstructionException();
    (*pcVar1)();
  }
  return;
}

