/* address=14001a16c rva=0x1a16c */

uint FUN_14001a16c(void)

{
  return *(uint *)(*(longlong *)((longlong)ProcessEnvironmentBlock + 0x20) + 8) >> 0x1f;
}

