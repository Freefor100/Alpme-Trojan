/* address=1400173c0 rva=0x173c0 */

undefined1 FUN_1400173c0(void)

{
  if (DAT_1400d0334 != 0xffffffff) {
    FlsFree(DAT_1400d0334);
    DAT_1400d0334 = 0xffffffff;
  }
  return 1;
}

