/* address=140017660 rva=0x17660 */

undefined1 FUN_140017660(void)

{
  uint uVar1;
  ulonglong unaff_RBX;
  
  do {
    uVar1 = (int)unaff_RBX - 1;
    unaff_RBX = (ulonglong)uVar1;
    DeleteCriticalSection((LPCRITICAL_SECTION)(&DAT_1400d1060 + unaff_RBX * 0x28));
    DAT_1400d1088 = DAT_1400d1088 + -1;
  } while (uVar1 != 0);
  return 1;
}

