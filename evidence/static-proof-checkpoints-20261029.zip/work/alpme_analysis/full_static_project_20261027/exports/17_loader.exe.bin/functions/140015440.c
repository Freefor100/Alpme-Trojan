/* address=140015440 rva=0x15440 */

void FUN_140015440(void)

{
                    /* WARNING: Could not recover jumptable at 0x000140015447. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  InitializeSListHead(&DAT_1400d0de0);
  return;
}

