/* address=140022cd0 rva=0x22cd0 */

BOOL FUN_140022cd0(void *param_1,DWORD param_2,LPDWORD param_3)

{
  BOOL BVar1;
  DWORD DVar2;
  
  BVar1 = WriteConsoleW(DAT_1400d0cc0,param_1,param_2,param_3,(LPVOID)0x0);
  if (BVar1 == 0) {
    DVar2 = GetLastError();
    if (DVar2 == 6) {
      if (DAT_1400d0cc0 < (HANDLE)0xfffffffffffffffe) {
        CloseHandle(DAT_1400d0cc0);
      }
      DAT_1400d0cc0 =
           CreateFileW(L"CONOUT$",0x40000000,3,(LPSECURITY_ATTRIBUTES)0x0,3,0,(HANDLE)0x0);
      BVar1 = WriteConsoleW(DAT_1400d0cc0,param_1,param_2,param_3,(LPVOID)0x0);
    }
  }
  return BVar1;
}

