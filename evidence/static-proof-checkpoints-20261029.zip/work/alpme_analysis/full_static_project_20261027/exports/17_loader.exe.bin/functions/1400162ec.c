/* address=1400162ec rva=0x162ec */

void FUN_1400162ec(void)

{
  undefined1 local_res8 [8];
  int local_res10 [2];
  int local_res18 [4];
  
  local_res10[0] = 4;
  local_res18[0] = 4;
  FUN_14001631c(local_res8,local_res18,local_res8,local_res10);
  return;
}

