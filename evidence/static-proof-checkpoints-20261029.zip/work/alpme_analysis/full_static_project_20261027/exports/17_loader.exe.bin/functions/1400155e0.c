/* address=1400155e0 rva=0x155e0 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Removing unreachable block (ram,0x000140015600) */
/* WARNING: Removing unreachable block (ram,0x000140015608) */
/* WARNING: Removing unreachable block (ram,0x00014001560e) */

void FUN_1400155e0(void)

{
  return;
}

