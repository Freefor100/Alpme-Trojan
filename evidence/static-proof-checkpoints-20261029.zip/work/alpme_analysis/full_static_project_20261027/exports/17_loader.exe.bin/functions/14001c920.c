/* address=14001c920 rva=0x1c920 */

undefined8 FUN_14001c920(uint param_1)

{
  undefined4 *puVar1;
  undefined8 *puVar2;
  
  if (param_1 == 0xfffffffe) {
    puVar1 = (undefined4 *)FUN_14001a010();
    *puVar1 = 0;
    puVar2 = FUN_140019fec();
    *(undefined4 *)puVar2 = 9;
  }
  else {
    if ((-1 < (int)param_1) && (param_1 < DAT_1400d17c0)) {
      if ((*(byte *)((&DAT_1400d13c0)[(ulonglong)(longlong)(int)param_1 >> 6] + 0x38 +
                    (ulonglong)(param_1 & 0x3f) * 0x48) & 1) != 0) {
        return *(undefined8 *)
                ((&DAT_1400d13c0)[(ulonglong)(longlong)(int)param_1 >> 6] + 0x28 +
                (ulonglong)(param_1 & 0x3f) * 0x48);
      }
    }
    puVar1 = (undefined4 *)FUN_14001a010();
    *puVar1 = 0;
    puVar2 = FUN_140019fec();
    *(undefined4 *)puVar2 = 9;
    FUN_1400192c4();
  }
  return 0xffffffffffffffff;
}

