/* address=1400215b0 rva=0x215b0 */

ulonglong FUN_1400215b0(byte *param_1,byte *param_2,ulonglong param_3)

{
  uint uVar1;
  int iVar2;
  ulonglong uVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong lStack_20;
  longlong lStack_18;
  char cStack_10;
  
  if (DAT_1400d0e78 == 0) {
    FUN_140022620(param_1,param_2,param_3);
    uVar3 = FUN_14002173c();
    return uVar3;
  }
  cStack_10 = '\0';
  lVar4 = FUN_140017dc0();
  lStack_20 = *(longlong *)(lVar4 + 0x90);
  lStack_18 = *(longlong *)(lVar4 + 0x88);
  FUN_14001e2a4(lVar4,&lStack_20);
  FUN_14001e2d8(lVar4,&lStack_18);
  if ((*(uint *)(lVar4 + 0x3a8) & 2) == 0) {
    *(uint *)(lVar4 + 0x3a8) = *(uint *)(lVar4 + 0x3a8) | 2;
    cStack_10 = '\x01';
  }
  if (param_3 == 0) {
    if (cStack_10 != '\0') {
      *(uint *)(lVar4 + 0x3a8) = *(uint *)(lVar4 + 0x3a8) & 0xfffffffd;
    }
    uVar3 = 0;
  }
  else if ((param_1 == (byte *)0x0) || (param_2 == (byte *)0x0)) {
    puVar5 = FUN_140019fec();
    *(undefined4 *)puVar5 = 0x16;
    FUN_1400192c4();
    if (cStack_10 != '\0') {
      *(uint *)(lVar4 + 0x3a8) = *(uint *)(lVar4 + 0x3a8) & 0xfffffffd;
    }
    uVar3 = 0x7fffffff;
  }
  else {
    uVar3 = 0x7fffffff;
    if (param_3 < 0x80000000) {
      if (*(ushort **)(lStack_20 + 0x130) == (ushort *)0x0) {
        uVar1 = FUN_1400226b0(param_1,param_2,param_3,&lStack_20);
        if (cStack_10 != '\0') {
          *(uint *)(lVar4 + 0x3a8) = *(uint *)(lVar4 + 0x3a8) & 0xfffffffd;
        }
        return (ulonglong)uVar1;
      }
      iVar2 = FUN_140022844((undefined4 *)&lStack_20,*(ushort **)(lStack_20 + 0x130),0x1001,param_1,
                            (int)param_3,param_2,(int)param_3,*(UINT *)(lStack_20 + 0x14));
      if (iVar2 == 0) {
        puVar5 = FUN_140019fec();
        *(undefined4 *)puVar5 = 0x16;
      }
      else {
        uVar3 = (ulonglong)(iVar2 - 2);
      }
    }
    else {
      puVar5 = FUN_140019fec();
      *(undefined4 *)puVar5 = 0x16;
      FUN_1400192c4();
    }
    if (cStack_10 != '\0') {
      *(uint *)(lVar4 + 0x3a8) = *(uint *)(lVar4 + 0x3a8) & 0xfffffffd;
    }
  }
  return uVar3;
}

