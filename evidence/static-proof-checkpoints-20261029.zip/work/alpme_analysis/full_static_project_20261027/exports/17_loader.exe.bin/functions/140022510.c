/* address=140022510 rva=0x22510 */

void FUN_140022510(undefined8 *param_1,undefined8 *param_2)

{
  *param_2 = *param_1;
  *(undefined1 *)(param_2 + 1) = 0;
  return;
}

