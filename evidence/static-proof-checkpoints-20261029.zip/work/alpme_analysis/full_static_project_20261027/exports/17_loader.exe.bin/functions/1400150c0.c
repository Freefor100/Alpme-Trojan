/* address=1400150c0 rva=0x150c0 */

void entry(void)

{
  FUN_140015350();
  FUN_140014f40();
  return;
}

