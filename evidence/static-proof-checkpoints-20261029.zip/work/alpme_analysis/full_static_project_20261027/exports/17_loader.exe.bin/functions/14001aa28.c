/* address=14001aa28 rva=0x1aa28 */

void FUN_14001aa28(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    FUN_14001ab30(param_1,7);
    FUN_14001ab30(param_1 + 7,7);
    FUN_14001ab30(param_1 + 0xe,0xc);
    FUN_14001ab30(param_1 + 0x1a,0xc);
    FUN_14001ab30(param_1 + 0x26,2);
    FUN_1400191b0((LPVOID)param_1[0x28]);
    FUN_1400191b0((LPVOID)param_1[0x29]);
    FUN_1400191b0((LPVOID)param_1[0x2a]);
    FUN_14001ab30(param_1 + 0x2c,7);
    FUN_14001ab30(param_1 + 0x33,7);
    FUN_14001ab30(param_1 + 0x3a,0xc);
    FUN_14001ab30(param_1 + 0x46,0xc);
    FUN_14001ab30(param_1 + 0x52,2);
    FUN_1400191b0((LPVOID)param_1[0x54]);
    FUN_1400191b0((LPVOID)param_1[0x55]);
    FUN_1400191b0((LPVOID)param_1[0x56]);
    FUN_1400191b0((LPVOID)param_1[0x57]);
  }
  return;
}

