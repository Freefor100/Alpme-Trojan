/* address=1400213b4 rva=0x213b4 */

byte * FUN_1400213b4(byte *param_1,byte *param_2,undefined4 *param_3)

{
  undefined8 *puVar1;
  byte *pbVar2;
  longlong local_28 [2];
  longlong local_18;
  char local_10;
  
  if ((param_1 == (byte *)0x0) || (param_2 == (byte *)0x0)) {
    puVar1 = FUN_140019fec();
    *(undefined4 *)puVar1 = 0x16;
    FUN_1400192c4();
  }
  else if (param_1 < param_2) {
    FUN_14001863c(local_28,param_3);
    pbVar2 = param_2 + -1;
    if (*(int *)(local_18 + 8) != 0) {
      do {
        pbVar2 = pbVar2 + -1;
        if (pbVar2 < param_1) break;
      } while ((*(byte *)((ulonglong)*pbVar2 + 0x19 + local_18) & 4) != 0);
      pbVar2 = param_2 + (-1 - (ulonglong)((int)param_2 - (int)pbVar2 & 1));
    }
    if (local_10 != '\0') {
      *(uint *)(local_28[0] + 0x3a8) = *(uint *)(local_28[0] + 0x3a8) & 0xfffffffd;
    }
    return pbVar2;
  }
  return (byte *)0x0;
}

