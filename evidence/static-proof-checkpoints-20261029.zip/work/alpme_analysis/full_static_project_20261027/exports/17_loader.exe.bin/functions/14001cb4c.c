/* address=14001cb4c rva=0x1cb4c */

undefined4 FUN_14001cb4c(uint param_1)

{
  int iVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined4 uVar4;
  
  if (param_1 < 0x2000) {
    uVar4 = 0;
    FUN_140017cb4(7);
    lVar3 = 0;
    iVar1 = DAT_1400d17c0;
    while (iVar1 <= (int)param_1) {
      if ((&DAT_1400d13c0)[lVar3] == 0) {
        puVar2 = FUN_14001ca54();
        (&DAT_1400d13c0)[lVar3] = puVar2;
        if (puVar2 == (undefined8 *)0x0) {
          uVar4 = 0xc;
          break;
        }
        iVar1 = DAT_1400d17c0 + 0x40;
        DAT_1400d17c0 = iVar1;
      }
      lVar3 = lVar3 + 1;
    }
    FUN_140017cd0(7);
  }
  else {
    puVar2 = FUN_140019fec();
    *(undefined4 *)puVar2 = 9;
    FUN_1400192c4();
    uVar4 = 9;
  }
  return uVar4;
}

