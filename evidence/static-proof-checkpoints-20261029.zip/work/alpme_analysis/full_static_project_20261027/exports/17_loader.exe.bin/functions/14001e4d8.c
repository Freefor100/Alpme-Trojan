/* address=14001e4d8 rva=0x1e4d8 */

int FUN_14001e4d8(uint param_1,byte *param_2,uint param_3,longlong *param_4)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  byte bVar4;
  short sVar5;
  short sVar6;
  BOOL BVar7;
  DWORD DVar8;
  int iVar9;
  ulonglong uVar10;
  undefined7 extraout_var;
  undefined8 *puVar11;
  int iVar12;
  longlong lVar13;
  ulonglong uVar14;
  byte *pbVar15;
  undefined1 in_stack_ffffffffffffff78;
  undefined8 local_70;
  int local_68;
  undefined8 local_60;
  DWORD local_50 [4];
  
  iVar12 = 0;
  uVar14 = (ulonglong)param_3;
  if (param_3 == 0) {
    return 0;
  }
  if (param_2 == (byte *)0x0) {
LAB_14001e508:
    *(undefined1 *)(param_4 + 7) = 1;
    *(undefined4 *)((longlong)param_4 + 0x34) = 0;
    *(undefined1 *)(param_4 + 6) = 1;
    *(undefined4 *)((longlong)param_4 + 0x2c) = 0x16;
    FUN_1400194a4(0,0,0,0,0,param_4);
    return -1;
  }
  uVar10 = (ulonglong)(param_1 & 0x3f);
  lVar13 = (longlong)(int)param_1 >> 6;
  cVar1 = *(char *)((&DAT_1400d13c0)[lVar13] + 0x39 + uVar10 * 0x48);
  if (((byte)(cVar1 - 1U) < 2) && ((~param_3 & 1) == 0)) goto LAB_14001e508;
  if ((*(byte *)((&DAT_1400d13c0)[lVar13] + 0x38 + uVar10 * 0x48) & 0x20) != 0) {
    thunk_FUN_140022150(param_1,(LARGE_INTEGER)0x0,2,(longlong)param_4);
  }
  local_60 = 0;
  bVar4 = FUN_14001f24c(param_1);
  if (((int)CONCAT71(extraout_var,bVar4) == 0) ||
     (-1 < *(char *)((&DAT_1400d13c0)[lVar13] + 0x38 + uVar10 * 0x48))) {
LAB_14001e6c0:
    if (-1 < *(char *)((&DAT_1400d13c0)[lVar13] + 0x38 + (ulonglong)(param_1 & 0x3f) * 0x48)) {
      local_70 = 0;
      local_68 = 0;
      BVar7 = WriteFile(*(HANDLE *)
                         ((&DAT_1400d13c0)[lVar13] + 0x28 + (ulonglong)(param_1 & 0x3f) * 0x48),
                        param_2,param_3,(LPDWORD)((longlong)&local_70 + 4),(LPOVERLAPPED)0x0);
      iVar12 = local_68;
      uVar3 = local_70;
      if (BVar7 == 0) {
        DVar8 = GetLastError();
        local_70 = CONCAT44(local_70._4_4_,DVar8);
        iVar12 = local_68;
        uVar3 = local_70;
      }
      goto LAB_14001e775;
    }
    if (cVar1 == '\0') {
      puVar11 = (undefined8 *)
                FUN_14001edbc((DWORD *)&local_70,param_1,(char *)param_2,uVar14,
                              in_stack_ffffffffffffff78);
    }
    else if (cVar1 == '\x01') {
      puVar11 = (undefined8 *)
                FUN_14001efe0((DWORD *)&local_70,param_1,(short *)param_2,param_3,
                              in_stack_ffffffffffffff78);
    }
    else {
      uVar3 = local_60;
      if (cVar1 != '\x02') goto LAB_14001e775;
      puVar11 = (undefined8 *)
                FUN_14001eec4((DWORD *)&local_70,param_1,(short *)param_2,uVar14,
                              in_stack_ffffffffffffff78);
    }
  }
  else {
    if ((char)param_4[5] == '\0') {
      FUN_14001ccd0(param_4);
    }
    if ((*(longlong *)(param_4[3] + 0x138) == 0) &&
       (*(char *)((&DAT_1400d13c0)[lVar13] + 0x39 + uVar10 * 0x48) == '\0')) goto LAB_14001e6c0;
    local_50[0] = 0;
    BVar7 = GetConsoleMode(*(HANDLE *)((&DAT_1400d13c0)[lVar13] + 0x28 + uVar10 * 0x48),local_50);
    if (BVar7 == 0) goto LAB_14001e6c0;
    if (cVar1 != '\0') {
      if ((cVar1 == '\x01') || (uVar3 = local_60, cVar1 == '\x02')) {
        local_70 = 0;
        uVar3 = local_70;
        if (param_2 < param_2 + uVar14) {
          local_70._4_4_ = 0;
          pbVar15 = param_2;
          iVar9 = local_70._4_4_;
          do {
            sVar6 = *(short *)pbVar15;
            sVar5 = FUN_140022200(sVar6);
            if (sVar5 != sVar6) {
LAB_14001e688:
              DVar8 = GetLastError();
              local_70 = CONCAT44(local_70._4_4_,DVar8);
              uVar3 = local_70;
              break;
            }
            local_70 = CONCAT44(iVar9 + 2,(DWORD)local_70);
            iVar2 = iVar9 + 2;
            if (sVar6 == 10) {
              sVar6 = FUN_140022200(0xd);
              if (sVar6 != 0xd) goto LAB_14001e688;
              local_70 = CONCAT44(iVar9 + 3,(DWORD)local_70);
              iVar12 = iVar12 + 1;
              iVar2 = iVar9 + 3;
            }
            iVar9 = iVar2;
            pbVar15 = pbVar15 + 2;
            uVar3 = local_70;
          } while (pbVar15 < param_2 + uVar14);
        }
      }
      goto LAB_14001e775;
    }
    puVar11 = (undefined8 *)FUN_14001e928((DWORD *)&local_70,param_1,param_2,uVar14,param_4);
  }
  iVar12 = *(int *)(puVar11 + 1);
  uVar3 = *puVar11;
LAB_14001e775:
  local_60 = uVar3;
  iVar9 = (int)((ulonglong)local_60 >> 0x20);
  if (iVar9 != 0) {
    return iVar9 - iVar12;
  }
  if ((uint)local_60 != 0) {
    if ((uint)local_60 == 5) {
      *(undefined1 *)(param_4 + 6) = 1;
      *(undefined4 *)((longlong)param_4 + 0x2c) = 9;
      *(undefined1 *)(param_4 + 7) = 1;
      *(undefined4 *)((longlong)param_4 + 0x34) = 5;
      return -1;
    }
    FUN_14001a12c((uint)local_60,(longlong)param_4);
    return -1;
  }
  if (((*(byte *)((&DAT_1400d13c0)[lVar13] + 0x38 + (ulonglong)(param_1 & 0x3f) * 0x48) & 0x40) == 0
      ) || (*param_2 != 0x1a)) {
    *(undefined4 *)((longlong)param_4 + 0x34) = 0;
    *(undefined1 *)(param_4 + 6) = 1;
    *(undefined4 *)((longlong)param_4 + 0x2c) = 0x1c;
    *(undefined1 *)(param_4 + 7) = 1;
    return -1;
  }
  return 0;
}

