/* address=140001934 rva=0x1934 */

undefined8 FUN_140001934(HANDLE param_1,void *param_2,DWORD param_3)

{
  BOOL BVar1;
  undefined8 uVar2;
  DWORD local_4;
  
  local_4 = 0;
  BVar1 = WriteConsoleW(param_1,param_2,param_3,&local_4,(LPVOID)0x0);
  if (BVar1 == 0) {
    GetLastError();
    if ((undefined **)PTR_PTR_1400cfa50 != &PTR_LAB_140073648) {
      PTR_PTR_1400cfa50 = (undefined *)&PTR_LAB_140073648;
    }
    uVar2 = 1;
  }
  else {
    uVar2 = 0;
  }
  return uVar2;
}

