/* address=140015ffc rva=0x15ffc */

void FUN_140015ffc(undefined8 param_1)

{
  DAT_1400d0e68 = param_1;
  return;
}

