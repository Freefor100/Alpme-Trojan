/* address=140015f94 rva=0x15f94 */

void FUN_140015f94(uint param_1)

{
  FUN_140016098(param_1,2,0);
  return;
}

