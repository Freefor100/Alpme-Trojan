/* address=1400243ad rva=0x243ad */

void FUN_1400243ad(void)

{
  FUN_140017cd0(4);
  return;
}

