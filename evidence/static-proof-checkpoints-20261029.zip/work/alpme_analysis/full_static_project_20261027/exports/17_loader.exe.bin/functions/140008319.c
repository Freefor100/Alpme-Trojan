/* address=140008319 rva=0x8319 */

undefined8 FUN_140008319(undefined8 param_1,ulonglong param_2)

{
  undefined8 uVar1;
  int *piVar2;
  _union_552 local_80 [2];
  _FILETIME local_78;
  _FILETIME local_70 [6];
  
  switch(param_2 < 6) {
  case true:
    return 0;
  }
  if (*(int *)(*(longlong *)((longlong)ThreadLocalStoragePointer + (ulonglong)_tls_index * 8) +
              0x110) == -0x59f8c402) {
    GetPhysicallyInstalledSystemMemory((PULONGLONG)&local_80[0].dwOemId);
    GetNativeSystemInfo((LPSYSTEM_INFO)&local_80[0].s);
    GetSystemPowerStatus((LPSYSTEM_POWER_STATUS)&local_80[0].s);
    GetSystemTimes(local_70,&local_78,(LPFILETIME)&local_80[0].s);
    local_80[0].dwOemId = 0x40;
    GlobalMemoryStatusEx((LPMEMORYSTATUSEX)&local_80[0].s);
    GetLargePageMinimum();
    GetSystemInfo((LPSYSTEM_INFO)&local_80[0].s);
    piVar2 = &DAT_1400762f0;
    if (param_2 != 0) {
      piVar2 = &DAT_1400762e4;
    }
                    /* WARNING: Could not recover jumptable at 0x0001400084f1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (*(code *)(&LAB_14000841f + *piVar2))(&LAB_14000841f + *piVar2);
    return uVar1;
  }
  piVar2 = &DAT_1400762f0;
  if (param_2 != 0) {
    piVar2 = &DAT_1400762e4;
  }
                    /* WARNING: Could not recover jumptable at 0x000140008468. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (*(code *)(&LAB_14000841f + *piVar2))(&LAB_14000841f + *piVar2);
  return uVar1;
}

