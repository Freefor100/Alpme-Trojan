/* address=140015550 rva=0x15550 */

undefined8 thunk_FUN_140015410(void)

{
  return 0;
}

