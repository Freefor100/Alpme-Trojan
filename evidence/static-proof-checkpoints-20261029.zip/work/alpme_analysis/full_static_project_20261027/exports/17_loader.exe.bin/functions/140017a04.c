/* address=140017a04 rva=0x17a04 */

/* WARNING: Removing unreachable block (ram,0x000140017a15) */

bool FUN_140017a04(void)

{
  FARPROC pFVar1;
  
  pFVar1 = FUN_140017a48(3,"FlsGetValue2",(uint *)&DAT_140077008,(uint *)&DAT_140077010);
  return pFVar1 != (FARPROC)0x0;
}

