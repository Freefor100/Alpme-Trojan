/* address=1400154a0 rva=0x154a0 */

undefined * FUN_1400154a0(void)

{
  return &DAT_1400d0df8;
}

