/* address=140017350 rva=0x17350 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_140017350(void)

{
  uint dwFlsIndex;
  BOOL BVar1;
  
  dwFlsIndex = FlsAlloc((PFLS_CALLBACK_FUNCTION)&LAB_1400174d0);
  DAT_1400d0334 = dwFlsIndex;
  if (dwFlsIndex != 0xffffffff) {
    BVar1 = FlsSetValue(dwFlsIndex,&DAT_1400d0fe0);
    if (BVar1 != 0) {
      _DAT_1400d1058 = 0xfffffffe;
      return CONCAT31((int3)((uint)BVar1 >> 8),1);
    }
    dwFlsIndex = 0;
    if (DAT_1400d0334 != 0xffffffff) {
      dwFlsIndex = FlsFree(DAT_1400d0334);
      DAT_1400d0334 = 0xffffffff;
    }
  }
  return dwFlsIndex & 0xffffff00;
}

