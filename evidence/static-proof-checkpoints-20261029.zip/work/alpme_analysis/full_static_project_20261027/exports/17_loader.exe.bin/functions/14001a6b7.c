/* address=14001a6b7 rva=0x1a6b7 */

void thunk_FUN_1400172f8(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_1400172f8();
}

