/* address=140001201 rva=0x1201 */

/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_140001201(undefined8 *param_1)

{
  longlong *plVar1;
  byte bVar2;
  char cVar3;
  BOOL BVar4;
  UINT UVar5;
  uint uVar6;
  longlong lVar7;
  HANDLE pvVar8;
  ulonglong uVar9;
  longlong lVar10;
  byte *pbVar11;
  ulonglong uVar12;
  code *pcVar13;
  undefined **ppuVar14;
  undefined **ppuVar15;
  undefined **ppuVar16;
  bool bVar17;
  char local_71;
  DWORD local_70 [2];
  undefined **local_68;
  undefined **local_60;
  char local_58 [8];
  undefined **local_50;
  undefined **local_48;
  
  cVar3 = *(char *)*param_1;
  *(char *)*param_1 = '\0';
  if (cVar3 == '\0') {
LAB_1400016f0:
                    /* WARNING: Does not return */
    pcVar13 = (code *)invalidInstructionException();
    (*pcVar13)();
  }
  local_71 = '\0';
  uVar12 = (ulonglong)DAT_1400cf788;
  if (DAT_1400cf788 != 0) {
    uVar12 = FUN_140023ea0(&local_71);
  }
  if (local_71 == '\0') {
    plVar1 = (longlong *)
             (*(longlong *)((longlong)ThreadLocalStoragePointer + (ulonglong)_tls_index * 8) + 0x48)
    ;
    lVar10 = *plVar1;
    if (lVar10 == 0) {
      lVar7 = DAT_1400d0d80;
      do {
        if (lVar7 == -1) goto LAB_1400016f0;
        lVar10 = lVar7 + 1;
        LOCK();
        bVar17 = lVar7 == DAT_1400d0d80;
        if (bVar17) {
          DAT_1400d0d80 = lVar10;
        }
        else {
          lVar7 = DAT_1400d0d80;
        }
        UNLOCK();
      } while (!bVar17);
      *plVar1 = lVar10;
    }
    if (DAT_1400cf738 == lVar10) {
      if (DAT_1400cf740 == 0xffffffff) {
        return 0xffffffff;
      }
      DAT_1400cf740 = DAT_1400cf740 + 1;
    }
    else {
      uVar12 = 0;
      LOCK();
      bVar17 = DAT_1400cf730 == 0;
      if (bVar17) {
        DAT_1400cf730 = 1;
      }
      else {
        uVar12 = (ulonglong)DAT_1400cf730;
      }
      UNLOCK();
      if (!bVar17) {
        return uVar12;
      }
      DAT_1400cf740 = 1;
      DAT_1400cf738 = lVar10;
    }
    if (DAT_1400cf748 != 0) goto LAB_1400016f0;
    DAT_1400cf748 = -1;
    if (DAT_1400cf750 == '\0') {
      pbVar11 = (byte *)0x0;
      pcVar13 = GetLastError_exref;
LAB_140001302:
      do {
        while( true ) {
          ppuVar16 = (undefined **)
                     ((byte *)CONCAT35(DAT_1400cf768._5_3_,(undefined5)DAT_1400cf768) +
                     -(longlong)pbVar11);
          if ((byte *)CONCAT35(DAT_1400cf768._5_3_,(undefined5)DAT_1400cf768) < pbVar11 ||
              ppuVar16 == (undefined **)0x0) {
            ppuVar15 = (undefined **)0x0;
            goto LAB_1400013f2;
          }
          DAT_1400cf750 = '\x01';
          ppuVar15 = (undefined **)((longlong)DAT_1400cf758 + (longlong)pbVar11);
          if (DAT_1400cf778 == 2) break;
          if ((DAT_1400cf778 & 1) == 0) {
LAB_14000155f:
            uVar6 = FUN_140002475(DAT_1400cf780,ppuVar15,(ulonglong)ppuVar16);
            uVar12 = (ulonglong)uVar6;
          }
          else {
LAB_140001343:
            pvVar8 = DAT_1400cf780;
            if ((ulonglong)(uRam00000001400cf771 >> 0x18) == 0) {
              ppuVar14 = ppuVar16;
              if ((undefined **)0xfff < ppuVar16) {
                ppuVar14 = (undefined **)0x1000;
              }
              FUN_14000b360((undefined8 *)local_70,(longlong)ppuVar15,(ulonglong)ppuVar14);
              if ((char)local_70[0] == '\0') {
                ppuVar15 = local_68;
                ppuVar14 = local_60;
              }
              else {
                if (local_68 == (undefined **)0x0) {
                  bVar2 = *(byte *)ppuVar15;
                  uVar12 = 1;
                  if (0x32 < (byte)(bVar2 + 0x3e)) goto LAB_140001698;
                  ppuVar15 = (undefined **)&DAT_140073528;
                  if (ppuVar16 < (undefined **)(ulonglong)(byte)(&DAT_14007506b)[bVar2]) {
                    ram0x0001400cf76d = CONCAT13(bVar2,DAT_1400cf768._5_3_);
                    uRam00000001400cf771 = CONCAT13(1,(undefined3)uRam00000001400cf771);
                    ppuVar15 = (undefined **)0x1;
                    uVar12 = 0;
                  }
                  goto LAB_140001608;
                }
                if ((ppuVar16 < local_68) ||
                   (FUN_14000b360((undefined8 *)local_58,(longlong)ppuVar15,(ulonglong)local_68),
                   local_58[0] != '\0')) goto LAB_1400016f0;
                ppuVar15 = local_50;
                ppuVar14 = local_48;
              }
              uVar12 = FUN_140012c25(pvVar8,(LPCSTR)ppuVar15,(ulonglong)ppuVar14);
            }
            else {
              if (3 < (byte)(uRam00000001400cf771 >> 0x18)) goto LAB_1400016f0;
              if ((char)*(byte *)ppuVar15 < -0x40) {
                (&DAT_1400cf770)[uRam00000001400cf771 >> 0x18] = *(byte *)ppuVar15;
                bVar2 = DAT_1400cf774 + 1;
                uRam00000001400cf771 = CONCAT13(bVar2,(undefined3)uRam00000001400cf771);
                ppuVar14 = (undefined **)
                           (ulonglong)(byte)(&DAT_14007506b)[ram0x0001400cf76d >> 0x18];
                if (bVar2 < (byte)(&DAT_14007506b)[ram0x0001400cf76d >> 0x18]) {
LAB_1400013a6:
                  ppuVar15 = (undefined **)0x1;
                  uVar12 = 0;
                }
                else {
                  if (4 < bVar2) goto LAB_1400016f0;
                  FUN_14000b360((undefined8 *)local_70,0x1400cf770,(ulonglong)bVar2);
                  uRam00000001400cf771 = uRam00000001400cf771 & 0xffffff;
                  uVar12 = 1;
                  if ((char)local_70[0] == '\0') {
                    if (local_60 != ppuVar14) goto LAB_1400016f0;
                    ppuVar15 = local_68;
                    uVar9 = FUN_140012c25(pvVar8,(LPCSTR)local_68,(ulonglong)ppuVar14);
                    if ((uVar9 & 1) == 0) {
                      if (ppuVar15 == ppuVar14) goto LAB_1400013a6;
                      goto LAB_1400016f0;
                    }
                  }
                  else {
                    ppuVar15 = (undefined **)&DAT_140073528;
                  }
                }
                pcVar13 = GetLastError_exref;
              }
              else {
                uRam00000001400cf771 = uRam00000001400cf771 & 0xffffff;
LAB_140001698:
                uVar12 = 1;
                ppuVar15 = (undefined **)&DAT_140073528;
              }
            }
          }
LAB_140001608:
          if ((uVar12 & 1) != 0) goto LAB_140001612;
LAB_1400016a7:
          DAT_1400cf750 = '\0';
          if (ppuVar15 == (undefined **)0x0) {
            ppuVar15 = &PTR_s_through_may_little_line_had_end_e_1400738f8_0x29f_140073540;
            goto LAB_1400013f2;
          }
          pbVar11 = pbVar11 + (longlong)ppuVar15;
        }
        pvVar8 = GetStdHandle(0xfffffff5);
        if (pvVar8 == (HANDLE)0xffffffffffffffff) {
          uVar6 = (*pcVar13)();
          if ((undefined **)PTR_PTR_1400cfa50 != &PTR_LAB_140073648) {
            PTR_PTR_1400cfa50 = (undefined *)&PTR_LAB_140073648;
          }
          ppuVar15 = (undefined **)((ulonglong)uVar6 << 0x20 | 2);
        }
        else {
          if (pvVar8 != (HANDLE)0x0) {
            local_70[0] = 0;
            BVar4 = GetConsoleMode(pvVar8,local_70);
            if ((BVar4 == 0) || (UVar5 = GetConsoleOutputCP(), UVar5 == 0xfde9)) {
              DAT_1400cf778 = 0;
              DAT_1400cf780 = pvVar8;
              goto LAB_14000155f;
            }
            DAT_1400cf778 = 1;
            DAT_1400cf780 = pvVar8;
            goto LAB_140001343;
          }
          ppuVar15 = (undefined **)0x600000002;
          if ((undefined **)PTR_PTR_1400cfa50 != &PTR_LAB_140073648) {
            PTR_PTR_1400cfa50 = (undefined *)&PTR_LAB_140073648;
          }
        }
LAB_140001612:
        uVar6 = (uint)ppuVar15 & 3;
        DAT_1400cf750 = '\0';
        switch(uVar6) {
        case 0:
          bVar2 = *(byte *)(ppuVar15 + 2);
joined_r0x000140001646:
          DAT_1400cf750 = '\0';
          if (bVar2 != 0x23) goto LAB_1400013f2;
          goto LAB_140001302;
        case 1:
          if (*(byte *)((longlong)ppuVar15 + -1) != 0x23) goto LAB_1400013f2;
          (**(code **)((longlong)ppuVar15 + 7))((byte *)((longlong)ppuVar15 + -1));
          goto LAB_140001302;
        }
        if (uVar6 != 2) {
          bVar2 = (byte)((ulonglong)ppuVar15 >> 0x20);
          if ((undefined **)0x2bffffffff < ppuVar15) {
            bVar2 = 0xff;
          }
          goto joined_r0x000140001646;
        }
        if ((int)((ulonglong)ppuVar15 >> 0x20) == 6) {
          ppuVar15 = ppuVar16;
          goto LAB_1400016a7;
        }
        DAT_1400cf750 = '\0';
        cVar3 = (**(code **)(PTR_PTR_1400cfa50 + 8))((ulonglong)ppuVar15 >> 0x20);
      } while (cVar3 != '\0');
LAB_1400013f2:
      if (pbVar11 != (byte *)0x0) {
        uVar12 = (longlong)CONCAT35(DAT_1400cf768._5_3_,(undefined5)DAT_1400cf768) -
                 (longlong)pbVar11;
        if ((byte *)CONCAT35(DAT_1400cf768._5_3_,(undefined5)DAT_1400cf768) < pbVar11)
        goto LAB_1400016f0;
        FUN_140023130(DAT_1400cf758,(undefined8 *)(pbVar11 + (longlong)DAT_1400cf758),uVar12);
        if (uVar12 <= CONCAT35(DAT_1400cf768._5_3_,(undefined5)DAT_1400cf768)) {
          DAT_1400cf768._0_5_ = (undefined5)uVar12;
          DAT_1400cf768._5_3_ = (undefined3)(uVar12 >> 0x28);
        }
      }
      if (((ppuVar15 != (undefined **)0x0) && (1 < ((uint)ppuVar15 & 3) - 2)) &&
         (((ulonglong)ppuVar15 & 3) != 0)) {
        (**(code **)((longlong)ppuVar15 + 7))((byte *)((longlong)ppuVar15 + -1));
      }
    }
    uVar12 = FUN_14000250d(DAT_1400cf758,DAT_1400cf760,1,1);
    bVar2 = DAT_1400cf730;
    DAT_1400cf750 = '\0';
    DAT_1400cf758 = (undefined8 *)0x1;
    DAT_1400cf760 = 0;
    DAT_1400cf768._0_5_ = 0;
    ram0x0001400cf76d = 0;
    uRam00000001400cf771 = 0;
    DAT_1400cf778 = 2;
    DAT_1400cf748 = DAT_1400cf748 + 1;
    DAT_1400cf740 = DAT_1400cf740 - 1;
    if (DAT_1400cf740 == 0) {
      DAT_1400cf738 = 0;
      LOCK();
      DAT_1400cf730 = 0;
      uVar12 = (ulonglong)bVar2;
      UNLOCK();
      if (bVar2 == 2) {
        uVar12 = WakeByAddressSingle(&DAT_1400cf730);
      }
    }
  }
  return uVar12;
}

