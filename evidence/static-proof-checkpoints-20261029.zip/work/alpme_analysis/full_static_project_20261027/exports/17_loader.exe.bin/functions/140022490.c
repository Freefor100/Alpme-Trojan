/* address=140022490 rva=0x22490 */

void FUN_140022490(longlong *param_1,longlong *param_2)

{
  longlong lVar1;
  longlong lVar2;
  char *pcVar3;
  
  if (((char)param_1[1] == '\0') || (*param_1 == 0)) {
    *param_2 = *param_1;
    *(undefined1 *)(param_2 + 1) = 0;
    return;
  }
  lVar1 = -1;
  do {
    lVar2 = lVar1;
    lVar1 = lVar2 + 1;
  } while (*(char *)(*param_1 + 1 + lVar2) != '\0');
  pcVar3 = thunk_FUN_14001ac00(lVar2 + 2U);
  if (pcVar3 != (char *)0x0) {
    FUN_140017540(pcVar3,lVar2 + 2U,*param_1);
    *param_2 = (longlong)pcVar3;
    *(undefined1 *)(param_2 + 1) = 1;
  }
  thunk_FUN_1400191b0((LPVOID)0x0);
  return;
}

