/* address=140014f40 rva=0x14f40 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */

uint FUN_140014f40(void)

{
  bool bVar1;
  bool bVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  longlong *plVar5;
  ulonglong uVar6;
  ulonglong *puVar7;
  uint unaff_EBX;
  undefined8 in_R9;
  undefined1 uVar8;
  
  uVar3 = FUN_140015240(1);
  if ((char)uVar3 == '\0') {
    FUN_140015570(7);
  }
  else {
    bVar1 = false;
    uVar8 = 0;
    uVar3 = FUN_1400151c0();
    unaff_EBX = (uint)uVar3 & 0xff;
    if (DAT_1400d0d90 != 1) {
      if (DAT_1400d0d90 == 0) {
        DAT_1400d0d90 = 1;
        uVar4 = FUN_140016f24((undefined8 *)&DAT_14007e0b8,(undefined8 *)&DAT_14007e0f0);
        if ((int)uVar4 != 0) {
          return 0xff;
        }
        FUN_140016eec((undefined8 *)&DAT_14007e0a0,(undefined8 *)&DAT_14007e0b0);
        DAT_1400d0d90 = 2;
      }
      else {
        bVar1 = true;
        uVar8 = 1;
      }
      FUN_140015210((char)uVar3);
      plVar5 = (longlong *)FUN_1400154c0();
      if ((*plVar5 != 0) && (uVar6 = FUN_140015120((longlong)plVar5), (char)uVar6 != '\0')) {
        (*(code *)*plVar5)(0,2,0,in_R9,uVar8);
      }
      puVar7 = (ulonglong *)FUN_1400154d0();
      if ((*puVar7 != 0) && (uVar6 = FUN_140015120((longlong)puVar7), (char)uVar6 != '\0')) {
        FUN_140015fc0(*puVar7);
      }
      FUN_140016b38();
      FUN_140015f10();
      FUN_140015f08();
      unaff_EBX = FUN_14000b800();
      bVar2 = FUN_1400154f0();
      if (bVar2) {
        if (!bVar1) {
          FUN_140015fa0();
        }
        FUN_140015280('\x01','\0');
        return unaff_EBX;
      }
      goto LAB_1400150af;
    }
  }
  FUN_140015570(7);
LAB_1400150af:
  FUN_140015f88(unaff_EBX);
                    /* WARNING: Subroutine does not return */
  FUN_140015f94(unaff_EBX);
}

