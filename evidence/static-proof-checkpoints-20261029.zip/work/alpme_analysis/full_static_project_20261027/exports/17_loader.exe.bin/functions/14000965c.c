/* address=14000965c rva=0x965c */

undefined8
FUN_14000965c(undefined8 *param_1,ulonglong param_2,ulonglong param_3,LPVOID param_4,
             ulonglong param_5)

{
  ulonglong uVar1;
  ulonglong uVar2;
  char local_28 [8];
  undefined8 local_20;
  
  if (CARRY8(param_2,param_3)) {
    local_20 = 0;
  }
  else {
    uVar1 = param_1[1] * 2;
    uVar2 = param_2 + param_3;
    if (param_2 + param_3 < uVar1) {
      uVar2 = uVar1;
    }
    uVar1 = (ulonglong)(param_5 == 1) * 4 + 4;
    if (uVar2 < uVar1) {
      uVar2 = uVar1;
    }
    FUN_140023eef((ulonglong *)local_28,(LPVOID)*param_1,param_1[1],uVar2,param_4,param_5);
    if (local_28[0] == '\0') {
      *param_1 = local_20;
      param_1[1] = uVar2;
      local_20 = 0xffffffffffffffff;
    }
  }
  return local_20;
}

