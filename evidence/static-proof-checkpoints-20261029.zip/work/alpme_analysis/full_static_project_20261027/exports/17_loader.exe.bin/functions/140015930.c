/* address=140015930 rva=0x15930 */

bool FUN_140015930(void)

{
  return DAT_1400d0e1c != 0;
}

