/* address=140024200 rva=0x24200 */

bool FUN_140024200(undefined8 *param_1)

{
  return *(int *)*param_1 == -0x3ffffffb;
}

