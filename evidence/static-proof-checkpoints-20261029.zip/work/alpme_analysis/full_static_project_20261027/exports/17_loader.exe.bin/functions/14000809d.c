/* address=14000809d rva=0x809d */

undefined **
FUN_14000809d(byte *param_1,undefined **param_2,undefined **param_3,undefined **param_4)

{
  code *pcVar1;
  char cVar2;
  uint uVar3;
  ulonglong uVar4;
  undefined **ppuVar5;
  bool bVar6;
  byte local_68 [4];
  undefined8 local_64;
  undefined4 local_58;
  undefined1 local_54;
  undefined4 local_50;
  undefined2 local_4c;
  undefined4 uStack_48;
  undefined1 uStack_44;
  undefined2 uStack_43;
  
  local_68[0] = 0;
  local_68[1] = 0;
  local_68[2] = 0;
  local_64 = 0;
  local_58 = 7;
  local_54 = 0;
  local_50 = 0;
  uStack_43 = 0;
  uStack_48 = 0;
  uStack_44 = 1;
  local_4c = 0x101;
  uVar4 = FUN_14000a9a9(param_1,(longlong)param_2,local_68);
  ppuVar5 = param_2;
  if ((uVar4 & 1) == 0) {
    do {
      ppuVar5 = param_3;
      uVar3 = FUN_140002475(param_2,param_3,(ulonglong)param_4);
      if ((uVar3 & 1) == 0) {
        if (ppuVar5 != (undefined **)0x0) {
          bVar6 = param_4 < ppuVar5;
          param_4 = (undefined **)((longlong)param_4 - (longlong)ppuVar5);
          if (bVar6) {
                    /* WARNING: Does not return */
            pcVar1 = (code *)invalidInstructionException();
            (*pcVar1)();
          }
          param_3 = (undefined **)((longlong)param_3 + (longlong)ppuVar5);
          goto LAB_140008177;
        }
        ppuVar5 = &PTR_DAT_140073510;
        goto LAB_14000818d;
      }
      switch((uint)ppuVar5 & 3) {
      case 0:
        cVar2 = *(char *)(ppuVar5 + 2);
        goto joined_r0x000140008162;
      case 1:
        if (*(char *)((longlong)ppuVar5 + -1) != '#') goto LAB_14000818d;
        (**(code **)((longlong)ppuVar5 + 7))((longlong)ppuVar5 + -1);
        break;
      case 2:
        cVar2 = (**(code **)(PTR_PTR_1400cfa50 + 8))((ulonglong)ppuVar5 >> 0x20);
        if (cVar2 == '\0') goto LAB_14000818d;
        break;
      case 3:
        cVar2 = (char)((ulonglong)ppuVar5 >> 0x20);
        if ((undefined **)0x2bffffffff < ppuVar5) {
          cVar2 = -1;
        }
joined_r0x000140008162:
        if (cVar2 != '#') goto LAB_14000818d;
      }
LAB_140008177:
    } while (param_4 != (undefined **)0x0);
    ppuVar5 = (undefined **)0x0;
LAB_14000818d:
    CloseHandle(param_2);
  }
  return ppuVar5;
}

