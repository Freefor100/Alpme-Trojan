/* address=140017280 rva=0x17280 */

void FUN_140017280(void)

{
  FUN_1400172a0();
  return;
}

