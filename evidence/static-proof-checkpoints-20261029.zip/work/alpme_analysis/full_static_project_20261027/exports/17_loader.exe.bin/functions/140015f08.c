/* address=140015f08 rva=0x15f08 */

undefined * FUN_140015f08(void)

{
  return &DAT_1400d0e30;
}

