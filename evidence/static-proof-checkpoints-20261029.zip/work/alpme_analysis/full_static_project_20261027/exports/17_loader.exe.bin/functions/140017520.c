/* address=140017520 rva=0x17520 */

void thunk_FUN_1400191b0(LPVOID param_1)

{
  BOOL BVar1;
  DWORD DVar2;
  uint uVar3;
  uint *puVar4;
  
  if ((param_1 != (LPVOID)0x0) && (BVar1 = HeapFree(DAT_1400d13b0,0,param_1), BVar1 == 0)) {
    DVar2 = GetLastError();
    uVar3 = FUN_14001a05c(DVar2);
    puVar4 = (uint *)FUN_140019fec();
    *puVar4 = uVar3;
  }
  return;
}

