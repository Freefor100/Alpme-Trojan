/* address=140016098 rva=0x16098 */

void FUN_140016098(uint param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  bool bVar2;
  HMODULE pHVar3;
  undefined7 extraout_var;
  ulonglong uVar4;
  int *piVar5;
  undefined4 local_res10 [2];
  int local_res18 [2];
  undefined1 local_res20 [8];
  undefined1 local_38 [4];
  int local_34 [3];
  undefined8 local_28;
  undefined4 *local_20;
  int *local_18;
  undefined1 *local_10;
  
  local_28 = 0xfffffffffffffffe;
  local_res10[0] = param_2;
  local_res18[0] = param_3;
  if (param_3 == 0) {
    pHVar3 = GetModuleHandleW((LPCWSTR)0x0);
    if ((((pHVar3 != (HMODULE)0x0) && ((short)pHVar3->unused == 0x5a4d)) &&
        (piVar5 = (int *)((longlong)&pHVar3->unused + (longlong)pHVar3[0xf].unused),
        *piVar5 == 0x4550)) &&
       ((((short)piVar5[6] == 0x20b && (0xe < (uint)piVar5[0x21])) && (piVar5[0x3e] != 0)))) {
      FUN_140016004(param_1);
    }
  }
  local_res20[0] = 0;
  local_20 = local_res10;
  local_18 = local_res18;
  local_10 = local_res20;
  local_34[0] = 2;
  local_34[1] = 2;
  FUN_14001623c(local_38,local_34 + 1,&local_20,local_34);
  if (local_res18[0] == 0) {
    bVar2 = FUN_14001a184();
    if ((int)CONCAT71(extraout_var,bVar2) == 1) {
      bVar2 = false;
    }
    else {
      uVar4 = FUN_14001a150();
      bVar2 = (char)uVar4 == '\0';
    }
    if (local_res18[0] == 0) {
      FUN_140016068(param_1,bVar2);
      pcVar1 = (code *)swi(3);
      (*pcVar1)();
      return;
    }
  }
  return;
}

