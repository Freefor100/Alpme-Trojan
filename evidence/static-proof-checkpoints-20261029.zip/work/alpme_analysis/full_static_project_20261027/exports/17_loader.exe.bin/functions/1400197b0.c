/* address=1400197b0 rva=0x197b0 */

ulonglong FUN_1400197b0(ulonglong param_1)

{
  byte bVar1;
  byte bVar2;
  ulonglong uVar3;
  
  FUN_140017cb4(0);
  bVar2 = (byte)DAT_1400d02c0 & 0x3f;
  uVar3 = DAT_1400d02c0 ^ DAT_1400d17f0;
  bVar1 = 0x40 - bVar2 & 0x3f;
  DAT_1400d17f0 = (param_1 >> bVar1 | param_1 << 0x40 - bVar1) ^ DAT_1400d02c0;
  FUN_140017cd0(0);
  return uVar3 >> bVar2 | uVar3 << 0x40 - bVar2;
}

