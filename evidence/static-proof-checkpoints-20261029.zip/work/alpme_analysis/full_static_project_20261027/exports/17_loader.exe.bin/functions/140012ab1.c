/* address=140012ab1 rva=0x12ab1 */

void FUN_140012ab1(undefined8 *param_1,undefined8 *param_2,ulonglong param_3)

{
  code *pcVar1;
  char local_40 [8];
  undefined8 *local_38;
  undefined8 local_30;
  
  FUN_1400146e3((undefined8 *)local_40,param_3,0,1,1);
  if (local_40[0] != '\0') {
                    /* WARNING: Does not return */
    pcVar1 = (code *)invalidInstructionException();
    (*pcVar1)();
  }
  if (param_3 != 0) {
    FUN_140023130(local_38,param_2,param_3);
  }
  *param_1 = local_38;
  param_1[1] = local_30;
  param_1[2] = param_3;
  return;
}

