/* address=140016c08 rva=0x16c08 */

undefined8 FUN_140016c08(void)

{
  undefined8 uVar1;
  char *pcVar2;
  undefined8 *puVar3;
  
  uVar1 = 0;
  if (DAT_1400d0fb8 == (undefined8 *)0x0) {
    FUN_1400185dc();
    pcVar2 = FUN_14001c3c8();
    if (pcVar2 == (char *)0x0) {
      FUN_1400191b0((LPVOID)0x0);
      uVar1 = 0xffffffff;
    }
    else {
      puVar3 = FUN_140016cf8(pcVar2);
      if (puVar3 == (undefined8 *)0x0) {
        uVar1 = 0xffffffff;
      }
      else {
        DAT_1400d0fb8 = puVar3;
        DAT_1400d0fd0 = puVar3;
      }
      FUN_1400191b0((LPVOID)0x0);
      FUN_1400191b0(pcVar2);
    }
  }
  else {
    uVar1 = 0;
  }
  return uVar1;
}

