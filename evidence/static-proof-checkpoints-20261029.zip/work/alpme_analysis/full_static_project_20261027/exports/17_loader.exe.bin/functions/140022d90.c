/* address=140022d90 rva=0x22d90 */

void FUN_140022d90(void)

{
  if (DAT_1400d0cc0 < (HANDLE)0xfffffffffffffffe) {
    CloseHandle(DAT_1400d0cc0);
  }
  return;
}

