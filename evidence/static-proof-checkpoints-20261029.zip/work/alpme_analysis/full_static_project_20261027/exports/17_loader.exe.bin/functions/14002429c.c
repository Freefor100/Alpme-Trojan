/* address=14002429c rva=0x2429c */

void FUN_14002429c(undefined8 param_1,longlong param_2)

{
  if (*(char *)(param_2 + 0x70) != '\0') {
    FUN_140017cd0(3);
  }
  return;
}

