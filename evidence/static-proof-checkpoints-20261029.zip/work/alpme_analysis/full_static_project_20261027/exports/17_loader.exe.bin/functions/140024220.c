/* address=140024220 rva=0x24220 */

void FUN_140024220(void)

{
  FUN_140017cd0(7);
  return;
}

