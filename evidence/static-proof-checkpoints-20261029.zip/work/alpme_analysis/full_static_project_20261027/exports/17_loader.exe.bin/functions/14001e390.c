/* address=14001e390 rva=0x1e390 */

undefined8 FUN_14001e390(uint param_1)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  uint local_res8 [2];
  undefined1 local_res10 [8];
  uint local_res18 [2];
  uint local_res20 [2];
  uint *local_18 [3];
  
  local_res8[0] = param_1;
  if (param_1 == 0xfffffffe) {
    puVar1 = FUN_140019fec();
    *(undefined4 *)puVar1 = 9;
  }
  else {
    if (((-1 < (int)param_1) && (param_1 < DAT_1400d17c0)) &&
       ((*(byte *)((&DAT_1400d13c0)[(longlong)(int)param_1 >> 6] + 0x38 +
                  (ulonglong)(param_1 & 0x3f) * 0x48) & 1) != 0)) {
      local_18[0] = local_res8;
      local_res18[0] = param_1;
      local_res20[0] = param_1;
      uVar2 = FUN_14001e424(local_res10,local_res20,local_18,local_res18);
      return uVar2;
    }
    puVar1 = FUN_140019fec();
    *(undefined4 *)puVar1 = 9;
    FUN_1400192c4();
  }
  return 0xffffffff;
}

