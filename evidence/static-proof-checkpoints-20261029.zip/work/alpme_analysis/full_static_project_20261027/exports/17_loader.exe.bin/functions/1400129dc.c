/* address=1400129dc rva=0x129dc */

void FUN_1400129dc(undefined8 *param_1)

{
  undefined8 local_8;
  
  local_8 = *param_1;
  FUN_140001201(&local_8);
  return;
}

