/* address=14001f8e0 rva=0x1f8e0 */

undefined8 * FUN_14001f8e0(undefined8 *param_1,uint param_2)

{
  *param_1 = std::exception::vftable;
  FUN_140022530(param_1 + 1);
  if ((param_2 & 1) != 0) {
    thunk_FUN_1400191b0(param_1);
  }
  return param_1;
}

