/* address=140015240 rva=0x15240 */

ulonglong FUN_140015240(int param_1)

{
  undefined4 uVar1;
  undefined4 extraout_var_00;
  undefined8 uVar2;
  uint7 extraout_var;
  ulonglong uVar3;
  
  if (param_1 == 0) {
    DAT_1400d0da0 = 1;
  }
  FUN_140015680();
  uVar1 = FUN_140015d40();
  uVar3 = CONCAT44(extraout_var_00,uVar1);
  if ((char)uVar1 != '\0') {
    uVar2 = FUN_140015ebc();
    if ((char)uVar2 != '\0') {
      return CONCAT71((int7)((ulonglong)uVar2 >> 8),1);
    }
    FUN_140015d70('\0');
    uVar3 = (ulonglong)extraout_var << 8;
  }
  return uVar3 & 0xffffffffffffff00;
}

