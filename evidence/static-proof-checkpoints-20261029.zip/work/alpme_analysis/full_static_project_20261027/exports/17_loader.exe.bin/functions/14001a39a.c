/* address=14001a39a rva=0x1a39a */

void FUN_14001a39a(void)

{
  uint uVar1;
  uint uVar2;
  PRUNTIME_FUNCTION p_Var3;
  ulonglong uVar4;
  longlong lVar5;
  longlong unaff_RBP;
  int unaff_ESI;
  uint uVar6;
  ulonglong unaff_RDI;
  longlong lVar7;
  longlong *unaff_R12;
  undefined8 *unaff_R14;
  DWORD64 *unaff_R15;
  ulonglong uStack0000000000000050;
  
  do {
    uVar6 = (int)unaff_RDI - 1;
    unaff_RDI = (ulonglong)uVar6;
    lVar5 = (longlong)*(int *)(unaff_RBP + 0x10) + unaff_RDI * 0x14 + unaff_R15[1];
    if ((*(int *)(lVar5 + 4) < unaff_ESI) && (unaff_ESI <= *(int *)(lVar5 + 8))) {
      p_Var3 = RtlLookupFunctionEntry(*unaff_R15,&uStack0000000000000050,(PUNWIND_HISTORY_TABLE)0x0)
      ;
      lVar7 = (longlong)*(int *)(lVar5 + 0x10) + uStack0000000000000050;
      uVar1 = *(uint *)(lVar5 + 0xc);
      uVar4 = 0;
      if (uVar1 != 0) {
        do {
          if ((longlong)*(int *)(lVar7 + 0xc + uVar4 * 0x14) == (ulonglong)p_Var3->BeginAddress)
          goto LAB_14001a410;
          uVar2 = (int)uVar4 + 1;
          uVar4 = (ulonglong)uVar2;
        } while (uVar2 < uVar1);
      }
      if ((uint)uVar4 < uVar1) {
LAB_14001a410:
        *unaff_R14 = *(undefined8 *)((longlong)*(int *)(lVar7 + 0x10 + uVar4 * 0x14) + *unaff_R12);
        return;
      }
    }
    if (uVar6 == 0) {
      return;
    }
  } while( true );
}

