/* address=140017e20 rva=0x17e20 */

undefined8 * FUN_140017e20(void)

{
  DWORD dwErrCode;
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)0x0;
  if (DAT_1400d13b8 == '\0') {
    dwErrCode = GetLastError();
    if (DAT_1400d0338 == 0xffffffff) {
      puVar1 = (undefined8 *)0x0;
    }
    else {
      puVar1 = FlsGetValue(DAT_1400d0338);
    }
    if (puVar1 != (undefined8 *)0xffffffffffffffff) {
      if (puVar1 == (undefined8 *)0x0) {
        puVar1 = FUN_14001815c();
      }
      puVar2 = puVar1;
    }
    SetLastError(dwErrCode);
  }
  else {
    if (DAT_1400d0338 == 0xffffffff) {
      puVar1 = (undefined8 *)0x0;
    }
    else {
      puVar1 = (undefined8 *)FUN_14001783c();
    }
    if (puVar1 != (undefined8 *)0xffffffffffffffff) {
      if (puVar1 == (undefined8 *)0x0) {
        puVar1 = FUN_14001815c();
      }
      puVar2 = puVar1;
    }
  }
  return puVar2;
}

