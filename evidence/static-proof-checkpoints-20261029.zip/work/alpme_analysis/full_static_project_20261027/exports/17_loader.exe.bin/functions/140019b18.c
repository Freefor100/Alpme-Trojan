/* address=140019b18 rva=0x19b18 */

undefined4 FUN_140019b18(int *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  undefined8 uVar3;
  longlong lVar4;
  longlong local_48 [2];
  undefined1 local_38;
  undefined *local_30;
  undefined *puStack_28;
  char local_20;
  undefined4 local_1c;
  char local_18;
  undefined4 local_14;
  char local_10;
  
  local_48[0] = 0;
  local_20 = DAT_1400d0e78 == 0;
  local_38 = 0;
  local_18 = '\0';
  local_10 = '\0';
  if ((bool)local_20) {
    local_30 = PTR_PTR_1400d09d8;
    puStack_28 = PTR_DAT_1400d09e0;
  }
  if (param_1 == (int *)0x0) {
    uVar1 = FUN_140019c78('\0');
    goto LAB_140019b9d;
  }
  uVar3 = FUN_140019bec(param_1,local_48);
  if ((int)uVar3 == 0) {
    if (((uint)param_1[5] >> 0xb & 1) != 0) {
      uVar2 = FUN_14001e4b0((longlong)param_1);
      uVar3 = FUN_14001e390(uVar2);
      if ((int)uVar3 != 0) goto LAB_140019b78;
    }
    uVar1 = 0;
  }
  else {
LAB_140019b78:
    uVar1 = 0xffffffff;
  }
LAB_140019b9d:
  if (local_20 == '\x02') {
    *(uint *)(local_48[0] + 0x3a8) = *(uint *)(local_48[0] + 0x3a8) & 0xfffffffd;
  }
  if (local_18 != '\0') {
    lVar4 = FUN_14001955c(local_48);
    *(undefined4 *)(lVar4 + 0x20) = local_1c;
  }
  if (local_10 != '\0') {
    lVar4 = FUN_14001955c(local_48);
    *(undefined4 *)(lVar4 + 0x24) = local_14;
  }
  return uVar1;
}

