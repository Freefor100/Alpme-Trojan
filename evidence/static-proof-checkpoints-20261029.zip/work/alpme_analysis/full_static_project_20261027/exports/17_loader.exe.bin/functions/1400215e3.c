/* address=1400215e3 rva=0x215e3 */

int FUN_1400215e3(void)

{
  uint *puVar1;
  ushort *puVar2;
  int iVar3;
  int iVar4;
  longlong lVar5;
  undefined8 *puVar6;
  char cVar7;
  longlong unaff_RBP;
  byte *unaff_RSI;
  ulonglong unaff_RDI;
  byte *unaff_R14;
  
  *(undefined1 *)(unaff_RBP + -8) = 0;
  lVar5 = FUN_140017dc0();
  *(longlong *)(unaff_RBP + -0x20) = lVar5;
  *(undefined8 *)(unaff_RBP + -0x18) = *(undefined8 *)(lVar5 + 0x90);
  *(undefined8 *)(unaff_RBP + -0x10) = *(undefined8 *)(lVar5 + 0x88);
  FUN_14001e2a4(lVar5,(longlong *)(unaff_RBP + -0x18));
  FUN_14001e2d8(*(longlong *)(unaff_RBP + -0x20),(longlong *)(unaff_RBP + -0x10));
  lVar5 = *(longlong *)(unaff_RBP + -0x20);
  if ((*(uint *)(lVar5 + 0x3a8) & 2) == 0) {
    *(uint *)(lVar5 + 0x3a8) = *(uint *)(lVar5 + 0x3a8) | 2;
    cVar7 = '\x01';
    lVar5 = *(longlong *)(unaff_RBP + -0x20);
    *(undefined1 *)(unaff_RBP + -8) = 1;
  }
  else {
    cVar7 = *(char *)(unaff_RBP + -8);
  }
  if (unaff_RDI == 0) {
    if (cVar7 != '\0') {
      *(uint *)(lVar5 + 0x3a8) = *(uint *)(lVar5 + 0x3a8) & 0xfffffffd;
    }
    iVar3 = 0;
  }
  else if ((unaff_R14 == (byte *)0x0) || (unaff_RSI == (byte *)0x0)) {
    puVar6 = FUN_140019fec();
    *(undefined4 *)puVar6 = 0x16;
    FUN_1400192c4();
    if (*(char *)(unaff_RBP + -8) != '\0') {
      puVar1 = (uint *)(*(longlong *)(unaff_RBP + -0x20) + 0x3a8);
      *puVar1 = *puVar1 & 0xfffffffd;
    }
    iVar3 = 0x7fffffff;
  }
  else {
    iVar3 = 0x7fffffff;
    if (unaff_RDI < 0x80000000) {
      puVar2 = *(ushort **)(*(longlong *)(unaff_RBP + -0x18) + 0x130);
      if (puVar2 == (ushort *)0x0) {
        iVar3 = FUN_1400226b0(unaff_R14,unaff_RSI,unaff_RDI,(undefined8 *)(unaff_RBP + -0x18));
        if (*(char *)(unaff_RBP + -8) != '\0') {
          puVar1 = (uint *)(*(longlong *)(unaff_RBP + -0x20) + 0x3a8);
          *puVar1 = *puVar1 & 0xfffffffd;
        }
        return iVar3;
      }
      iVar4 = FUN_140022844((undefined4 *)(unaff_RBP + -0x18),puVar2,0x1001,unaff_R14,(int)unaff_RDI
                            ,unaff_RSI,(int)unaff_RDI,
                            *(UINT *)(*(longlong *)(unaff_RBP + -0x18) + 0x14));
      if (iVar4 == 0) {
        puVar6 = FUN_140019fec();
        *(undefined4 *)puVar6 = 0x16;
      }
      else {
        iVar3 = iVar4 + -2;
      }
    }
    else {
      puVar6 = FUN_140019fec();
      *(undefined4 *)puVar6 = 0x16;
      FUN_1400192c4();
    }
    if (*(char *)(unaff_RBP + -8) != '\0') {
      puVar1 = (uint *)(*(longlong *)(unaff_RBP + -0x20) + 0x3a8);
      *puVar1 = *puVar1 & 0xfffffffd;
    }
  }
  return iVar3;
}

