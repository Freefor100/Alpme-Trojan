/* address=140018378 rva=0x18378 */

undefined1 FUN_140018378(void)

{
  ulonglong uVar1;
  
  uVar1 = 0;
  do {
    if (*(LPCRITICAL_SECTION *)((longlong)&DAT_1400d13c0 + uVar1) != (LPCRITICAL_SECTION)0x0) {
      FUN_14001cafc(*(LPCRITICAL_SECTION *)((longlong)&DAT_1400d13c0 + uVar1));
      *(undefined8 *)((longlong)&DAT_1400d13c0 + uVar1) = 0;
    }
    uVar1 = uVar1 + 8;
  } while (uVar1 < 0x400);
  return 1;
}

