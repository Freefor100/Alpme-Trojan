/* address=140019e64 rva=0x19e64 */

void FUN_140019e64(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x000140019e68. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  LeaveCriticalSection(param_1 + 0x30);
  return;
}

