/* address=140020df8 rva=0x20df8 */

void FUN_140020df8(void)

{
  undefined1 uStack0000000000000000;
  ulonglong in_stack_00000410;
  
  FUN_14001b4d0(in_stack_00000410 ^ (ulonglong)&uStack0000000000000000);
  return;
}

