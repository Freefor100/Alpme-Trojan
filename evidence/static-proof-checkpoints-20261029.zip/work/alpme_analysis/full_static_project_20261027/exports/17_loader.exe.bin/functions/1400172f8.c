/* address=1400172f8 rva=0x172f8 */

void FUN_1400172f8(void)

{
  code *pcVar1;
  BOOL BVar2;
  longlong lVar3;
  undefined1 *puVar4;
  undefined1 auStack_28 [8];
  undefined1 auStack_20 [32];
  
  lVar3 = FUN_14001983c();
  if (lVar3 != 0) {
    FUN_14001986c(0x16);
  }
  puVar4 = auStack_28;
  if ((DAT_1400d0330 & 2) != 0) {
    BVar2 = IsProcessorFeaturePresent(0x17);
    puVar4 = auStack_28;
    if (BVar2 != 0) {
      pcVar1 = (code *)swi(0x29);
      (*pcVar1)(7);
      puVar4 = auStack_20;
    }
    *(undefined8 *)(puVar4 + -8) = 0x140017343;
    FUN_14001932c(3,0x40000015,1);
  }
                    /* WARNING: Subroutine does not return */
  *(undefined **)(puVar4 + -8) = &UNK_14001734d;
  FUN_140015f94(3);
}

