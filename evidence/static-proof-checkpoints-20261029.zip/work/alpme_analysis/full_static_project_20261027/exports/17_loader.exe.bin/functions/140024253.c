/* address=140024253 rva=0x24253 */

void FUN_140024253(void)

{
  FUN_140017cd0(5);
  return;
}

