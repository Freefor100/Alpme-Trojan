/* address=1400167f0 rva=0x167f0 */

undefined8 FUN_1400167f0(undefined8 *param_1)

{
  ulonglong uVar1;
  LPVOID pvVar2;
  undefined8 uVar3;
  byte bVar4;
  ulonglong *puVar5;
  ulonglong uVar6;
  LPVOID pvVar7;
  ulonglong uVar8;
  ulonglong *puVar9;
  ulonglong *puVar10;
  
  puVar5 = *(ulonglong **)*param_1;
  if (puVar5 == (ulonglong *)0x0) {
LAB_140016982:
    uVar3 = 0xffffffff;
  }
  else {
    bVar4 = (byte)DAT_1400d02c0 & 0x3f;
    pvVar7 = (LPVOID)((DAT_1400d02c0 ^ *puVar5) >> bVar4 | (DAT_1400d02c0 ^ *puVar5) << 0x40 - bVar4
                     );
    puVar10 = (ulonglong *)
              ((DAT_1400d02c0 ^ puVar5[1]) >> bVar4 | (DAT_1400d02c0 ^ puVar5[1]) << 0x40 - bVar4);
    puVar5 = (ulonglong *)
             ((DAT_1400d02c0 ^ puVar5[2]) >> bVar4 | (DAT_1400d02c0 ^ puVar5[2]) << 0x40 - bVar4);
    if (puVar10 == puVar5) {
      uVar6 = (longlong)puVar5 - (longlong)pvVar7 >> 3;
      uVar8 = uVar6;
      if (0x200 < uVar6) {
        uVar8 = 0x200;
      }
      uVar8 = uVar8 + uVar6;
      if (uVar8 == 0) {
        uVar8 = 0x20;
      }
      if (uVar8 < uVar6) {
LAB_140016892:
        uVar8 = uVar6 + 4;
        pvVar2 = FUN_14001c240(pvVar7,uVar8,8);
        FUN_1400191b0((LPVOID)0x0);
        if (pvVar2 == (LPVOID)0x0) goto LAB_140016982;
      }
      else {
        pvVar2 = FUN_14001c240(pvVar7,uVar8,8);
        FUN_1400191b0((LPVOID)0x0);
        if (pvVar2 == (LPVOID)0x0) goto LAB_140016892;
      }
      pvVar7 = pvVar2;
      uVar1 = DAT_1400d02c0;
      puVar10 = (ulonglong *)((longlong)pvVar7 + uVar6 * 8);
      puVar5 = (ulonglong *)((longlong)pvVar7 + uVar8 * 8);
      uVar8 = (ulonglong)((longlong)puVar5 + (7 - (longlong)puVar10)) >> 3;
      if (puVar5 < puVar10) {
        uVar8 = 0;
      }
      if (uVar8 != 0) {
        puVar9 = puVar10;
        for (; uVar8 != 0; uVar8 = uVar8 - 1) {
          *puVar9 = uVar1;
          puVar9 = puVar9 + 1;
        }
      }
    }
    bVar4 = -((byte)DAT_1400d02c0 & 0x3f) & 0x3f;
    *puVar10 = (*(ulonglong *)param_1[1] >> bVar4 | *(ulonglong *)param_1[1] << 0x40 - bVar4) ^
               DAT_1400d02c0;
    bVar4 = -((byte)DAT_1400d02c0 & 0x3f) & 0x3f;
    **(ulonglong **)*param_1 =
         ((ulonglong)pvVar7 >> bVar4 | (longlong)pvVar7 << 0x40 - bVar4) ^ DAT_1400d02c0;
    bVar4 = -((byte)DAT_1400d02c0 & 0x3f) & 0x3f;
    *(ulonglong *)(*(longlong *)*param_1 + 8) =
         ((ulonglong)(puVar10 + 1) >> bVar4 | (longlong)(puVar10 + 1) << 0x40 - bVar4) ^
         DAT_1400d02c0;
    bVar4 = 0x40 - ((byte)DAT_1400d02c0 & 0x3f) & 0x3f;
    uVar3 = 0;
    *(ulonglong *)(*(longlong *)*param_1 + 0x10) =
         ((ulonglong)puVar5 >> bVar4 | (longlong)puVar5 << 0x40 - bVar4) ^ DAT_1400d02c0;
  }
  return uVar3;
}

