/* address=140014d71 rva=0x14d71 */

undefined1 * FUN_140014d71(undefined8 *param_1,ulonglong param_2)

{
  code *pcVar1;
  undefined8 *puVar2;
  undefined1 *puVar3;
  undefined8 local_20;
  undefined8 uStack_18;
  undefined8 local_10;
  
  FUN_140012ab1(&local_20,param_1,param_2);
  puVar2 = FUN_1400128ed(0,0x18);
  if (puVar2 != (undefined8 *)0x0) {
    puVar2[2] = local_10;
    *puVar2 = local_20;
    puVar2[1] = uStack_18;
    puVar3 = FUN_1400128ed(0,0x28);
    if (puVar3 != (undefined1 *)0x0) {
      *puVar3 = 0x14;
      *(code **)(puVar3 + 8) = FUN_140001046;
      *(undefined8 **)(puVar3 + 0x10) = puVar2;
      *(undefined ***)(puVar3 + 0x18) = &PTR_LAB_140073660;
      *(code **)(puVar3 + 0x20) = FUN_14000b2d9;
      return puVar3 + 1;
    }
  }
                    /* WARNING: Does not return */
  pcVar1 = (code *)invalidInstructionException();
  (*pcVar1)();
}

