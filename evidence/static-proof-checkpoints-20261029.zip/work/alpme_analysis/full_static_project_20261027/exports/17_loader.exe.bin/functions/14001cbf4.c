/* address=14001cbf4 rva=0x1cbf4 */

void FUN_14001cbf4(uint param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00014001cc14. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  EnterCriticalSection
            ((&DAT_1400d13c0)[(longlong)(int)param_1 >> 6] + (ulonglong)(param_1 & 0x3f) * 0x48);
  return;
}

