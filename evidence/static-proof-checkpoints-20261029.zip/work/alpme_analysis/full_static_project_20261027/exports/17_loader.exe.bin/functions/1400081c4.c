/* address=1400081c4 rva=0x81c4 */

undefined8 FUN_1400081c4(HANDLE param_1,longlong *param_2)

{
  code *pcVar1;
  char cVar2;
  char cVar3;
  longlong lVar4;
  undefined8 *puVar5;
  uint uVar6;
  undefined8 *puVar7;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  
  local_58 = 0;
  uStack_50 = 0;
  local_68 = 0;
  uStack_60 = 0;
LAB_1400081fe:
  puVar5 = &local_68;
  lVar4 = FUN_140012db6(param_1,&local_68,0x20);
  if (lVar4 != 1) {
    puVar7 = puVar5;
    if ((undefined8 *)0x20 < puVar5) {
                    /* WARNING: Does not return */
      pcVar1 = (code *)invalidInstructionException();
      (*pcVar1)();
    }
LAB_1400082b6:
    FUN_14000100e(param_2,(ulonglong)puVar7);
    lVar4 = param_2[2];
    if (puVar7 != (undefined8 *)0x0) {
      FUN_140023130((undefined8 *)(*param_2 + lVar4),&local_68,(ulonglong)puVar7);
    }
    param_2[2] = lVar4 + (longlong)puVar7;
    return 0;
  }
  uVar6 = (uint)puVar5 & 3;
  cVar2 = (char)((ulonglong)puVar5 >> 0x20);
  switch(uVar6) {
  case 0:
    cVar3 = *(char *)(puVar5 + 2);
    break;
  case 1:
    cVar3 = *(char *)((longlong)puVar5 - 1);
    break;
  case 2:
    cVar3 = (**(code **)PTR_PTR_1400cfa50)((ulonglong)puVar5 >> 0x20);
    break;
  case 3:
    cVar3 = cVar2;
  }
  if (cVar3 == '\v') {
    puVar7 = (undefined8 *)0x0;
    if ((1 < uVar6 - 2) && (((ulonglong)puVar5 & 3) != 0)) {
      (**(code **)((longlong)puVar5 + 7))((longlong)puVar5 - 1);
      puVar7 = (undefined8 *)0x0;
    }
    goto LAB_1400082b6;
  }
  switch(uVar6) {
  case 0:
    cVar2 = *(char *)(puVar5 + 2);
    break;
  case 1:
    if (*(char *)((longlong)puVar5 - 1) != '#') {
      return 1;
    }
    (**(code **)((longlong)puVar5 + 7))((longlong)puVar5 - 1);
    goto LAB_1400081fe;
  case 2:
    goto switchD_140008305_caseD_2;
  case 3:
    if ((undefined8 *)0x2bffffffff < puVar5) {
      cVar2 = -1;
    }
  }
  if (cVar2 != '#') {
    return 1;
  }
  goto LAB_1400081fe;
switchD_140008305_caseD_2:
  cVar2 = (**(code **)(PTR_PTR_1400cfa50 + 8))((ulonglong)puVar5 >> 0x20);
  if (cVar2 == '\0') {
    return 1;
  }
  goto LAB_1400081fe;
}

