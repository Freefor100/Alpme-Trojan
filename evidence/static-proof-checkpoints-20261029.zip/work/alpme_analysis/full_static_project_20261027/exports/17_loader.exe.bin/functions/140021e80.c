/* address=140021e80 rva=0x21e80 */

undefined8 FUN_140021e80(int *param_1,ulonglong param_2,ULONG_PTR param_3,ulonglong *param_4)

{
  ulonglong uVar1;
  undefined8 uVar2;
  
  uVar1 = param_4[7];
  FUN_14001b2c0(param_2,(longlong)param_4,(int *)(uVar1 + 4));
  if ((*(uint *)(uVar1 + 4) & ((*(byte *)(param_1 + 1) & 0x66) != 0) + 1) == 0) {
    return 1;
  }
  uVar2 = FUN_14001a7e0(param_1,param_2,param_3,param_4);
  return uVar2;
}

