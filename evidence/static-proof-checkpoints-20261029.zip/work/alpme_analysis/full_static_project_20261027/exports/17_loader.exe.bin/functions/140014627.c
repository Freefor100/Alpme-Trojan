/* address=140014627 rva=0x14627 */

ulonglong FUN_140014627(uint param_1)

{
  longlong lVar1;
  longlong lVar2;
  uint uVar3;
  ulonglong uVar4;
  uint uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  
  uVar6 = 0x3c;
  lVar1 = 0;
  do {
    lVar2 = lVar1 + (uVar6 >> 1);
    if (param_1 < ((&DAT_1400736e8)[lVar2] & 0x1fffff)) {
      lVar2 = lVar1;
    }
    uVar6 = uVar6 - (uVar6 >> 1);
    lVar1 = lVar2;
  } while (1 < uVar6);
  uVar4 = (ulonglong)((&DAT_1400736e8)[lVar2] * 0x800 == param_1 * 0x800) + lVar2 +
          (ulonglong)((uint)((&DAT_1400736e8)[lVar2] * 0x800) < param_1 * 0x800);
  uVar6 = (ulonglong)((uint)(&DAT_1400736e8)[uVar4] >> 0x15);
  uVar7 = 0x5b5;
  if ((uVar4 < 0x3b) &&
     (uVar7 = (ulonglong)(*(uint *)(&DAT_1400736ec + uVar4 * 4) >> 0x15), uVar4 == 0)) {
    uVar5 = 0;
  }
  else {
    uVar5 = *(uint *)(&DAT_1400736e4 + uVar4 * 4) & 0x1fffff;
  }
  if (~uVar6 + uVar7 != 0) {
    uVar3 = 0;
    do {
      uVar3 = (byte)"VRezccJ8npnB0RE_vIZhwKtEynR88Str8NzukcA7H7eLkFGROhagh0Vof show them mother think over are now little or did must "
                    [uVar6 + 0x71] + uVar3;
      if (param_1 - uVar5 < uVar3) break;
      uVar6 = uVar6 + 1;
    } while (uVar7 - 1 != uVar6);
  }
  return uVar6 & 0xffffffffffffff01;
}

