/* address=14001f880 rva=0x1f880 */

undefined8 * FUN_14001f880(undefined8 *param_1,longlong param_2)

{
  *param_1 = std::exception::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  FUN_140022490((longlong *)(param_2 + 8),param_1 + 1);
  return param_1;
}

