/* address=140015fc0 rva=0x15fc0 */

void FUN_140015fc0(ulonglong param_1)

{
  byte bVar1;
  
  if (DAT_1400d0e68 != DAT_1400d02c0) {
                    /* WARNING: Subroutine does not return */
    FUN_14001715c();
  }
  bVar1 = 0x40 - ((byte)DAT_1400d02c0 & 0x3f) & 0x3f;
  DAT_1400d0e68 = (param_1 >> bVar1 | param_1 << 0x40 - bVar1) ^ DAT_1400d02c0;
  return;
}

