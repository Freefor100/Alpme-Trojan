/* address=140018254 rva=0x18254 */

void FUN_140018254(undefined8 param_1,int *param_2,undefined8 *param_3,int *param_4)

{
  FUN_140017cb4(*param_2);
  FUN_140017f2c(*(longlong *)*param_3,**(longlong **)param_3[1]);
  FUN_140017cd0(*param_4);
  return;
}

