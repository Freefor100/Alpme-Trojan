/* address=140012b23 rva=0x12b23 */

void FUN_140012b23(longlong param_1,longlong param_2,undefined4 param_3,undefined8 param_4,
                  undefined8 param_5)

{
  undefined8 *puVar1;
  ushort uVar2;
  longlong lVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  
  uVar2 = *(ushort *)(param_2 + 0x98);
  uVar5 = (ulonglong)uVar2;
  puVar1 = (undefined8 *)(param_2 + param_1 * 4);
  uVar4 = param_1 + 1;
  if (uVar5 < uVar4) {
    *(undefined4 *)puVar1 = param_3;
  }
  else {
    FUN_140023130((undefined8 *)(param_2 + uVar4 * 4),puVar1,(uVar5 - param_1) * 4);
    *(undefined4 *)(param_2 + param_1 * 4) = param_3;
    FUN_140023130((undefined8 *)(param_2 + uVar4 * 8 + 0x30),
                  (undefined8 *)(param_2 + param_1 * 8 + 0x30),(uVar5 - param_1) * 8);
  }
  *(undefined8 *)(param_2 + 0x30 + param_1 * 8) = param_4;
  if (param_1 + 2U < uVar5 + 2) {
    FUN_140023130((undefined8 *)(param_2 + 0xa0 + (param_1 + 2U) * 8),
                  (undefined8 *)(param_2 + 0xa0 + uVar4 * 8),(uVar5 - param_1) * 8);
  }
  *(undefined8 *)(param_2 + 0xa8 + param_1 * 8) = param_5;
  *(ushort *)(param_2 + 0x98) = uVar2 + 1;
  if (uVar4 < uVar5 + 2) {
    uVar4 = param_1 - 1;
    do {
      lVar3 = *(longlong *)(param_2 + 0xb0 + uVar4 * 8);
      *(longlong *)(lVar3 + 0x90) = param_2;
      *(short *)(lVar3 + 0x88) = (short)uVar4 + 2;
      uVar4 = uVar4 + 1;
    } while (uVar5 != uVar4);
  }
  return;
}

