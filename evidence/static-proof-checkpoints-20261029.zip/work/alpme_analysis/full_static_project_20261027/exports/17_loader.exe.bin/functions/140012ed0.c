/* address=140012ed0 rva=0x12ed0 */

void FUN_140012ed0(void)

{
  char cVar1;
  short sVar2;
  int iVar3;
  ulonglong uVar4;
  uint uVar5;
  longlong lVar6;
  
  if (*(char *)(*(longlong *)((longlong)ThreadLocalStoragePointer + (ulonglong)_tls_index * 8) +
               0x80) == '\x01') {
    return;
  }
  uVar4 = 0xc40b0bd5d623baaf;
  uVar5 = 0;
  lVar6 = 0;
  do {
    *(ulonglong *)
     (*(longlong *)((longlong)ThreadLocalStoragePointer + (ulonglong)_tls_index * 8) + 8 + lVar6) =
         *(ulonglong *)((longlong)&DAT_1400735e0 + lVar6) ^ uVar4;
    uVar4 = uVar4 + 0x149fb4e9127431f5;
    uVar5 = uVar5 + 1;
    lVar6 = lVar6 + 8;
  } while (uVar5 < 8);
  iVar3 = 0x643c0c89;
  uVar5 = 0;
  lVar6 = 0;
  do {
    *(int *)(*(longlong *)((longlong)ThreadLocalStoragePointer + (ulonglong)_tls_index * 8) + 0x50 +
            lVar6) = *(int *)((longlong)&DAT_1400737d8 + lVar6) + iVar3;
    uVar5 = uVar5 + 1;
    iVar3 = iVar3 + 0x5e570a11;
    lVar6 = lVar6 + 4;
  } while (uVar5 < 10);
  sVar2 = -0x442c;
  uVar5 = 0;
  lVar6 = 0;
  do {
    *(short *)(*(longlong *)((longlong)ThreadLocalStoragePointer + (ulonglong)_tls_index * 8) + 0x78
              + lVar6) = sVar2 + *(short *)((longlong)&DAT_1400738b0 + lVar6);
    uVar5 = uVar5 + 1;
    lVar6 = lVar6 + 2;
    sVar2 = sVar2 + -0x5d7f;
  } while (uVar5 < 4);
  cVar1 = -0x15;
  lVar6 = 0;
  do {
    *(char *)(*(longlong *)((longlong)ThreadLocalStoragePointer + (ulonglong)_tls_index * 8) + 0x81
             + lVar6) = (&DAT_14007517e)[lVar6] + cVar1;
    cVar1 = cVar1 + -0xd;
    lVar6 = lVar6 + 1;
  } while ((uint)lVar6 < 5);
  *(undefined1 *)
   (*(longlong *)((longlong)ThreadLocalStoragePointer + (ulonglong)_tls_index * 8) + 0x80) = 1;
  return;
}

