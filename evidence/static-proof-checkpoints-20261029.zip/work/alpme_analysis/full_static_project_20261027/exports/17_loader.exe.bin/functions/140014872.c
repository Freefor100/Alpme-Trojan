/* address=140014872 rva=0x14872 */

void FUN_140014872(undefined8 *param_1,byte *param_2,HANDLE param_3)

{
  code *pcVar1;
  bool bVar2;
  char cVar3;
  char cVar4;
  BOOL BVar5;
  DWORD DVar6;
  ulonglong uVar7;
  longlong lVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined8 unaff_RBP;
  ulonglong uVar11;
  undefined8 uVar12;
  ulonglong uVar13;
  LPVOID *ppvVar14;
  LPVOID *ppvVar15;
  LPVOID *ppvVar16;
  uint uVar17;
  LPVOID local_b8;
  ulonglong uStack_b0;
  ulonglong local_a8;
  undefined8 local_a0;
  undefined8 *local_98;
  ulonglong local_90;
  LPVOID *local_88;
  ulonglong local_80;
  _BY_HANDLE_FILE_INFORMATION local_78;
  
  local_78.dwFileAttributes._0_1_ = 0;
  local_78.dwFileAttributes._1_1_ = 0;
  local_78.ftCreationTime.dwLowDateTime = 0;
  local_78.ftCreationTime.dwHighDateTime = 0;
  local_78._16_5_ = 7;
  local_78._24_8_ = local_78._24_8_ & 0xffff000000000000;
  local_78._32_8_ = local_78._32_8_ & 0xff00000000000000;
  local_78.dwFileAttributes._2_1_ = 1;
  uVar7 = FUN_14000a9a9(param_2,(longlong)param_3,(byte *)&local_78);
  if ((uVar7 & 1) != 0) {
    *param_1 = param_3;
    param_1[1] = 0xffffffffffffffff;
    return;
  }
  local_78.nFileSizeHigh = 0;
  local_78.nFileSizeLow = 0;
  local_78.nNumberOfLinks = 0;
  local_78.nFileIndexHigh = 0;
  local_78.ftLastAccessTime.dwHighDateTime = 0;
  local_78.ftLastWriteTime.dwLowDateTime = 0;
  local_78.ftLastWriteTime.dwHighDateTime = 0;
  local_78.dwVolumeSerialNumber = 0;
  local_78.dwFileAttributes._0_1_ = '\0';
  local_78.dwFileAttributes._1_1_ = 0;
  local_78.dwFileAttributes._2_1_ = 0;
  local_78.dwFileAttributes._3_1_ = 0;
  local_78.ftCreationTime.dwLowDateTime = 0;
  local_78.ftCreationTime.dwHighDateTime = 0;
  local_78.ftLastAccessTime.dwLowDateTime = 0;
  local_78.nFileIndexLow = 0;
  BVar5 = GetFileInformationByHandle(param_3,&local_78);
  if (BVar5 == 0) {
LAB_140014a86:
    DVar6 = GetLastError();
    if ((undefined **)PTR_PTR_1400cfa50 != &PTR_LAB_140073648) {
      PTR_PTR_1400cfa50 = (undefined *)&PTR_LAB_140073648;
    }
    uVar7 = (ulonglong)DVar6 << 0x20 | 2;
    bVar2 = false;
    uVar10 = 0;
  }
  else {
    if ((local_78.dwFileAttributes._1_1_ & 4) != 0) {
      local_b8 = (LPVOID)0x0;
      BVar5 = GetFileInformationByHandleEx(param_3,FileAttributeTagInfo,&local_b8,8);
      if (BVar5 == 0) goto LAB_140014a86;
    }
    uVar10 = CONCAT44(local_78.nFileSizeHigh,local_78.nFileSizeLow);
    bVar2 = true;
    uVar7 = uVar10;
  }
  FUN_1400146e3((undefined8 *)&local_78,uVar10,0,1,1);
  uVar10 = local_78._16_8_;
  if ((char)local_78.dwFileAttributes != '\0') {
    *param_1 = 0x2600000003;
    param_1[1] = 0xffffffffffffffff;
    goto LAB_140014b55;
  }
  local_b8 = (LPVOID)CONCAT44(local_78.ftLastAccessTime.dwLowDateTime,
                              local_78.ftCreationTime.dwHighDateTime);
  uStack_b0._0_4_ = local_78.ftLastAccessTime.dwHighDateTime;
  uStack_b0._4_4_ = local_78.ftLastWriteTime.dwLowDateTime;
  local_a8 = 0;
  if ((bool)(bVar2 & uVar7 < 0xfffffffffffffc00)) {
    ppvVar16 = (LPVOID *)(uVar7 + 0x400);
    ppvVar15 = (LPVOID *)(((ulonglong)ppvVar16 & 0xffffffffffffe000) + 0x2000);
    if (ppvVar15 < ppvVar16) {
      ppvVar15 = (LPVOID *)0x2000;
    }
    if (((ulonglong)ppvVar16 & 0x1fff) == 0) {
      ppvVar15 = ppvVar16;
    }
LAB_140014d28:
    uVar12 = 0;
    if (uVar7 != 0) {
      local_a0 = 0;
      goto LAB_140014bce;
    }
  }
  else {
    ppvVar15 = (LPVOID *)0x2000;
    uVar12 = CONCAT71((int7)((ulonglong)unaff_RBP >> 8),1);
    if (bVar2) goto LAB_140014d28;
  }
  ppvVar16 = &local_b8;
  if ((ulonglong)local_78._16_8_ < 0x20) {
    uVar7 = FUN_1400081c4(param_3,(longlong *)ppvVar16);
    if ((uVar7 & 1) == 0) {
      local_a0 = uVar12;
      if (ppvVar16 != (LPVOID *)0x0) {
        goto LAB_140014bce;
      }
LAB_140014ba3:
      param_1[2] = local_a8;
      *param_1 = local_b8;
      param_1[1] = uStack_b0;
    }
    else {
LAB_140014b2d:
      *param_1 = ppvVar16;
      param_1[1] = 0xffffffffffffffff;
      FUN_14000250d(local_b8,uStack_b0,1,1);
    }
LAB_140014b55:
    CloseHandle(param_3);
    return;
  }
  local_a0 = uVar12;
LAB_140014bce:
  uVar7 = 0;
  uVar11 = uStack_b0;
LAB_140014bd0:
  uVar9 = uVar11 - local_a8;
  while (uVar13 = uVar7, uVar9 < 0x20) {
    if (uVar11 != uVar10) {
      if (uVar11 - local_a8 < 0x20) {
        lVar8 = FUN_14000965c(&local_b8,local_a8,0x20,(LPVOID)0x1,1);
        if (lVar8 != -1) {
          ppvVar16 = (LPVOID *)0x2600000003;
          goto LAB_140014b2d;
        }
        uVar11 = uStack_b0;
        uVar13 = local_a8;
      }
      else {
        uVar13 = local_a8;
      }
      break;
    }
    ppvVar16 = &local_b8;
    uVar7 = FUN_1400081c4(param_3,(longlong *)ppvVar16);
    if ((uVar7 & 1) != 0) goto LAB_140014b2d;
    if (ppvVar16 == (LPVOID *)0x0) goto LAB_140014ba3;
    uVar7 = local_a8;
    uVar11 = uStack_b0;
    uVar9 = uStack_b0 - local_a8;
  }
  uVar9 = local_a8;
  local_98 = param_1;
  local_88 = ppvVar15;
  local_80 = uVar10;
  if (local_a8 + 0x20 < uVar13) {
    ppvVar14 = (LPVOID *)(uVar13 - local_a8);
    if ((LPVOID *)(uVar11 - local_a8) < ppvVar14) {
                    /* WARNING: Does not return */
      pcVar1 = (code *)invalidInstructionException();
      (*pcVar1)();
    }
  }
  else {
    ppvVar14 = (LPVOID *)(uVar11 - local_a8);
    if (ppvVar15 < (LPVOID *)(uVar11 - local_a8)) {
      ppvVar14 = ppvVar15;
    }
  }
  ppvVar15 = (LPVOID *)((longlong)local_b8 + local_a8);
  local_90 = (longlong)ppvVar14 + local_a8;
LAB_140014c72:
  ppvVar16 = ppvVar15;
  uVar7 = FUN_140012db6(param_3,ppvVar15,(ulonglong)ppvVar14);
  if ((uVar7 & 1) == 0) goto LAB_140014a06;
  uVar17 = (uint)ppvVar16 & 3;
  cVar4 = (char)((ulonglong)ppvVar16 >> 0x20);
  switch(uVar17) {
  case 0:
    cVar3 = *(char *)(ppvVar16 + 2);
    break;
  case 1:
    cVar3 = *(char *)((longlong)ppvVar16 + -1);
    break;
  case 2:
    cVar3 = (**(code **)PTR_PTR_1400cfa50)((ulonglong)ppvVar16 >> 0x20);
    break;
  case 3:
    cVar3 = cVar4;
  }
  param_1 = local_98;
  if (cVar3 == '\v') {
    if ((1 < uVar17 - 2) && (((ulonglong)ppvVar16 & 3) != 0)) {
      (**(code **)((longlong)ppvVar16 + 7))((longlong)ppvVar16 + -1);
    }
    local_a8 = uVar9;
    goto LAB_140014ba3;
  }
  if (ppvVar16 == (LPVOID *)0x0) {
    local_a8 = uVar9;
    goto LAB_140014ba3;
  }
  switch(uVar17) {
  case 0:
    if (*(char *)(ppvVar16 + 2) != '#') break;
    goto LAB_140014c72;
  case 1:
    if (*(char *)((longlong)ppvVar16 + -1) == '#') {
      (**(code **)((longlong)ppvVar16 + 7))((longlong)ppvVar16 + -1);
      goto LAB_140014c72;
    }
    break;
  case 2:
    cVar4 = (**(code **)(PTR_PTR_1400cfa50 + 8))((ulonglong)ppvVar16 >> 0x20);
    if (cVar4 != '\0') goto LAB_140014c72;
    break;
  case 3:
    goto switchD_140014994_caseD_3;
  }
  goto LAB_140014b23;
LAB_140014a06:
  uVar7 = uVar13;
  if (local_90 <= uVar13) {
    uVar7 = local_90;
  }
  local_a8 = uVar9 + (longlong)ppvVar16;
  param_1 = local_98;
  if (ppvVar16 == (LPVOID *)0x0) goto LAB_140014ba3;
  uVar10 = local_80;
  ppvVar15 = local_88;
  if (((byte)local_a0 & local_90 <= uVar13) == 0) {
    if ((byte)local_a0 != 0) {
      ppvVar15 = (LPVOID *)0xffffffffffffffff;
    }
  }
  else if (local_88 == ppvVar16) {
    ppvVar15 = (LPVOID *)((longlong)local_88 * 2);
    if ((longlong)local_88 < 0) {
      ppvVar15 = (LPVOID *)0xffffffffffffffff;
    }
  }
  goto LAB_140014bd0;
switchD_140014994_caseD_3:
  if ((LPVOID *)0x2bffffffff < ppvVar16) {
    cVar4 = -1;
  }
  if (cVar4 == '#') goto LAB_140014c72;
LAB_140014b23:
  param_1 = local_98;
  local_a8 = uVar9;
  goto LAB_140014b2d;
}

