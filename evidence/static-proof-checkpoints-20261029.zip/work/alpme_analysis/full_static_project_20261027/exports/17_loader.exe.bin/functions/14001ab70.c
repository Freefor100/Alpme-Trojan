/* address=14001ab70 rva=0x1ab70 */

void FUN_14001ab70(void)

{
  code *pcVar1;
  
  pcVar1 = (code *)swi(0x29);
  (*pcVar1)(2);
  return;
}

