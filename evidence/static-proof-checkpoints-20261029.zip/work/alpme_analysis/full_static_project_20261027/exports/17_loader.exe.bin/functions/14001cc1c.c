/* address=14001cc1c rva=0x1cc1c */

void FUN_14001cc1c(uint param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00014001cc3c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  LeaveCriticalSection
            ((&DAT_1400d13c0)[(longlong)(int)param_1 >> 6] + (ulonglong)(param_1 & 0x3f) * 0x48);
  return;
}

