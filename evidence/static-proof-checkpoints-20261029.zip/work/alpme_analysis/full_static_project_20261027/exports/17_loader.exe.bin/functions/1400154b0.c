/* address=1400154b0 rva=0x154b0 */

bool FUN_1400154b0(void)

{
  return DAT_1400d02b4 == 0;
}

