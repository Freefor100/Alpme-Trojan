/* address=140015ebc rva=0x15ebc */

void FUN_140015ebc(void)

{
  FUN_140019208(&PTR_LAB_1400765a0,(undefined8 *)&FuncInfo_1400766a0);
  return;
}

