/* address=140017f2c rva=0x17f2c */

void FUN_140017f2c(longlong param_1,longlong param_2)

{
  undefined **ppuVar1;
  
  if (*(longlong *)(param_1 + 0x90) != 0) {
    FUN_14001af40(*(longlong *)(param_1 + 0x90));
    ppuVar1 = *(undefined ***)(param_1 + 0x90);
    if (((ppuVar1 != DAT_1400d1818) && (ppuVar1 != &PTR_DAT_1400d0880)) &&
       (*(int *)(ppuVar1 + 2) == 0)) {
      FUN_14001afe8(ppuVar1);
    }
  }
  *(longlong *)(param_1 + 0x90) = param_2;
  if (param_2 != 0) {
    FUN_14001aeb4(param_2);
  }
  return;
}

