/* address=140015da4 rva=0x15da4 */

undefined8 FUN_140015da4(void)

{
  undefined8 uVar1;
  
  FUN_14001672c((longlong *)&DAT_1400d0f88);
  uVar1 = FUN_14001672c((longlong *)&DAT_1400d0fa0);
  return CONCAT71((int7)((ulonglong)uVar1 >> 8),1);
}

