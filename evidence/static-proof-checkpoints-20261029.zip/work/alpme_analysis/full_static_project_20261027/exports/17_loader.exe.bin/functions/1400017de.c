/* address=1400017de rva=0x17de */

void FUN_1400017de(longlong param_1,longlong param_2)

{
  byte bVar1;
  uint uVar2;
  longlong lVar3;
  longlong lVar4;
  uint uVar5;
  byte bVar6;
  
  lVar3 = param_1 + param_2;
  if (param_2 != 0) {
    do {
      uVar5 = (uint)*(char *)(lVar3 + -1);
      if ((int)uVar5 < 0) {
        bVar6 = *(byte *)(lVar3 + -2);
        if ((char)bVar6 < -0x40) {
          bVar1 = *(byte *)(lVar3 + -3);
          if ((char)bVar1 < -0x40) {
            lVar4 = lVar3 + -4;
            uVar2 = bVar1 & 0x3f | (*(byte *)(lVar3 + -4) & 7) << 6;
          }
          else {
            uVar2 = bVar1 & 0xf;
            lVar4 = lVar3 + -3;
          }
          uVar2 = uVar2 << 6 | bVar6 & 0x3f;
        }
        else {
          uVar2 = bVar6 & 0x1f;
          lVar4 = lVar3 + -2;
        }
        uVar5 = uVar2 << 6 | uVar5 & 0x3f;
      }
      else {
        lVar4 = lVar3 + -1;
      }
      if ((4 < uVar5 - 9) && (uVar5 != 0x20)) {
        if (uVar5 < 0x85) {
          return;
        }
        uVar2 = uVar5 >> 8;
        if (uVar2 < 0x20) {
          if (uVar2 == 0) {
            bVar6 = (&DAT_140074baa)[uVar5 & 0xff];
          }
          else {
            if (uVar2 != 0x16) {
              return;
            }
            bVar6 = uVar5 == 0x1680;
          }
        }
        else if (uVar2 == 0x20) {
          bVar6 = (byte)(&DAT_140074baa)[uVar5 & 0xff] >> 1;
        }
        else {
          if (uVar2 != 0x30) {
            return;
          }
          bVar6 = uVar5 == 0x3000;
        }
        if ((bVar6 & 1) == 0) {
          return;
        }
      }
      lVar3 = lVar4;
    } while (lVar4 != param_1);
  }
  return;
}

