/* address=140017d00 rva=0x17d00 */

bool FUN_140017d00(void)

{
  DAT_1400d13b0 = GetProcessHeap();
  return DAT_1400d13b0 != (HANDLE)0x0;
}

