/* address=1400240c0 rva=0x240c0 */

void FUN_1400240c0(undefined8 *param_1)

{
  FUN_140016f60(*(int *)*param_1,param_1);
  return;
}

