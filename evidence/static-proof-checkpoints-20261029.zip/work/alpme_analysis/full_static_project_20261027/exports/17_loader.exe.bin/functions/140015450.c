/* address=140015450 rva=0x15450 */

undefined1 FUN_140015450(void)

{
  return 1;
}

