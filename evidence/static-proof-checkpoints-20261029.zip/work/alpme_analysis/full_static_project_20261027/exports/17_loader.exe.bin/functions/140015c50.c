/* address=140015c50 rva=0x15c50 */

longlong FUN_140015c50(void)

{
  PVOID pvVar1;
  
  pvVar1 = FUN_1400173f0();
  return (longlong)pvVar1 + 0x28;
}

