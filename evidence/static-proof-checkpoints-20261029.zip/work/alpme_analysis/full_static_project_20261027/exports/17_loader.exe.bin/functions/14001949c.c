/* address=14001949c rva=0x1949c */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_14001949c(undefined8 param_1)

{
  _DAT_1400d17e8 = param_1;
  return;
}

