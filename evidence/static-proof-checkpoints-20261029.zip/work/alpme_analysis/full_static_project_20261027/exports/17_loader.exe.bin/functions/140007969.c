/* address=140007969 rva=0x7969 */

ulonglong FUN_140007969(uint param_1)

{
  undefined8 in_RAX;
  undefined7 uVar2;
  ulonglong uVar1;
  
  uVar2 = (undefined7)((ulonglong)in_RAX >> 8);
  uVar1 = CONCAT71(uVar2,1);
  if (0x377 < param_1) {
    if (param_1 < 0x3fffe) {
      uVar1 = FUN_140014627(param_1);
      uVar1 = uVar1 ^ 1;
    }
    else if ((0xfffd < param_1 - 0xf0000 && param_1 != 0xe0001) &&
             (0x5f < param_1 - 0xe0020 && 0xef < param_1 - 0xe0100)) {
      uVar1 = CONCAT71(uVar2,param_1 - 0x100000 < 0xfffe);
    }
  }
  return uVar1;
}

