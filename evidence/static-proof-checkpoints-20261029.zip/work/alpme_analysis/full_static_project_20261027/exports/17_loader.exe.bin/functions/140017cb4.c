/* address=140017cb4 rva=0x17cb4 */

void FUN_140017cb4(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x000140017cc6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  EnterCriticalSection(&DAT_1400d1150 + (longlong)param_1 * 0x28);
  return;
}

