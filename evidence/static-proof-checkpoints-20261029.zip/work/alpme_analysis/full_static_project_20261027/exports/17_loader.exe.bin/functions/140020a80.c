/* address=140020a80 rva=0x20a80 */

void FUN_140020a80(undefined1 *param_1,ulonglong param_2,ulonglong param_3,undefined *param_4)

{
  undefined1 uVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined1 *puVar4;
  longlong lVar5;
  undefined1 *puVar6;
  undefined1 *puVar7;
  undefined1 *puVar8;
  ulonglong uVar9;
  undefined1 *puVar10;
  undefined1 auStack_468 [32];
  longlong lStack_448;
  undefined8 local_438 [62];
  undefined8 local_248 [62];
  ulonglong local_58;
  
  local_58 = DAT_1400d02c0 ^ (ulonglong)auStack_468;
  if ((((param_1 == (undefined1 *)0x0) && (param_2 != 0)) || (param_3 == 0)) ||
     (param_4 == (undefined *)0x0)) {
    puVar3 = FUN_140019fec();
    *(undefined4 *)puVar3 = 0x16;
    FUN_1400192c4();
    FUN_140020df8();
    return;
  }
  _guard_check_icall();
  FUN_1400237e0((undefined1 (*) [32])local_438,0,0x1f0);
  FUN_1400237e0((undefined1 (*) [32])local_248,0,0x1f0);
  if (param_2 < 2) {
code_r0x000140020df8:
    FUN_14001b4d0(local_58 ^ (ulonglong)auStack_468);
    return;
  }
  lStack_448 = 0;
  puVar10 = param_1 + (param_2 - 1) * param_3;
LAB_140020b40:
  uVar9 = (ulonglong)((longlong)puVar10 - (longlong)param_1) / param_3 + 1;
  if (8 < uVar9) {
    lVar5 = (uVar9 >> 1) * param_3;
    puVar4 = param_1 + lVar5;
    iVar2 = (*(code *)param_4)(param_1,puVar4);
    if (0 < iVar2) {
      puVar6 = puVar4;
      uVar9 = param_3;
      if (param_1 != puVar4) {
        do {
          uVar1 = puVar6[-lVar5];
          puVar6[-lVar5] = *puVar6;
          *puVar6 = uVar1;
          uVar9 = uVar9 - 1;
          puVar6 = puVar6 + 1;
        } while (uVar9 != 0);
      }
    }
    iVar2 = (*(code *)param_4)(param_1,puVar10);
    if ((0 < iVar2) && (param_1 != puVar10)) {
      puVar6 = puVar10;
      uVar9 = param_3;
      do {
        uVar1 = puVar6[(longlong)param_1 - (longlong)puVar10];
        puVar6[(longlong)param_1 - (longlong)puVar10] = *puVar6;
        *puVar6 = uVar1;
        puVar6 = puVar6 + 1;
        uVar9 = uVar9 - 1;
      } while (uVar9 != 0);
    }
    iVar2 = (*(code *)param_4)(puVar4);
    if ((0 < iVar2) && (puVar4 != puVar10)) {
      puVar6 = puVar10;
      uVar9 = param_3;
      do {
        uVar1 = puVar6[(longlong)puVar4 - (longlong)puVar10];
        puVar6[(longlong)puVar4 - (longlong)puVar10] = *puVar6;
        *puVar6 = uVar1;
        puVar6 = puVar6 + 1;
        uVar9 = uVar9 - 1;
      } while (uVar9 != 0);
    }
    puVar6 = param_1;
    puVar8 = puVar10;
    do {
      if (puVar6 < puVar4) {
        do {
          puVar6 = puVar6 + param_3;
          if (puVar4 <= puVar6) goto LAB_140020cd0;
          iVar2 = (*(code *)param_4)(puVar6);
        } while (iVar2 < 1);
      }
      else {
LAB_140020cd0:
        do {
          puVar6 = puVar6 + param_3;
          if (puVar10 < puVar6) break;
          iVar2 = (*(code *)param_4)(puVar6);
        } while (iVar2 < 1);
      }
      do {
        puVar7 = puVar8;
        puVar8 = puVar7 + -param_3;
        if (puVar8 <= puVar4) break;
        iVar2 = (*(code *)param_4)(puVar8);
      } while (0 < iVar2);
      if (puVar8 < puVar6) goto LAB_140020d3a;
      if (puVar8 != puVar6) {
        puVar7 = puVar8;
        uVar9 = param_3;
        do {
          uVar1 = puVar7[(longlong)puVar6 - (longlong)puVar8];
          puVar7[(longlong)puVar6 - (longlong)puVar8] = *puVar7;
          *puVar7 = uVar1;
          puVar7 = puVar7 + 1;
          uVar9 = uVar9 - 1;
        } while (uVar9 != 0);
      }
      puVar7 = puVar6;
      if (puVar4 != puVar8) {
        puVar7 = puVar4;
      }
      puVar4 = puVar7;
    } while( true );
  }
  puVar6 = param_1;
  puVar4 = param_1;
  if (param_1 < puVar10) {
    do {
      while( true ) {
        puVar8 = puVar6;
        puVar4 = puVar4 + param_3;
        if (puVar10 < puVar4) break;
        iVar2 = (*(code *)param_4)(puVar4,puVar8);
        puVar6 = puVar4;
        if (iVar2 < 1) {
          puVar6 = puVar8;
        }
      }
      if (puVar8 != puVar10) {
        puVar4 = puVar10;
        uVar9 = param_3;
        do {
          uVar1 = puVar4[(longlong)puVar8 - (longlong)puVar10];
          puVar4[(longlong)puVar8 - (longlong)puVar10] = *puVar4;
          *puVar4 = uVar1;
          puVar4 = puVar4 + 1;
          uVar9 = uVar9 - 1;
        } while (uVar9 != 0);
      }
      puVar10 = puVar10 + -param_3;
      puVar6 = param_1;
      puVar4 = param_1;
    } while (param_1 < puVar10);
  }
  goto LAB_140020bc3;
LAB_140020d3a:
  if (puVar4 < puVar7) {
    do {
      puVar7 = puVar7 + -param_3;
      if (puVar7 <= puVar4) goto LAB_140020d57;
      iVar2 = (*(code *)param_4)(puVar7);
    } while (iVar2 == 0);
  }
  else {
LAB_140020d57:
    do {
      puVar7 = puVar7 + -param_3;
      if (puVar7 <= param_1) break;
      iVar2 = (*(code *)param_4)(puVar7);
    } while (iVar2 == 0);
  }
  if ((longlong)puVar7 - (longlong)param_1 < (longlong)puVar10 - (longlong)puVar6) {
    if (puVar6 < puVar10) {
      local_438[lStack_448] = puVar6;
      local_248[lStack_448] = puVar10;
      lStack_448 = lStack_448 + 1;
    }
    if (param_1 < puVar7) {
      puVar10 = puVar7;
      goto LAB_140020b40;
    }
  }
  else {
    if (param_1 < puVar7) {
      local_438[lStack_448] = param_1;
      local_248[lStack_448] = puVar7;
      lStack_448 = lStack_448 + 1;
    }
    if (puVar6 < puVar10) {
      param_1 = puVar6;
      goto LAB_140020b40;
    }
  }
LAB_140020bc3:
  lStack_448 = lStack_448 + -1;
  if (-1 < lStack_448) {
    param_1 = (undefined1 *)local_438[lStack_448];
    puVar10 = (undefined1 *)local_248[lStack_448];
    goto LAB_140020b40;
  }
  goto code_r0x000140020df8;
}

