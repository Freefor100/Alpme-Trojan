/* address=14001617c rva=0x1617c */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */

void FUN_14001617c(undefined8 *param_1)

{
  byte bVar1;
  undefined *puVar2;
  
  if (DAT_1400d0e74 != '\0') {
    return;
  }
  LOCK();
  DAT_1400d0e70 = 1;
  UNLOCK();
  if (*(int *)*param_1 == 0) {
    if (DAT_1400d0e68 != DAT_1400d02c0) {
      bVar1 = (byte)DAT_1400d02c0 & 0x3f;
      (*(code *)((DAT_1400d02c0 ^ DAT_1400d0e68) >> bVar1 |
                (DAT_1400d02c0 ^ DAT_1400d0e68) << 0x40 - bVar1))(0,0,0);
    }
    puVar2 = &DAT_1400d0f88;
  }
  else {
    if (*(int *)*param_1 != 1) goto LAB_1400161eb;
    puVar2 = &DAT_1400d0fa0;
  }
  FUN_14001679c(puVar2);
LAB_1400161eb:
  if (*(int *)*param_1 == 0) {
    FUN_140016eec((undefined8 *)&DAT_14007e110,(undefined8 *)&DAT_14007e130);
  }
  FUN_140016eec((undefined8 *)&DAT_14007e138,(undefined8 *)&DAT_14007e140);
  if (*(int *)param_1[1] == 0) {
    DAT_1400d0e74 = '\x01';
    *(undefined1 *)param_1[2] = 1;
  }
  return;
}

