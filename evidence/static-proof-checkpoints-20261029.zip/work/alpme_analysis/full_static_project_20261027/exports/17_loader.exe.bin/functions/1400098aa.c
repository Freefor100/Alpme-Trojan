/* address=1400098aa rva=0x98aa */

void FUN_1400098aa(undefined8 *param_1)

{
  code *pcVar1;
  longlong lVar2;
  
  lVar2 = FUN_14000965c(param_1,param_1[1],1,(LPVOID)0x1,1);
  if (lVar2 != -1) {
                    /* WARNING: Does not return */
    pcVar1 = (code *)invalidInstructionException();
    (*pcVar1)();
  }
  return;
}

