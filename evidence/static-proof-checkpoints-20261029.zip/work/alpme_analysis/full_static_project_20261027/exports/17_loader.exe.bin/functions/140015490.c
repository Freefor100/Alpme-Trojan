/* address=140015490 rva=0x15490 */

undefined * FUN_140015490(void)

{
  return &DAT_1400d0df0;
}

