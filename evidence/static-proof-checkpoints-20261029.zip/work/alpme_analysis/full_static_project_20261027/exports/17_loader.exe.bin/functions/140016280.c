/* address=140016280 rva=0x16280 */

int FUN_140016280(int param_1)

{
  uint uVar1;
  longlong lVar2;
  undefined8 *puVar3;
  uint uVar4;
  
  lVar2 = FUN_140017dc0();
  uVar1 = *(uint *)(lVar2 + 0x3a8);
  if (param_1 == -1) {
    DAT_1400d0ba0 = 0xffffffff;
  }
  else if (param_1 != 0) {
    if (param_1 == 1) {
      uVar4 = uVar1 | 2;
    }
    else {
      if (param_1 != 2) {
        puVar3 = FUN_140019fec();
        *(undefined4 *)puVar3 = 0x16;
        FUN_1400192c4();
        return -1;
      }
      uVar4 = uVar1 & 0xfffffffd;
    }
    *(uint *)(lVar2 + 0x3a8) = uVar4;
  }
  return 2 - (uint)((uVar1 & 2) != 0);
}

