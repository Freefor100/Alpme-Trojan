/* address=1400157c3 rva=0x157c3 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_1400157c3(void)

{
  ulonglong uVar1;
  byte bVar2;
  ulonglong in_RAX;
  ulonglong uVar3;
  uint unaff_EBP;
  ulonglong unaff_RSI;
  uint unaff_EDI;
  uint in_R9D;
  uint in_R10D;
  byte unaff_R14B;
  ulonglong in_XCR0;
  
  DAT_1400d0320 = in_RAX & 0xffffffffffffffef;
  DAT_1400d0308 = 2;
  DAT_1400d030c = 6;
  if ((unaff_EDI >> 0x1b & 1) == 0) {
    DAT_1400d0308 = 2;
    DAT_1400d030c = 6;
    return 0;
  }
  uVar1 = xinuse(0);
  uVar3 = in_XCR0 & uVar1 & 0xffffffff;
  uVar1 = DAT_1400d0320;
  if (((unaff_EDI >> 0x1c & 1) != 0) && (bVar2 = (byte)uVar3, (bVar2 & 6) == 6)) {
    DAT_1400d0308 = 3;
    DAT_1400d030c = 0xe;
    if ((in_R9D & 0x20) != 0) {
      DAT_1400d0308 = 5;
      DAT_1400d030c = 0x2e;
      DAT_1400d0320 = in_RAX & 0xffffffffffffffed;
      if (((in_R9D & 0xd0030000) == 0xd0030000) && ((bVar2 & 0xe0) == 0xe0)) {
        DAT_1400d030c = 0x6e;
        DAT_1400d0320 = in_RAX & 0xffffffffffffffc9;
        DAT_1400d0308 = 6;
      }
    }
    if ((unaff_EBP >> 0x17 & 1) != 0) {
      DAT_1400d0320 = DAT_1400d0320 & 0xfffffffffeffffff;
    }
    uVar1 = DAT_1400d0320;
    if (((in_R10D >> 0x13 & 1) != 0) && ((bVar2 & 0xe0) == 0xe0)) {
      _DAT_1400d0e18 = (uint)unaff_R14B;
      uVar1 = DAT_1400d0320 & 0xfffffffffeffffd0;
      if (1 < _DAT_1400d0e18) {
        uVar1 = DAT_1400d0320 & 0xfffffffffeffff90;
      }
    }
  }
  DAT_1400d0320 = uVar1;
  if ((((in_R10D >> 0x15 & 1) != 0) && ((unaff_RSI & 1) != 0)) && ((uVar3 >> 0x13 & 1) != 0)) {
    DAT_1400d0320 = DAT_1400d0320 & 0xffffffffffffff7f;
  }
  return 0;
}

