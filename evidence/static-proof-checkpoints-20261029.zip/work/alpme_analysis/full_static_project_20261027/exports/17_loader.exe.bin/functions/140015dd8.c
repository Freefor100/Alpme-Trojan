/* address=140015dd8 rva=0x15dd8 */

undefined1 FUN_140015dd8(void)

{
  undefined8 uVar1;
  
  uVar1 = DAT_1400d02c0;
  FUN_14001949c(DAT_1400d02c0);
  FUN_140019760(uVar1);
  FUN_14001981c(uVar1);
  FUN_140015f80(uVar1);
  FUN_140015ffc(uVar1);
  return 1;
}

