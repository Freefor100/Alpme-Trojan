/* address=1400243e0 rva=0x243e0 */

void FUN_1400243e0(undefined8 param_1,longlong param_2)

{
  FUN_14001cc1c(*(uint *)(param_2 + 0x60));
  return;
}

