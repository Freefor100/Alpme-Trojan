/* address=1400096e5 rva=0x96e5 */

undefined8 FUN_1400096e5(undefined8 param_1,longlong param_2,ulonglong param_3,ushort *param_4)

{
  byte bVar1;
  ushort uVar2;
  code *pcVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  uint uVar6;
  ushort *puVar7;
  
  if ((param_3 & 1) != 0) {
                    /* WARNING: Could not recover jumptable at 0x000140009727. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar4 = (**(code **)(param_2 + 0x18))(param_1,param_4,param_3 >> 1);
    return uVar4;
  }
  bVar1 = (byte)*param_4;
  if (bVar1 != 0) {
    pcVar3 = *(code **)(param_2 + 0x18);
    uVar5 = 0;
    do {
      puVar7 = (ushort *)((longlong)param_4 + 1);
      uVar6 = (uint)bVar1;
      if ((char)bVar1 < '\0') {
        if (bVar1 == 0x80) {
          uVar2 = *(ushort *)((longlong)param_4 + 1);
          uVar4 = (*pcVar3)(param_1,(byte *)((longlong)param_4 + 3),(ulonglong)uVar2);
          if ((char)uVar4 != '\0') goto LAB_140009850;
          puVar7 = (ushort *)((longlong)param_4 + (ulonglong)uVar2 + 3);
        }
        else {
          if (uVar6 != 0xc0) {
            if ((bVar1 & 1) != 0) {
              puVar7 = (ushort *)((longlong)param_4 + 5);
            }
            if ((bVar1 & 2) != 0) {
              puVar7 = puVar7 + 1;
            }
            if ((bVar1 & 4) != 0) {
              puVar7 = puVar7 + 1;
            }
            if ((bVar1 & 8) != 0) {
              uVar5 = (ulonglong)*puVar7;
              puVar7 = puVar7 + 1;
            }
          }
          uVar4 = (**(code **)(param_3 + uVar5 * 0x10))();
          if ((char)uVar4 != '\0') {
LAB_140009850:
            return CONCAT71((int7)((ulonglong)uVar4 >> 8),1);
          }
          uVar5 = uVar5 + 1;
        }
      }
      else {
        uVar4 = (*pcVar3)(param_1,puVar7,(ulonglong)uVar6);
        if ((char)uVar4 != '\0') goto LAB_140009850;
        puVar7 = (ushort *)((longlong)puVar7 + (ulonglong)uVar6);
      }
      bVar1 = (byte)*puVar7;
      param_4 = puVar7;
    } while (bVar1 != 0);
  }
  return 0;
}

