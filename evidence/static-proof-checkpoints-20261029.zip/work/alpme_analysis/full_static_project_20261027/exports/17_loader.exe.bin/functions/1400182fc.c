/* address=1400182fc rva=0x182fc */

void FUN_1400182fc(undefined8 param_1,int *param_2,undefined8 *param_3,int *param_4)

{
  FUN_140017cb4(*param_2);
  FUN_140017f2c(*(longlong *)*param_3,0);
  FUN_140017cd0(*param_4);
  return;
}

