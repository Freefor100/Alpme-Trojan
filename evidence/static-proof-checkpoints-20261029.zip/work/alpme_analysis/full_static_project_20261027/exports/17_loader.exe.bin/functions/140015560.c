/* address=140015560 rva=0x15560 */

void FUN_140015560(void)

{
                    /* WARNING: Could not recover jumptable at 0x000140015567. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  SetUnhandledExceptionFilter(FUN_140015580);
  return;
}

