/* address=140017698 rva=0x17698 */

bool FUN_140017698(void)

{
  BOOL BVar1;
  DWORD local_res8 [8];
  
  local_res8[0] = 0;
  BVar1 = VirtualProtect(&DAT_14007e150,0x100,2,local_res8);
  return BVar1 != 0;
}

