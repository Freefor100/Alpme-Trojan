/* address=140019bec rva=0x19bec */

undefined8 FUN_140019bec(int *param_1,longlong *param_2)

{
  byte *pbVar1;
  uint uVar2;
  uint uVar3;
  
  if ((((byte)param_1[5] & 3) == 2) && ((param_1[5] & 0xc0U) != 0)) {
    uVar3 = *param_1 - param_1[2];
    param_1[4] = 0;
    pbVar1 = *(byte **)(param_1 + 2);
    *(byte **)param_1 = pbVar1;
    if (0 < (int)uVar3) {
      uVar2 = FUN_14001e4b0((longlong)param_1);
      uVar2 = FUN_14001e808(uVar2,pbVar1,uVar3,param_2);
      if (uVar3 != uVar2) {
        LOCK();
        param_1[5] = param_1[5] | 0x10;
        UNLOCK();
        return 0xffffffff;
      }
      if (((uint)param_1[5] >> 2 & 1) != 0) {
        LOCK();
        param_1[5] = param_1[5] & 0xfffffffd;
        UNLOCK();
      }
    }
  }
  return 0;
}

