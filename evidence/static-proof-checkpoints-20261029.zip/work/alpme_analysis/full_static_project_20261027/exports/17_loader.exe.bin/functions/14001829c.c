/* address=14001829c rva=0x1829c */

void FUN_14001829c(undefined8 param_1,int *param_2,undefined8 *param_3,int *param_4)

{
  int iVar1;
  int *piVar2;
  
  FUN_140017cb4(*param_2);
  piVar2 = *(int **)(*(longlong *)*param_3 + 0x88);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (piVar2 != (int *)&DAT_1400d0340)) {
      FUN_1400191b0(piVar2);
    }
  }
  FUN_140017cd0(*param_4);
  return;
}

