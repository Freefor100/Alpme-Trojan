/* address=14001ac94 rva=0x1ac94 */

void FUN_14001ac94(undefined4 *param_1,DWORD param_2,LPCSTR param_3,int param_4,LPWORD param_5,
                  UINT param_6,int param_7)

{
  int iVar1;
  longlong lVar2;
  undefined4 *puVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  undefined1 (*lpSrcStr) [32];
  undefined1 *puVar6;
  undefined1 *puVar7;
  undefined1 *puVar8;
  undefined1 auStackY_88 [32];
  undefined4 local_58 [2];
  longlong local_50;
  longlong local_48;
  char local_38;
  ulonglong local_30;
  
  local_30 = DAT_1400d02c0 ^ (ulonglong)local_58;
  FUN_14001863c(&local_50,param_1);
  if (param_6 == 0) {
    param_6 = *(UINT *)(local_48 + 0xc);
  }
  iVar1 = FUN_14001ae24(param_6,(-(uint)(param_7 != 0) & 8) + 1,param_3,param_4,(LPWSTR)0x0,0);
  puVar7 = auStackY_88;
  puVar8 = auStackY_88;
  if (iVar1 == 0) goto LAB_14001adea;
  uVar5 = (longlong)iVar1 * 2;
  uVar4 = -(ulonglong)(uVar5 < uVar5 + 0x10) & uVar5 + 0x10;
  if (uVar4 == 0) {
    lpSrcStr = (undefined1 (*) [32])0x0;
LAB_14001add2:
    puVar8 = puVar7;
    if (lpSrcStr == (undefined1 (*) [32])0x0) goto LAB_14001adea;
  }
  else {
    if (uVar4 < 0x401) {
      lVar2 = FUN_140014e00();
      lVar2 = -lVar2;
      puVar7 = auStackY_88 + lVar2;
      puVar6 = auStackY_88 + lVar2;
      puVar3 = (undefined4 *)((longlong)local_58 + lVar2);
      lpSrcStr = (undefined1 (*) [32])0x0;
      if (puVar3 == (undefined4 *)0x0) goto LAB_14001add2;
      *puVar3 = 0xcccc;
LAB_14001ad80:
      lpSrcStr = (undefined1 (*) [32])(puVar3 + 4);
      puVar7 = puVar6;
    }
    else {
      puVar3 = FUN_14001ac00(uVar4);
      puVar7 = auStackY_88;
      puVar6 = auStackY_88;
      lpSrcStr = (undefined1 (*) [32])0x0;
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = 0xdddd;
        goto LAB_14001ad80;
      }
    }
    if (lpSrcStr == (undefined1 (*) [32])0x0) goto LAB_14001add2;
    *(undefined8 *)(puVar7 + -8) = 0x14001ad96;
    FUN_1400237e0(lpSrcStr,0,uVar5);
    *(int *)(puVar7 + 0x28) = iVar1;
    *(undefined1 (**) [32])(puVar7 + 0x20) = lpSrcStr;
    *(undefined8 *)(puVar7 + -8) = 0x14001adb2;
    iVar1 = FUN_14001ae24(param_6,1,param_3,param_4,*(LPWSTR *)(puVar7 + 0x20),
                          *(int *)(puVar7 + 0x28));
    if (iVar1 == 0) goto LAB_14001add2;
    *(undefined8 *)(puVar7 + -8) = 0x14001adcc;
    GetStringTypeW(param_2,(LPCWSTR)lpSrcStr,iVar1,param_5);
  }
  puVar8 = puVar7;
  if (*(int *)(lpSrcStr[-1] + 0x10) == 0xdddd) {
    *(undefined8 *)(puVar7 + -8) = 0x14001adea;
    FUN_1400191b0(lpSrcStr[-1] + 0x10);
  }
LAB_14001adea:
  if (local_38 != '\0') {
    *(uint *)(local_50 + 0x3a8) = *(uint *)(local_50 + 0x3a8) & 0xfffffffd;
  }
  uVar5 = local_30 ^ (ulonglong)local_58;
  *(undefined8 *)(puVar8 + -8) = 0x14001ae09;
  FUN_14001b4d0(uVar5);
  return;
}

