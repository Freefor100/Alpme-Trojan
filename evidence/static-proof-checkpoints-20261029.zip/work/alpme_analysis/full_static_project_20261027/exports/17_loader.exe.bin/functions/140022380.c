/* address=140022380 rva=0x22380 */

ulonglong FUN_140022380(int *param_1,longlong *param_2)

{
  ulonglong uVar1;
  
  if (param_1 == (int *)0x0) {
    *(undefined1 *)(param_2 + 6) = 1;
    *(undefined4 *)((longlong)param_2 + 0x2c) = 0x16;
    FUN_1400194a4(0,0,0,0,0,param_2);
  }
  else {
    if (((uint)param_1[5] >> 0xc & 1) == 0) {
      FUN_140019e58((longlong)param_1);
      uVar1 = FUN_1400222d8(param_1,param_2);
      FUN_140019e64((longlong)param_1);
      return uVar1 & 0xffffffff;
    }
    FUN_140022fb8((undefined8 *)param_1);
  }
  return 0xffffffff;
}

