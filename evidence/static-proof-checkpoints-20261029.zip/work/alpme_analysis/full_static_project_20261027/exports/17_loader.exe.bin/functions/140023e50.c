/* address=140023e50 rva=0x23e50 */

void FUN_140023e50(longlong param_1,undefined8 *param_2)

{
  undefined1 local_31;
  undefined8 *local_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined8 local_18;
  longlong local_10;
  undefined1 *local_8;
  
  local_8 = &local_31;
  if (*(int *)(param_1 + 0x18) != 0) {
    local_18 = param_2[2];
    local_30 = &local_28;
    local_28 = *param_2;
    uStack_20 = param_2[1];
    local_10 = param_1;
    FUN_140023fbe((uint *)(param_1 + 0x18),'\x01',&local_30,0x140073558);
  }
  return;
}

