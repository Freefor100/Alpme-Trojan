/* address=14000a9a9 rva=0xa9a9 */

undefined8 FUN_14000a9a9(byte *param_1,longlong param_2,byte *param_3)

{
  byte *pbVar1;
  byte bVar2;
  byte bVar3;
  code *pcVar4;
  bool bVar5;
  short sVar6;
  BOOL BVar7;
  DWORD DVar8;
  FILETIME FVar9;
  HANDLE hFile;
  longlong lVar10;
  char *pcVar11;
  short sVar12;
  WCHAR WVar13;
  uint uVar14;
  uint uVar15;
  DWORD DVar16;
  FILETIME FVar17;
  FILETIME *lpLastWriteTime;
  undefined8 uVar18;
  FILETIME *lpLastAccessTime;
  ulonglong uVar19;
  ulonglong uVar20;
  _SECURITY_ATTRIBUTES *p_Var21;
  ulonglong uVar22;
  byte *pbVar23;
  FILETIME FVar24;
  undefined8 *puVar25;
  FILETIME local_498;
  FILETIME local_490;
  FILETIME local_488;
  _SECURITY_ATTRIBUTES *local_480;
  ulonglong local_478;
  ulonglong uStack_470;
  FILETIME local_468;
  FILETIME local_460;
  FILETIME local_458;
  byte *local_450;
  FILETIME local_448;
  _SECURITY_ATTRIBUTES local_440 [42];
  
  FUN_1400146e3((undefined8 *)local_440,param_2 + 1,0,2,2);
  if ((char)local_440[0].nLength == '\0') {
    local_490.dwHighDateTime = local_440[0]._20_4_;
    local_490.dwLowDateTime = local_440[0].bInheritHandle;
    local_498 = (FILETIME)local_440[0].lpSecurityDescriptor;
    local_488.dwLowDateTime = 0;
    local_488.dwHighDateTime = 0;
    pbVar23 = param_1 + param_2;
    uVar15 = 0;
    do {
      FVar24 = local_488;
      if ((short)uVar15 != 0) goto LAB_14000b269;
      if (param_1 == pbVar23) {
        FVar9 = local_498;
        FVar17 = local_488;
        if (7 < (ulonglong)local_488) goto LAB_14000aa65;
        goto LAB_14000aaaa;
      }
      bVar2 = *param_1;
      uVar15 = (uint)bVar2;
      if ((char)bVar2 < '\0') {
        uVar14 = bVar2 & 0x1f;
        pbVar1 = param_1 + 1;
        if (bVar2 < 0xe0) {
          param_1 = param_1 + 2;
          uVar15 = uVar14 << 6 | *pbVar1 & 0x3f;
          goto LAB_14000b269;
        }
        uVar15 = param_1[2] & 0x3f | (*pbVar1 & 0x3f) << 6;
        if (bVar2 < 0xf0) {
          param_1 = param_1 + 3;
          uVar15 = uVar15 | uVar14 << 0xc;
        }
        else {
          pbVar1 = param_1 + 3;
          param_1 = param_1 + 4;
          uVar15 = *pbVar1 & 0x3f | uVar15 << 6 | (bVar2 & 7) << 0x12;
        }
        if (uVar15 < 0x10000) goto LAB_14000b269;
        WVar13 = (short)(uVar15 >> 10) + 0x3fc0U | 0xd800;
        uVar15 = (uint)((ushort)uVar15 & 0x3ff | 0xdc00);
      }
      else {
        param_1 = param_1 + 1;
LAB_14000b269:
        WVar13 = (WCHAR)uVar15;
        uVar15 = 0;
      }
      if (local_488 == local_490) {
        uVar19 = (longlong)pbVar23 - (longlong)param_1;
        uVar20 = uVar19 + 3;
        if (0xfffffffffffffffc < uVar19) {
          uVar20 = 0xffffffffffffffff;
        }
        lVar10 = FUN_14000965c(&local_498,(ulonglong)local_488,
                               ((uVar20 >> 2) + 2) - (ulonglong)((short)uVar15 == 0),(LPVOID)0x2,2);
        if (lVar10 != -1) break;
        local_440[0].lpSecurityDescriptor = (LPVOID)local_498;
      }
      *(WCHAR *)((longlong)local_440[0].lpSecurityDescriptor + (longlong)FVar24 * 2) = WVar13;
      local_488 = (FILETIME)((longlong)FVar24 + 1);
    } while( true );
  }
  goto LAB_14000b226;
  while( true ) {
    FVar17 = (FILETIME)((longlong)FVar17 - 8);
    FVar9 = (FILETIME)((longlong)FVar9 + 0x10);
    if ((ulonglong)FVar17 < 8) break;
LAB_14000aa65:
    if (((((*(WCHAR *)FVar9 == L'\0') || (*(LPCWSTR)((longlong)FVar9 + 2) == L'\0')) ||
         (*(LPCWSTR)((longlong)FVar9 + 4) == L'\0')) ||
        ((*(LPCWSTR)((longlong)FVar9 + 6) == L'\0' || (*(LPCWSTR)((longlong)FVar9 + 8) == L'\0'))))
       || ((*(LPCWSTR)((longlong)FVar9 + 10) == L'\0' ||
           ((*(LPCWSTR)((longlong)FVar9 + 0xc) == L'\0' ||
            (*(LPCWSTR)((longlong)FVar9 + 0xe) == L'\0')))))) goto LAB_14000aac4;
  }
LAB_14000aaaa:
  lVar10 = (longlong)FVar17 * 2;
  while (lVar10 != 0) {
    lVar10 = lVar10 + -2;
    WVar13 = *(WCHAR *)FVar9;
    FVar9 = (FILETIME)((longlong)FVar9 + 2);
    if (WVar13 == L'\0') {
LAB_14000aac4:
      FUN_14000250d((LPVOID)local_498,(longlong)local_490,2,2);
      return 1;
    }
  }
  if (local_490 == local_488) {
    FUN_140007620(&local_498);
  }
  FVar9 = local_498;
  *(WCHAR *)((longlong)local_498 + (longlong)FVar24 * 2) = L'\0';
  if (local_490 == (FILETIME)0xffffffffffffffff) {
    return 1;
  }
  local_458 = (FILETIME)((longlong)FVar24 + 1);
  FVar24 = local_498;
  FVar17 = local_490;
  local_468 = local_498;
  local_460 = local_490;
  if ((ulonglong)local_458 < 4) {
    if (local_458 != (FILETIME)0x0) {
      if (local_458 != (FILETIME)0x1) {
        if ((local_458 == (FILETIME)0x3) && (*(LPCWSTR)((longlong)local_498 + 2) == L':')) {
          WVar13 = *(WCHAR *)((longlong)local_498 + 4);
          if (WVar13 != L'\0') goto LAB_14000b01f;
          if ((*(WCHAR *)local_498 != L'/') && (*(WCHAR *)local_498 != L'\\')) goto LAB_14000ac9f;
        }
        goto LAB_14000b0aa;
      }
      if (*(WCHAR *)local_498 == L'\0') goto LAB_14000ac9f;
    }
LAB_14000b0df:
    local_480 = (_SECURITY_ATTRIBUTES *)0x2;
    local_478 = 0;
    uStack_470 = 0;
    uVar19 = 0x200;
    local_450 = param_3;
    local_448 = local_490;
    do {
      while( true ) {
        if (uVar19 < 0x201) {
          p_Var21 = local_440;
          uVar20 = 0x200;
          uVar22 = uVar19;
        }
        else {
          if ((local_478 - uStack_470 < uVar19 - uStack_470) &&
             (lVar10 = FUN_14000965c(&local_480,uStack_470,uVar19 - uStack_470,(LPVOID)0x2,2),
             lVar10 != -1)) goto LAB_14000b226;
          uVar20 = local_478;
          if (0xfffffffe < local_478) {
            uVar20 = 0xffffffff;
          }
          p_Var21 = local_480;
          uVar22 = uVar20;
          uStack_470 = uVar20;
        }
        SetLastError(0);
        DVar8 = GetFullPathNameW((LPCWSTR)FVar9,(DWORD)uVar22,(LPWSTR)p_Var21,(LPWSTR *)0x0);
        uVar19 = (ulonglong)DVar8;
        if ((DVar8 == 0) && (DVar16 = GetLastError(), DVar16 != 0)) {
          GetLastError();
          if ((undefined **)PTR_PTR_1400cfa50 != &PTR_LAB_140073648) {
            PTR_PTR_1400cfa50 = (undefined *)&PTR_LAB_140073648;
          }
          FUN_14000250d(local_480,local_478,2,2);
          FUN_14000250d((LPVOID)local_468,(longlong)local_448,2,2);
          return 1;
        }
        param_3 = local_450;
        if (uVar22 != uVar19) break;
        DVar8 = GetLastError();
        if (DVar8 != 0x7a) goto LAB_14000b226;
        uVar19 = uVar22 * 2;
        if (0xfffffffe < uVar19) {
          uVar19 = 0xffffffff;
        }
      }
    } while (uVar22 < uVar19);
    if (uVar20 < uVar19) goto LAB_14000b226;
    local_458.dwLowDateTime = 0;
    local_458.dwHighDateTime = 0;
    if (DVar8 < 3) {
      if (DVar8 != 2) goto LAB_14000ac16;
      sVar12 = (short)p_Var21->nLength;
LAB_14000abad:
      if (sVar12 == 0x5c) {
        sVar6 = *(short *)((longlong)&p_Var21->nLength + 2);
LAB_14000abb9:
        if (sVar6 == 0x5c) {
LAB_14000abbf:
          p_Var21 = (_SECURITY_ATTRIBUTES *)&p_Var21->field_0x4;
          lVar10 = 8;
          puVar25 = (undefined8 *)&DAT_1400738cc;
          uVar19 = uVar19 - 2;
          goto LAB_14000ac18;
        }
      }
LAB_14000ac16:
      puVar25 = (undefined8 *)0x2;
      lVar10 = 0;
    }
    else {
      sVar6 = *(short *)((longlong)&p_Var21->nLength + 2);
      if ((sVar6 != 0x3a) || (*(short *)&p_Var21->field_0x4 != 0x5c)) {
        sVar12 = (short)p_Var21->nLength;
        if (DVar8 == 3) goto LAB_14000abad;
        if ((sVar12 == 0x5c) && (sVar6 != 0x3f)) {
          if (sVar6 != 0x5c) goto LAB_14000abb9;
          if (*(short *)&p_Var21->field_0x4 == 0x2e) {
            if (*(short *)&p_Var21->field_0x6 == 0x5c) {
              uVar19 = uVar19 - 4;
              p_Var21 = (_SECURITY_ATTRIBUTES *)&p_Var21->lpSecurityDescriptor;
              goto LAB_14000ab77;
            }
          }
          else if ((*(short *)&p_Var21->field_0x4 == 0x3f) &&
                  (*(short *)&p_Var21->field_0x6 == 0x5c)) goto LAB_14000ac16;
          goto LAB_14000abbf;
        }
        goto LAB_14000ac16;
      }
LAB_14000ab77:
      puVar25 = (undefined8 *)&DAT_1400738dc;
      lVar10 = 4;
    }
LAB_14000ac18:
    FVar24 = (FILETIME)(lVar10 + uVar19 + 1);
    if ((ulonglong)local_448 < (ulonglong)FVar24) {
      FUN_140023eef((ulonglong *)&local_498,(LPVOID)local_468,(longlong)local_448,(ulonglong)FVar24,
                    (LPVOID)0x2,2);
      if ((char)local_498.dwLowDateTime == '\0') {
        local_468 = local_490;
        local_460 = FVar24;
      }
      else if (local_490 != (FILETIME)0xffffffffffffffff) {
LAB_14000b226:
                    /* WARNING: Does not return */
        pcVar4 = (code *)invalidInstructionException();
        (*pcVar4)();
      }
    }
    FUN_1400019bd((longlong *)&local_468,puVar25,(undefined8 *)((longlong)puVar25 + lVar10 * 2));
    FUN_1400019bd((longlong *)&local_468,(undefined8 *)p_Var21,
                  (undefined8 *)((longlong)&p_Var21->nLength + uVar19 * 2));
    FVar9 = local_458;
    if (local_460 == local_458) {
      FUN_140007620(&local_468);
    }
    FVar17 = local_460;
    FVar24 = local_468;
    *(WCHAR *)((longlong)local_468 + (longlong)FVar9 * 2) = L'\0';
    FUN_14000250d(local_480,local_478,2,2);
    if (FVar17 == (FILETIME)0xffffffffffffffff) {
      return 1;
    }
  }
  else if ((*(longlong *)local_498 != 0x5c003f005c005c) &&
          (*(longlong *)local_498 != 0x5c003f003f005c)) {
    if (0xf7 < (ulonglong)local_458) goto LAB_14000b0df;
    if (*(LPCWSTR)((longlong)local_498 + 2) == L':') {
      WVar13 = *(LPCWSTR)((longlong)local_498 + 4);
LAB_14000b01f:
      if ((WVar13 != L'/') && (WVar13 != L'\\')) goto LAB_14000b0aa;
      WVar13 = *(WCHAR *)local_498;
      if ((WVar13 != L'/') && (WVar13 != L'\\')) goto LAB_14000ac9f;
    }
    else {
LAB_14000b0aa:
      WVar13 = *(WCHAR *)local_498;
    }
    if (((WVar13 != L'/') && (WVar13 != L'\\')) ||
       ((*(LPCWSTR)((longlong)local_498 + 2) != L'/' &&
        (*(LPCWSTR)((longlong)local_498 + 2) != L'\\')))) goto LAB_14000b0df;
  }
LAB_14000ac9f:
  bVar2 = param_3[0x14];
  uVar15 = (uint)bVar2;
  if (param_3[0x1d] == 0) {
    if (uVar15 != 0) goto LAB_14000acba;
    DVar8 = (uint)param_3[0x1c] * 2 + 3;
  }
  else {
    DVar8 = 4;
    if (uVar15 != 0) {
LAB_14000acba:
      DVar8 = 1;
    }
  }
  local_440[0].nLength = 0x18;
  local_440[0].lpSecurityDescriptor = (LPVOID)0x0;
  local_440[0].bInheritHandle = (BOOL)*param_3;
  if (param_3[8] == 0) {
    bVar3 = param_3[2];
    if (param_3[0x24] != 0) {
      if (param_3[0x25] != 0) goto LAB_14000aea5;
      DVar16 = (uint)(byte)~bVar3 * -0x80000000 + 0xc0000000;
      goto LAB_14000ad20;
    }
    if (param_3[0x25] == 0) {
      if ((param_3[0x1d] == 0 && param_3[0x1c] == 0) && bVar2 == 0) {
        DVar16 = 0x80000000;
        if (bVar3 != 0) goto LAB_14000ad20;
        pcVar11 = "of show them mother think over are now little or did must ";
        uVar19 = 0x3a;
      }
      else {
        pcVar11 = 
        "been for so must make one right with word use been hand over eqkOMUsnrZvbL6atVpeUrjy7iyqqgT-Fi2VBVrE3r_frpGW-8FNAmCPWGotJusgw7P0123456789abcdefS_imju6t_nojNc8x"
        ;
        uVar19 = 0x3d;
      }
    }
    else {
LAB_14000aea5:
      if (param_3[0x1c] != 1 || bVar2 != 0) {
        DVar16 = (uint)(byte)~bVar3 * -0x80000000 + 0x80120114;
        goto LAB_14000ad20;
      }
      pcVar11 = 
      "turn think into take different when this azU6Xc--1MivfjCMBv1SlzSvGy7lD2A9hy08f3B84zKGJgrF9Av6yryrfxo_preferred alignment cannot less than compressed sizeB5ppg98DwJVea2586_h9WC3yMTHyqNeJQ9dXj5FtTotal compressed HPACK data size exceeds given valueRxQUrgR39REZu9jH4WG19qXTUhU3kUGlifk5hjF4Y7N8qgzIpI0EX6iUjEWGoCY_VR73G1mshO6Ljl6EUQHXCXL3GXb4PjrwRC8g8AxJbvcnQlWNNdea9vuzP96GswF1FQ-ym-AH85P2dwa5YVL5jas4mVZLAmp-WkySyDhDHgqGraTV44T1kPEezewKzouBd_jEPy1PZzS033NjprP3DtsApcF4WfMFuvYiZDO-Qi-Iz5aOQEL3Qgm-Y2tZzh9wOMNOYhfvybrng8YjrnacgvKG1k0zy8cseND7a0vTZcAhgs1p_Zu4Wu6mgDR_gK4b2n5LGNXng-ns749NOVVYxdk9HFK7Kc62xpMB0wB6lIzodmsy_QSx81clJCO5zYVfXGvhr-u7R40LkCgOoCMd40MLjpRPoY91cU-6ntymrjDG4nmmlWfwZZRw0NgyrYmvc47vqz3-pU6jD-rXSL00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_5akJIGK_6NaLhrWH7CPeCiIkyGrcUtYIl_FajutZBopZv43JQcdjqSAJ4uSDTMQ10puU-5fACmC:\\ProgramData\\versions\\dynaumiouft.pdfC:\\ProgramData\\welltried\\ueskeoty.txtXjEWQjh_klXMZY9nhKarBUU3_TQ5XOXHm_w8wr7paCi4LxQSsBJYgVo-gfGZ25rSRpCNUOJ1dkufKAaobKdiDTEAUIgvqJ12vnJjZlaAEOQAExRNi63WCwoNEw6qzuY_x_W_6\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02"
      ;
      uVar19 = 0x2a;
    }
    FUN_140014d71((undefined8 *)pcVar11,uVar19);
  }
  else {
    DVar16 = *(DWORD *)(param_3 + 0xc);
LAB_14000ad20:
    p_Var21 = local_440;
    if (*param_3 == 0) {
      p_Var21 = (LPSECURITY_ATTRIBUTES)0x0;
    }
    hFile = CreateFileW((LPCWSTR)FVar24,DVar16,*(DWORD *)(param_3 + 0x10),p_Var21,DVar8,
                        uVar15 << 0x15 | *(uint *)(param_3 + 0x20) | *(uint *)(param_3 + 0x18) |
                        *(uint *)(param_3 + 4),(HANDLE)0x0);
    if (hFile != (HANDLE)0xffffffffffffffff) {
      if (param_3[0x26] == 0) {
        if (param_3[1] != 0) {
          lpLastAccessTime = (FILETIME *)0x0;
          lpLastWriteTime = &local_498;
          goto LAB_14000ad8a;
        }
LAB_14000ada0:
        uVar18 = 0;
        if ((DVar8 != 4) || (param_3[0x1c] == 0)) goto LAB_14000ae26;
        DVar8 = GetLastError();
        if (DVar8 == 0xb7) {
          local_498.dwLowDateTime = 0;
          local_498.dwHighDateTime = 0;
          bVar5 = FUN_14000b971(hFile,FileAllocationInfo,&local_498);
          if (bVar5) {
            local_480 = (_SECURITY_ATTRIBUTES *)0x0;
            bVar5 = FUN_14000b971(hFile,FileEndOfFileInfo,&local_480);
            if (bVar5) goto LAB_14000b1b6;
          }
        }
        uVar18 = 0;
      }
      else {
        lpLastAccessTime = &local_498;
        lpLastWriteTime = (FILETIME *)0x0;
        if (param_3[1] != 0) {
          lpLastWriteTime = lpLastAccessTime;
        }
LAB_14000ad8a:
        local_498.dwLowDateTime = 0xffffffff;
        local_498.dwHighDateTime = 0xffffffff;
        BVar7 = SetFileTime(hFile,(FILETIME *)0x0,lpLastAccessTime,lpLastWriteTime);
        if (BVar7 != 0) goto LAB_14000ada0;
        GetLastError();
LAB_14000b1b6:
        if ((undefined **)PTR_PTR_1400cfa50 != &PTR_LAB_140073648) {
          PTR_PTR_1400cfa50 = (undefined *)&PTR_LAB_140073648;
        }
        CloseHandle(hFile);
        uVar18 = 1;
      }
      goto LAB_14000ae26;
    }
    GetLastError();
    if ((undefined **)PTR_PTR_1400cfa50 != &PTR_LAB_140073648) {
      PTR_PTR_1400cfa50 = (undefined *)&PTR_LAB_140073648;
    }
  }
  uVar18 = 1;
LAB_14000ae26:
  FUN_14000250d((LPVOID)FVar24,(longlong)FVar17,2,2);
  return uVar18;
}

