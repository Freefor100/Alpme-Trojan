/* address=14001e30c rva=0x1e30c */

void FUN_14001e30c(longlong param_1,longlong *param_2,longlong param_3)

{
  undefined **ppuVar1;
  
  if ((*param_2 != (&DAT_1400d1818)[param_3]) && ((DAT_1400d0ba0 & *(uint *)(param_1 + 0x3a8)) == 0)
     ) {
    ppuVar1 = FUN_14001b1e8();
    *param_2 = (longlong)ppuVar1;
  }
  return;
}

