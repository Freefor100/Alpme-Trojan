/* address=140018ab8 rva=0x18ab8 */

int * FUN_140018ab8(longlong param_1,undefined8 *param_2)

{
  int iVar1;
  int *piVar2;
  
  if (((*(uint *)(param_1 + 0x3a8) & DAT_1400d0ba0) == 0) || (*(longlong *)(param_1 + 0x90) == 0)) {
    FUN_140017cb4(5);
    piVar2 = *(int **)(param_1 + 0x88);
    if (piVar2 != (int *)*param_2) {
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if ((iVar1 == 1) && (piVar2 != (int *)&DAT_1400d0340)) {
          FUN_1400191b0(piVar2);
        }
      }
      piVar2 = (int *)*param_2;
      *(int **)(param_1 + 0x88) = piVar2;
      LOCK();
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    FUN_140017cd0(5);
  }
  else {
    piVar2 = *(int **)(param_1 + 0x88);
  }
  if (piVar2 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
    FUN_1400172f8();
  }
  return piVar2;
}

