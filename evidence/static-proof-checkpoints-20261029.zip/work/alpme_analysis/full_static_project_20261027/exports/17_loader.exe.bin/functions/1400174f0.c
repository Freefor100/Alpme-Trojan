/* address=1400174f0 rva=0x174f0 */

undefined8 * FUN_1400174f0(undefined8 *param_1,ulonglong param_2)

{
  *param_1 = type_info::vftable;
  if ((param_2 & 1) != 0) {
    thunk_FUN_1400191b0(param_1);
  }
  return param_1;
}

