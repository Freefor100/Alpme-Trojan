/* address=1400176c8 rva=0x176c8 */

undefined8 FUN_1400176c8(char param_1)

{
  HMODULE hLibModule;
  undefined *in_RAX;
  undefined8 *puVar1;
  
  if (param_1 == '\0') {
    puVar1 = &DAT_1400d1090;
    do {
      hLibModule = (HMODULE)*puVar1;
      if (hLibModule != (HMODULE)0x0) {
        if (hLibModule != (HMODULE)0xffffffffffffffff) {
          FreeLibrary(hLibModule);
        }
        *puVar1 = 0;
      }
      puVar1 = puVar1 + 1;
      in_RAX = &DAT_1400d1148;
    } while (puVar1 != (undefined8 *)&DAT_1400d1148);
  }
  return CONCAT71((int7)((ulonglong)in_RAX >> 8),1);
}

