/* address=14001ab30 rva=0x1ab30 */

void FUN_14001ab30(undefined8 *param_1,longlong param_2)

{
  undefined8 *puVar1;
  
  puVar1 = param_1 + param_2;
  for (; param_1 != puVar1; param_1 = param_1 + 1) {
    FUN_1400191b0((LPVOID)*param_1);
  }
  return;
}

