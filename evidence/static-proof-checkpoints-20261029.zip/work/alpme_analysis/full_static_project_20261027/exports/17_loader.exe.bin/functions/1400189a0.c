/* address=1400189a0 rva=0x189a0 */

UINT FUN_1400189a0(UINT param_1)

{
  longlong local_28;
  longlong local_20;
  char local_10;
  
  FUN_14001863c(&local_28,(undefined4 *)0x0);
  DAT_1400d17e0 = 0;
  if (param_1 == 0xfffffffe) {
    DAT_1400d17e0 = 1;
    param_1 = GetOEMCP();
  }
  else if (param_1 == 0xfffffffd) {
    DAT_1400d17e0 = 1;
    param_1 = GetACP();
  }
  else if (param_1 == 0xfffffffc) {
    DAT_1400d17e0 = 1;
    param_1 = *(UINT *)(local_20 + 0xc);
  }
  if (local_10 != '\0') {
    *(uint *)(local_28 + 0x3a8) = *(uint *)(local_28 + 0x3a8) & 0xfffffffd;
  }
  return param_1;
}

