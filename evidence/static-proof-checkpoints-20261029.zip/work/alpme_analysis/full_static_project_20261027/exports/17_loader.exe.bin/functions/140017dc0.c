/* address=140017dc0 rva=0x17dc0 */

void FUN_140017dc0(void)

{
  undefined8 *puVar1;
  
  puVar1 = FUN_140017e20();
  if (puVar1 == (undefined8 *)0x0) {
                    /* WARNING: Subroutine does not return */
    FUN_1400172f8();
  }
  return;
}

