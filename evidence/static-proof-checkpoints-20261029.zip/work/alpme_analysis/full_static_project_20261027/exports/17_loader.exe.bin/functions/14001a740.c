/* address=14001a740 rva=0x1a740 */

undefined8 * FUN_14001a740(undefined8 *param_1,undefined8 param_2)

{
  PVOID pvVar1;
  undefined8 uVar2;
  
  *param_1 = param_2;
  pvVar1 = FUN_1400173f0();
  if (param_1 < *(undefined8 **)((longlong)pvVar1 + 0x58)) {
    pvVar1 = FUN_1400173f0();
    uVar2 = *(undefined8 *)((longlong)pvVar1 + 0x58);
  }
  else {
    uVar2 = 0;
  }
  param_1[1] = uVar2;
  pvVar1 = FUN_1400173f0();
  *(undefined8 **)((longlong)pvVar1 + 0x58) = param_1;
  return param_1;
}

