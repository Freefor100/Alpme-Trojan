/* address=140022c74 rva=0x22c74 */

undefined8 FUN_140022c74(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = 0;
  return param_1;
}

