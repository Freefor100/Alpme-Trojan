/* address=14001e928 rva=0x1e928 */

void FUN_14001e928(DWORD *param_1,uint param_2,byte *param_3,ulonglong param_4,longlong *param_5)

{
  char cVar1;
  byte bVar2;
  HANDLE hFile;
  uint uVar3;
  BOOL BVar4;
  ulonglong uVar5;
  char *pcVar6;
  int iVar7;
  DWORD DVar8;
  undefined1 *puVar9;
  byte *pbVar10;
  int iVar11;
  longlong lVar12;
  ulonglong uVar13;
  longlong lVar14;
  longlong lVar15;
  longlong lVar16;
  undefined1 auStackY_108 [32];
  undefined2 local_c8 [2];
  WCHAR local_c4 [2];
  DWORD local_c0 [2];
  byte *local_b8;
  longlong *local_b0;
  uint local_a8 [2];
  UINT local_a0;
  int local_9c;
  byte *local_98;
  longlong local_90;
  uint local_88 [2];
  undefined8 *local_80;
  byte *local_78;
  HANDLE local_70;
  longlong local_68;
  undefined8 local_60;
  undefined8 local_58;
  byte local_50;
  byte local_4f;
  undefined1 local_48 [8];
  ulonglong local_40;
  
  local_60 = 0xfffffffffffffffe;
  local_40 = DAT_1400d02c0 ^ (ulonglong)auStackY_108;
  local_b0 = param_5;
  lVar14 = (longlong)(int)param_2 >> 6;
  uVar5 = (ulonglong)(param_2 & 0x3f);
  local_70 = *(HANDLE *)((&DAT_1400d13c0)[lVar14] + 0x28 + uVar5 * 0x48);
  local_b8 = param_3 + (param_4 & 0xffffffff);
  local_98 = param_3;
  local_90 = lVar14;
  local_a0 = GetConsoleOutputCP();
  iVar11 = 0;
  if ((char)local_b0[5] == '\0') {
    FUN_14001ccd0(local_b0);
  }
  local_9c = *(int *)(local_b0[3] + 0xc);
  param_1[0] = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (local_98 < param_3 + (param_4 & 0xffffffff)) {
    DVar8 = 0;
    local_68 = lVar14;
    do {
      local_c8[0] = CONCAT11(local_c8[0]._1_1_,*param_3);
      local_c4[0] = L'\0';
      local_c4[1] = L'\0';
      uVar3 = 1;
      if (local_9c == 0xfde9) {
        iVar7 = 0;
        lVar15 = 0;
        pcVar6 = (char *)(uVar5 * 0x48 + 0x3e + (&DAT_1400d13c0)[local_68]);
        do {
          if (*pcVar6 == '\0') break;
          iVar7 = iVar7 + 1;
          lVar15 = lVar15 + 1;
          pcVar6 = pcVar6 + 1;
        } while (lVar15 < 5);
        if (lVar15 < 1) {
          cVar1 = (&DAT_1400d0bc0)[*param_3];
          iVar7 = cVar1 + 1;
          lVar14 = (longlong)local_b8 - (longlong)param_3;
          if (lVar14 < iVar7) {
            if (0 < lVar14) {
              lVar15 = 0;
              do {
                *(byte *)(lVar15 + uVar5 * 0x48 + 0x3e + (&DAT_1400d13c0)[local_90]) =
                     param_3[lVar15];
                iVar11 = iVar11 + 1;
                lVar15 = lVar15 + 1;
              } while (iVar11 < lVar14);
            }
            param_1[1] = param_1[1] + (int)lVar14;
            break;
          }
          local_a8[0] = 0;
          local_a8[1] = 0;
          uVar3 = (iVar7 == 4) + 1;
          local_78 = param_3;
          lVar14 = FUN_140021cc0((ushort *)local_c4,&local_78,(ulonglong)uVar3,local_a8,
                                 (longlong)local_b0);
          if (lVar14 == -1) break;
          pbVar10 = param_3 + cVar1;
          lVar14 = local_90;
        }
        else {
          cVar1 = (&DAT_1400d0bc0)[*(byte *)((&DAT_1400d13c0)[lVar14] + 0x3e + uVar5 * 0x48)];
          iVar7 = (cVar1 + 1) - iVar7;
          local_a8[0] = iVar7;
          lVar12 = (longlong)local_b8 - (longlong)param_3;
          uVar13 = (ulonglong)iVar7;
          if (lVar12 < (longlong)uVar13) {
            if (0 < lVar12) {
              lVar16 = lVar15;
              do {
                *(byte *)(lVar16 + uVar5 * 0x48 + 0x3e + (&DAT_1400d13c0)[lVar14]) =
                     param_3[lVar16 - lVar15];
                iVar11 = iVar11 + 1;
                lVar16 = lVar16 + 1;
              } while (iVar11 < lVar12);
            }
            param_1[1] = param_1[1] + (int)lVar12;
            break;
          }
          lVar12 = 0;
          puVar9 = (undefined1 *)(uVar5 * 0x48 + 0x3e + (&DAT_1400d13c0)[local_68]);
          do {
            local_48[lVar12 + -0x10] = *puVar9;
            lVar12 = lVar12 + 1;
            puVar9 = puVar9 + 1;
          } while (lVar12 < lVar15);
          if (0 < (longlong)uVar13) {
            FUN_140023130((undefined8 *)(local_48 + lVar15 + -0x10),(undefined8 *)param_3,uVar13);
          }
          lVar12 = 0;
          do {
            *(undefined1 *)(lVar12 + uVar5 * 0x48 + 0x3e + (&DAT_1400d13c0)[lVar14]) = 0;
            lVar12 = lVar12 + 1;
          } while (lVar12 < lVar15);
          local_88[0] = 0;
          local_88[1] = 0;
          local_80 = &local_58;
          uVar3 = (cVar1 + 1 == 4) + 1;
          lVar15 = FUN_140021cc0((ushort *)local_c4,&local_80,(ulonglong)uVar3,local_88,
                                 (longlong)local_b0);
          if (lVar15 == -1) break;
          pbVar10 = param_3 + (int)(local_a8[0] - 1);
        }
      }
      else {
        lVar15 = (&DAT_1400d13c0)[lVar14];
        bVar2 = *(byte *)(lVar15 + 0x3d + uVar5 * 0x48);
        if ((bVar2 & 4) == 0) {
          if (*(short *)(*(longlong *)local_b0[3] + (ulonglong)*param_3 * 2) < 0) {
            pbVar10 = param_3 + 1;
            if (pbVar10 < local_b8) {
              iVar7 = FUN_140021908(local_c4,param_3,2,local_b0);
              if (iVar7 != -1) goto LAB_14001ec30;
            }
            else {
              *(byte *)(lVar15 + 0x3e + uVar5 * 0x48) = *param_3;
              pbVar10 = (byte *)((&DAT_1400d13c0)[lVar14] + 0x3d + uVar5 * 0x48);
              *pbVar10 = *pbVar10 | 4;
              param_1[1] = DVar8 + 1;
            }
            break;
          }
          uVar13 = 1;
          pbVar10 = param_3;
        }
        else {
          local_50 = *(byte *)(lVar15 + 0x3e + uVar5 * 0x48);
          local_4f = *param_3;
          *(byte *)(lVar15 + 0x3d + uVar5 * 0x48) = bVar2 & 0xfb;
          uVar13 = 2;
          pbVar10 = &local_50;
        }
        iVar7 = FUN_140021908(local_c4,pbVar10,uVar13,local_b0);
        pbVar10 = param_3;
        if (iVar7 == -1) break;
      }
LAB_14001ec30:
      param_3 = pbVar10 + 1;
      uVar3 = FUN_14001c2e8(local_a0,0,local_c4,uVar3);
      hFile = local_70;
      if (uVar3 == 0) break;
      local_c0[0] = 0;
      BVar4 = WriteFile(local_70,local_48,uVar3,local_c0,(LPOVERLAPPED)0x0);
      if (BVar4 == 0) {
LAB_14001ed89:
        DVar8 = GetLastError();
        *param_1 = DVar8;
        break;
      }
      DVar8 = (param_1[2] - (int)local_98) + (int)param_3;
      param_1[1] = DVar8;
      if (local_c0[0] < uVar3) break;
      if ((char)local_c8[0] == '\n') {
        local_c8[0] = 0xd;
        BVar4 = WriteFile(hFile,local_c8,1,local_c0,(LPOVERLAPPED)0x0);
        if (BVar4 == 0) goto LAB_14001ed89;
        if (local_c0[0] == 0) break;
        param_1[2] = param_1[2] + 1;
        param_1[1] = param_1[1] + 1;
        DVar8 = param_1[1];
      }
    } while (param_3 < local_b8);
  }
  FUN_14001b4d0(local_40 ^ (ulonglong)auStackY_108);
  return;
}

