/* address=1400152b0 rva=0x152b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_1400152b0(uint param_1)

{
  code *pcVar1;
  bool bVar2;
  ulonglong in_RAX;
  undefined7 extraout_var;
  undefined8 uVar3;
  
  if (DAT_1400d0da1 == '\0') {
    if (1 < param_1) {
      FUN_140015570(5);
      pcVar1 = (code *)swi(3);
      uVar3 = (*pcVar1)();
      return uVar3;
    }
    bVar2 = FUN_140015930();
    in_RAX = CONCAT71(extraout_var,bVar2);
    if (((int)in_RAX == 0) || (param_1 != 0)) {
      DAT_1400d0da8 = 0xffffffffffffffff;
      uRam00000001400d0db0 = 0xffffffffffffffff;
      _DAT_1400d0db8 = 0xffffffffffffffff;
      _DAT_1400d0dc0 = 0xffffffffffffffff;
      uRam00000001400d0dc8 = 0xffffffffffffffff;
      _DAT_1400d0dd0 = 0xffffffffffffffff;
    }
    else {
      in_RAX = FUN_14001672c(&DAT_1400d0da8);
      if ((int)in_RAX != 0) {
LAB_1400152f3:
        return in_RAX & 0xffffffffffffff00;
      }
      in_RAX = FUN_14001672c((longlong *)&DAT_1400d0dc0);
      if ((int)in_RAX != 0) goto LAB_1400152f3;
    }
    DAT_1400d0da1 = '\x01';
  }
  return CONCAT71((int7)(in_RAX >> 8),1);
}

