/* address=1400195c4 rva=0x195c4 */

undefined8 * FUN_1400195c4(longlong *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  DWORD local_res8 [2];
  
  puVar1 = (undefined8 *)*param_1;
  lVar2 = 0;
  if (puVar1 == (undefined8 *)0x0) {
    local_res8[0] = GetLastError();
    if ((char)param_1[2] == '\0') {
      param_1[1] = 0;
      *(undefined1 *)(param_1 + 2) = 1;
    }
    else {
      lVar2 = param_1[1];
    }
    puVar1 = FUN_140017eb0(local_res8,lVar2);
    *param_1 = (longlong)puVar1;
    SetLastError(local_res8[0]);
  }
  return puVar1;
}

