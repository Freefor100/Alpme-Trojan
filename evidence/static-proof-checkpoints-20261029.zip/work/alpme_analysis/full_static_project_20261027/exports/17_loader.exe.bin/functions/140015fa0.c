/* address=140015fa0 rva=0x15fa0 */

void FUN_140015fa0(void)

{
  FUN_140016098(0,0,1);
  return;
}

