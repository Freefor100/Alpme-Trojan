/* address=140021520 rva=0x21520 */

char * FUN_140021520(ulonglong param_1,char param_2)

{
  uint uVar1;
  char *pcVar2;
  char *pcVar3;
  char *pcVar4;
  char *pcVar5;
  char *pcVar6;
  char *pcVar7;
  char *pcVar8;
  char *pcVar9;
  char *pcVar10;
  char *pcVar11;
  char *pcVar12;
  char *pcVar13;
  char *pcVar14;
  char *pcVar15;
  char *pcVar16;
  char *pcVar17;
  char *pcVar18;
  uint uVar19;
  undefined1 auVar20 [16];
  undefined1 in_XMM1 [16];
  undefined1 auVar21 [16];
  undefined1 auVar22 [16];
  undefined1 auVar23 [16];
  char cVar24;
  char cVar25;
  char cVar26;
  char cVar27;
  
  pcVar17 = (char *)(param_1 & 0xfffffffffffffff0);
  auVar21 = pshuflw(in_XMM1,ZEXT216(CONCAT11(param_2,param_2)),0);
  auVar23[0] = -(*pcVar17 == '\0');
  auVar23[1] = -(pcVar17[1] == '\0');
  auVar23[2] = -(pcVar17[2] == '\0');
  auVar23[3] = -(pcVar17[3] == '\0');
  auVar23[4] = -(pcVar17[4] == '\0');
  auVar23[5] = -(pcVar17[5] == '\0');
  auVar23[6] = -(pcVar17[6] == '\0');
  auVar23[7] = -(pcVar17[7] == '\0');
  auVar23[8] = -(pcVar17[8] == '\0');
  auVar23[9] = -(pcVar17[9] == '\0');
  auVar23[10] = -(pcVar17[10] == '\0');
  auVar23[0xb] = -(pcVar17[0xb] == '\0');
  auVar23[0xc] = -(pcVar17[0xc] == '\0');
  auVar23[0xd] = -(pcVar17[0xd] == '\0');
  auVar23[0xe] = -(pcVar17[0xe] == '\0');
  auVar23[0xf] = -(pcVar17[0xf] == '\0');
  cVar24 = auVar21[0];
  auVar20[0] = -(*pcVar17 == cVar24);
  cVar25 = auVar21[1];
  auVar20[1] = -(pcVar17[1] == cVar25);
  cVar26 = auVar21[2];
  auVar20[2] = -(pcVar17[2] == cVar26);
  cVar27 = auVar21[3];
  auVar20[3] = -(pcVar17[3] == cVar27);
  auVar20[4] = -(pcVar17[4] == cVar24);
  auVar20[5] = -(pcVar17[5] == cVar25);
  auVar20[6] = -(pcVar17[6] == cVar26);
  auVar20[7] = -(pcVar17[7] == cVar27);
  auVar20[8] = -(pcVar17[8] == cVar24);
  auVar20[9] = -(pcVar17[9] == cVar25);
  auVar20[10] = -(pcVar17[10] == cVar26);
  auVar20[0xb] = -(pcVar17[0xb] == cVar27);
  auVar20[0xc] = -(pcVar17[0xc] == cVar24);
  auVar20[0xd] = -(pcVar17[0xd] == cVar25);
  auVar20[0xe] = -(pcVar17[0xe] == cVar26);
  auVar20[0xf] = -(pcVar17[0xf] == cVar27);
  auVar20 = auVar20 | auVar23;
  uVar19 = (uint)(ushort)((ushort)(SUB161(auVar20 >> 7,0) & 1) |
                          (ushort)(SUB161(auVar20 >> 0xf,0) & 1) << 1 |
                          (ushort)(SUB161(auVar20 >> 0x17,0) & 1) << 2 |
                          (ushort)(SUB161(auVar20 >> 0x1f,0) & 1) << 3 |
                          (ushort)(SUB161(auVar20 >> 0x27,0) & 1) << 4 |
                          (ushort)(SUB161(auVar20 >> 0x2f,0) & 1) << 5 |
                          (ushort)(SUB161(auVar20 >> 0x37,0) & 1) << 6 |
                          (ushort)(SUB161(auVar20 >> 0x3f,0) & 1) << 7 |
                          (ushort)(SUB161(auVar20 >> 0x47,0) & 1) << 8 |
                          (ushort)(SUB161(auVar20 >> 0x4f,0) & 1) << 9 |
                          (ushort)(SUB161(auVar20 >> 0x57,0) & 1) << 10 |
                          (ushort)(SUB161(auVar20 >> 0x5f,0) & 1) << 0xb |
                          (ushort)(SUB161(auVar20 >> 0x67,0) & 1) << 0xc |
                          (ushort)(SUB161(auVar20 >> 0x6f,0) & 1) << 0xd |
                          (ushort)(SUB161(auVar20 >> 0x77,0) & 1) << 0xe |
                         (ushort)(byte)(auVar20[0xf] >> 7) << 0xf) & -1 << ((byte)param_1 & 0xf);
  while (uVar19 == 0) {
    pcVar18 = pcVar17 + 0x10;
    pcVar2 = pcVar17 + 0x11;
    pcVar3 = pcVar17 + 0x12;
    pcVar4 = pcVar17 + 0x13;
    pcVar5 = pcVar17 + 0x14;
    pcVar6 = pcVar17 + 0x15;
    pcVar7 = pcVar17 + 0x16;
    pcVar8 = pcVar17 + 0x17;
    pcVar9 = pcVar17 + 0x18;
    pcVar10 = pcVar17 + 0x19;
    pcVar11 = pcVar17 + 0x1a;
    pcVar12 = pcVar17 + 0x1b;
    pcVar13 = pcVar17 + 0x1c;
    pcVar14 = pcVar17 + 0x1d;
    pcVar15 = pcVar17 + 0x1e;
    pcVar16 = pcVar17 + 0x1f;
    pcVar17 = pcVar17 + 0x10;
    auVar21[0] = -(*pcVar18 == '\0');
    auVar21[1] = -(*pcVar2 == '\0');
    auVar21[2] = -(*pcVar3 == '\0');
    auVar21[3] = -(*pcVar4 == '\0');
    auVar21[4] = -(*pcVar5 == '\0');
    auVar21[5] = -(*pcVar6 == '\0');
    auVar21[6] = -(*pcVar7 == '\0');
    auVar21[7] = -(*pcVar8 == '\0');
    auVar21[8] = -(*pcVar9 == '\0');
    auVar21[9] = -(*pcVar10 == '\0');
    auVar21[10] = -(*pcVar11 == '\0');
    auVar21[0xb] = -(*pcVar12 == '\0');
    auVar21[0xc] = -(*pcVar13 == '\0');
    auVar21[0xd] = -(*pcVar14 == '\0');
    auVar21[0xe] = -(*pcVar15 == '\0');
    auVar21[0xf] = -(*pcVar16 == '\0');
    auVar22[0] = -(*pcVar18 == cVar24);
    auVar22[1] = -(*pcVar2 == cVar25);
    auVar22[2] = -(*pcVar3 == cVar26);
    auVar22[3] = -(*pcVar4 == cVar27);
    auVar22[4] = -(*pcVar5 == cVar24);
    auVar22[5] = -(*pcVar6 == cVar25);
    auVar22[6] = -(*pcVar7 == cVar26);
    auVar22[7] = -(*pcVar8 == cVar27);
    auVar22[8] = -(*pcVar9 == cVar24);
    auVar22[9] = -(*pcVar10 == cVar25);
    auVar22[10] = -(*pcVar11 == cVar26);
    auVar22[0xb] = -(*pcVar12 == cVar27);
    auVar22[0xc] = -(*pcVar13 == cVar24);
    auVar22[0xd] = -(*pcVar14 == cVar25);
    auVar22[0xe] = -(*pcVar15 == cVar26);
    auVar22[0xf] = -(*pcVar16 == cVar27);
    auVar22 = auVar22 | auVar21;
    uVar19 = (uint)(ushort)((ushort)(SUB161(auVar22 >> 7,0) & 1) |
                            (ushort)(SUB161(auVar22 >> 0xf,0) & 1) << 1 |
                            (ushort)(SUB161(auVar22 >> 0x17,0) & 1) << 2 |
                            (ushort)(SUB161(auVar22 >> 0x1f,0) & 1) << 3 |
                            (ushort)(SUB161(auVar22 >> 0x27,0) & 1) << 4 |
                            (ushort)(SUB161(auVar22 >> 0x2f,0) & 1) << 5 |
                            (ushort)(SUB161(auVar22 >> 0x37,0) & 1) << 6 |
                            (ushort)(SUB161(auVar22 >> 0x3f,0) & 1) << 7 |
                            (ushort)(SUB161(auVar22 >> 0x47,0) & 1) << 8 |
                            (ushort)(SUB161(auVar22 >> 0x4f,0) & 1) << 9 |
                            (ushort)(SUB161(auVar22 >> 0x57,0) & 1) << 10 |
                            (ushort)(SUB161(auVar22 >> 0x5f,0) & 1) << 0xb |
                            (ushort)(SUB161(auVar22 >> 0x67,0) & 1) << 0xc |
                            (ushort)(SUB161(auVar22 >> 0x6f,0) & 1) << 0xd |
                            (ushort)(SUB161(auVar22 >> 0x77,0) & 1) << 0xe |
                           (ushort)(byte)(auVar22[0xf] >> 7) << 0xf);
  }
  uVar1 = 0;
  if (uVar19 != 0) {
    for (; (uVar19 >> uVar1 & 1) == 0; uVar1 = uVar1 + 1) {
    }
  }
  pcVar18 = (char *)0x0;
  if (pcVar17[uVar1] == param_2) {
    pcVar18 = pcVar17 + uVar1;
  }
  return pcVar18;
}

