/* address=140015bd0 rva=0x15bd0 */

void Unwind_140015bd0(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_14001715c();
}

