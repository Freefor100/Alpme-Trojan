/* address=14001a010 rva=0x1a010 */

undefined * FUN_14001a010(void)

{
  undefined8 *puVar1;
  undefined *puVar2;
  
  puVar1 = FUN_140017e20();
  puVar2 = (undefined *)((longlong)puVar1 + 0x24);
  if (puVar1 == (undefined8 *)0x0) {
    puVar2 = &DAT_1400d0afc;
  }
  return puVar2;
}

