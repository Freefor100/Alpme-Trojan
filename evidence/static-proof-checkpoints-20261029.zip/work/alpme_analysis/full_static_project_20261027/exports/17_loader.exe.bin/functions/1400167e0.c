/* address=1400167e0 rva=0x167e0 */

void FUN_1400167e0(undefined8 param_1)

{
  FUN_140016754(&DAT_1400d0f88,param_1);
  return;
}

