/* address=140019770 rva=0x19770 */

ulonglong FUN_140019770(void)

{
  byte bVar1;
  ulonglong uVar2;
  
  FUN_140017cb4(0);
  bVar1 = (byte)DAT_1400d02c0 & 0x3f;
  uVar2 = DAT_1400d17f0 ^ DAT_1400d02c0;
  FUN_140017cd0(0);
  return uVar2 >> bVar1 | uVar2 << 0x40 - bVar1;
}

