/* address=140014f20 rva=0x14f20 */

void FUN_140014f20(void)

{
  undefined8 uVar1;
  
  FUN_140015560();
  uVar1 = FUN_140015410();
  FUN_140017130((uint)uVar1);
  return;
}

