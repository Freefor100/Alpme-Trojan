/* address=140015f10 rva=0x15f10 */

undefined8 * FUN_140015f10(void)

{
  return &DAT_1400d0e38;
}

