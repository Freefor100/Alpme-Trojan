/* address=140017944 rva=0x17944 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */

void FUN_140017944(ushort *param_1,uint param_2)

{
  FARPROC pFVar1;
  
  pFVar1 = FUN_140017a48(0x14,"LocaleNameToLCID",(uint *)&DAT_140077018,(uint *)&DAT_140077020);
  if (pFVar1 == (FARPROC)0x0) {
    FUN_14001de30(param_1);
  }
  else {
    (*pFVar1)(param_1,(ulonglong)param_2);
  }
  return;
}

