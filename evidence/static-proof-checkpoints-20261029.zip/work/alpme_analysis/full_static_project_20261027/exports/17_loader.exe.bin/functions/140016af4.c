/* address=140016af4 rva=0x16af4 */

ulonglong FUN_140016af4(undefined8 param_1,int *param_2,undefined8 *param_3,int *param_4)

{
  ulonglong uVar1;
  
  FUN_140017cb4(*param_2);
  uVar1 = FUN_1400169a0(param_3);
  FUN_140017cd0(*param_4);
  return uVar1 & 0xffffffff;
}

