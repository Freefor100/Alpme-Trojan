/* address=140016bc4 rva=0x16bc4 */

void FUN_140016bc4(void)

{
  FUN_140016c7c(&DAT_1400d0fb8);
  FUN_140016c98(&DAT_1400d0fc0);
  FUN_140016cb4(DAT_1400d0fd0);
  FUN_140016cb4(DAT_1400d0fc8);
  return;
}

