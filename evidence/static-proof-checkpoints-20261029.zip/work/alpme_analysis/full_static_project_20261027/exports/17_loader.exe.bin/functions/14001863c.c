/* address=14001863c rva=0x1863c */

longlong * FUN_14001863c(longlong *param_1,undefined4 *param_2)

{
  longlong *plVar1;
  uint uVar2;
  longlong lVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  
  *(undefined1 *)(param_1 + 3) = 0;
  plVar1 = param_1 + 1;
  if (param_2 == (undefined4 *)0x0) {
    if (DAT_1400d0e78 != 0) {
      lVar3 = FUN_140017dc0();
      *param_1 = lVar3;
      *plVar1 = *(longlong *)(lVar3 + 0x90);
      param_1[2] = *(longlong *)(lVar3 + 0x88);
      FUN_14001e2a4(lVar3,plVar1);
      FUN_14001e2d8(*param_1,param_1 + 2);
      uVar2 = *(uint *)(*param_1 + 0x3a8);
      if ((uVar2 & 2) == 0) {
        *(uint *)(*param_1 + 0x3a8) = uVar2 | 2;
        *(undefined1 *)(param_1 + 3) = 1;
        return param_1;
      }
      return param_1;
    }
    uVar4 = PTR_PTR_1400d09d8._0_4_;
    uVar5 = PTR_PTR_1400d09d8._4_4_;
    uVar6 = PTR_DAT_1400d09e0._0_4_;
    uVar7 = PTR_DAT_1400d09e0._4_4_;
  }
  else {
    uVar4 = *param_2;
    uVar5 = param_2[1];
    uVar6 = param_2[2];
    uVar7 = param_2[3];
  }
  *(undefined4 *)plVar1 = uVar4;
  *(undefined4 *)((longlong)param_1 + 0xc) = uVar5;
  *(undefined4 *)(param_1 + 2) = uVar6;
  *(undefined4 *)((longlong)param_1 + 0x14) = uVar7;
  return param_1;
}

