/* address=140016cf8 rva=0x16cf8 */

undefined8 * FUN_140016cf8(char *param_1)

{
  longlong lVar1;
  longlong lVar2;
  undefined8 *puVar3;
  char *pcVar4;
  undefined8 uVar5;
  char cVar6;
  longlong lVar7;
  ulonglong uVar8;
  undefined8 *puVar9;
  
  cVar6 = *param_1;
  lVar7 = 0;
  pcVar4 = param_1;
  while (cVar6 != '\0') {
    lVar1 = lVar7 + 1;
    if (cVar6 == '=') {
      lVar1 = lVar7;
    }
    lVar7 = -1;
    do {
      lVar2 = lVar7;
      lVar7 = lVar2 + 1;
    } while (pcVar4[lVar7] != '\0');
    pcVar4 = pcVar4 + lVar2 + 2;
    lVar7 = lVar1;
    cVar6 = *pcVar4;
  }
  puVar3 = FUN_14001ab80(lVar7 + 1,8);
  if (puVar3 == (undefined8 *)0x0) {
LAB_140016d5b:
    FUN_1400191b0((LPVOID)0x0);
    puVar3 = (undefined8 *)0x0;
  }
  else {
    puVar9 = puVar3;
    for (; *param_1 != '\0'; param_1 = param_1 + uVar8) {
      lVar7 = -1;
      do {
        lVar1 = lVar7;
        lVar7 = lVar1 + 1;
      } while (param_1[lVar7] != '\0');
      uVar8 = lVar1 + 2;
      if (*param_1 != '=') {
        pcVar4 = FUN_14001ab80(uVar8,1);
        if (pcVar4 == (char *)0x0) {
          FUN_140016cb4(puVar3);
          FUN_1400191b0((LPVOID)0x0);
          goto LAB_140016d5b;
        }
        uVar5 = FUN_140017540(pcVar4,uVar8,(longlong)param_1);
        if ((int)uVar5 != 0) {
                    /* WARNING: Subroutine does not return */
          FUN_1400192e4();
        }
        *puVar9 = pcVar4;
        puVar9 = puVar9 + 1;
        FUN_1400191b0((LPVOID)0x0);
      }
    }
    FUN_1400191b0((LPVOID)0x0);
  }
  return puVar3;
}

