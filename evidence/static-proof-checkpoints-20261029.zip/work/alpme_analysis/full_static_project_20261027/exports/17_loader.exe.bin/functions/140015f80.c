/* address=140015f80 rva=0x15f80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_140015f80(undefined8 param_1)

{
  _DAT_1400d0e60 = param_1;
  return;
}

