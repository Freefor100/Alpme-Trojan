/* address=140015f40 rva=0x15f40 */

undefined * FUN_140015f40(void)

{
  return &DAT_1400d0e58;
}

