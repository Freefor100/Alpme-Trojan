/* address=140017eb0 rva=0x17eb0 */

undefined8 * FUN_140017eb0(undefined8 param_1,longlong param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)0x0;
  if (DAT_1400d0338 == 0xffffffff) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    puVar1 = FlsGetValue(DAT_1400d0338);
  }
  if (puVar1 != (undefined8 *)0xffffffffffffffff) {
    if ((puVar1 == (undefined8 *)0x0) && (puVar1 = FUN_14001815c(), puVar1 == (undefined8 *)0x0)) {
      return (undefined8 *)0x0;
    }
    puVar2 = puVar1 + param_2 * 0x79;
  }
  return puVar2;
}

