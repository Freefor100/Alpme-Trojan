"""Static transliteration of 19si's pure string transform, no native code."""
MASK=(1<<64)-1
def u64(x):return x&MASK
def alphabet():
    a=bytearray(b'abcdefghijklmnopqrstuvwxyz0123456789')
    inc=u64(0xf2779392ad1d518e-0x544019d92dd2d579)
    ax=(0x2dd2d579^0x2dd2d55d)
    state=u64((0xe7037ed1a0b428b7+ax)^0xbae2d64dd63a3919)
    for n in range(36,1,-1):
        state=u64(state+inc)
        v=u64((state^(state>>((0x7f4a7c33-(inc&0xffffffff))&63)))*0xbf58476d1ce4e5b9)
        v=u64((v^(v>>27))*0x94d049bb133111eb)
        v^=v>>31
        j=v%n;a[n-1],a[j]=a[j],a[n-1]
    return a
ALPHABET=alphabet()
def decode(s,seed):
    inv={x:i for i,x in enumerate(ALPHABET[:32])}
    out=bytearray(); acc=0;bits=0
    for n,c in enumerate(s):
        if n%46==45:continue
        acc=(acc<<5)|inv.get(c,0);bits+=5
        if bits>=8:
            bits-=8;out.append((acc>>bits)&255);acc&=(1<<bits)-1
    inc=0xb2041bff18f368b
    state=u64((seed^0xe27bb381a2ad7424)+inc) if seed!=0xe27bb381a2ad7424 else 0x1640837fe31e6d16
    for i in range(len(out)):
        if not i%8:
            state=u64(state+inc)
            v=u64((state^(state>>24))*0xfc601c526f4e6a03)
            v=u64((v^(v>>26))*0x734f7f849f60ca37);v^=v>>24
        out[i]^=(v>>((i%8)*8))&255
    pos=0
    def read(n):
        nonlocal pos
        v=0
        for _ in range(n):
            v=(v<<1)|((out[pos//8]>>(pos%8))&1) if pos<len(out)*8 else v<<1
            pos+=1
        return v
    comp=read(1); szbits=((read(2)<<3)^8)+8; size=read(szbits)
    if size>0x4000000:raise ValueError(('excess size',size,out[:10].hex(),bytes(s[:30]),hex(seed)))
    if not comp:return bytes(read(8) for _ in range(size))
    obits=max(4,min(14,(size-1).bit_length()))
    result=bytearray()
    while len(result)<size:
        if read(1):result.append(read(8))
        else:
            length=read(6);offset=read(obits);total=length+3
            if length==63:
                while True:
                    v=read(8);total+=v
                    if v<=254:break
            if offset>=len(result):break
            start=len(result)-offset-1
            for i in range(min(total,size-len(result))):result.append(result[start+i])
    return bytes(result)
