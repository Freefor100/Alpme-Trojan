"""Static transliteration of 17si string codec. Python data transforms only."""
M=(1<<64)-1
def rol(v,n):return ((v<<n)|(v>>(64-n)))&M
def alphabet():
 a=bytearray(b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_')
 st=((0xd0e87fd9439110d1^0xe7037ed1a0b428db)+0x9e3779b97f4a7c15)&M
 for n in range(2,65):
  v=((st^(st>>30))*0xbf58476d1ce4e5b9)&M
  v=((v^(v>>27))*0x94d049bb133111eb)&M;v^=v>>31;j=v%n;a[n-1],a[j]=a[j],a[n-1]
  st=(st+0x9e3779b97f4a7c15)&M
 return a
ALPHABET=alphabet()
def decode(raw,seed,debug=False):
 inv={v:i for i,v in enumerate(ALPHABET)};b=bytearray();acc=bits=0
 for n,v in enumerate(raw):
  if n%43==42:continue
  acc=(acc<<6)|inv.get(v,0);bits+=6
  if bits>=8:bits-=8;b.append((acc>>bits)&255);acc&=(1<<bits)-1
 st=(rol(seed^0x88711a1537065dec,49)+0x20edc5be3f5d5bc7)&M if seed!=0x88711a1537065dec else 0xd87c0799cad9da81
 for i in range(len(b)):
  if i%8==0:
   st=(rol(st,49)+0x20edc5be3f5d5bc7)&M;v=((st^(st>>33))*0xa0b4795468cdbc27)&M;v^=v>>32
  b[i]^=(v>>((i%8)*8))&255
 pos=0
 def read(n):
  nonlocal pos
  v=0
  for _ in range(n):v=(v<<1)|((b[pos//8]>>(pos%8))&1) if pos<len(b)*8 else v<<1;pos+=1
  return v
 comp=read(1);szbits=(read(2)*8^24)+8;size=read(szbits)
 if debug:print('codec',comp,szbits,size,len(b),b[:20].hex())
 if size>0x4000000:raise ValueError('size '+str(size))
 if not comp:return bytes(read(8) for _ in range(size))
 obits=max(4,min(12,(size-1).bit_length()));out=bytearray()
 while len(out)<size:
  if not read(1):out.append(read(8))
  else:
   ln=read(5);off=read(obits);total=ln+4
   if ln==31:
    while True:
     v=read(8);total+=v
     if v<=254:break
   if off>=len(out):raise ValueError(('off',off,len(out),pos))
   st=len(out)-off-1
   for j in range(min(total,size-len(out))):out.append(out[st+j])
 return bytes(out)
if __name__=='__main__':
 from emu import *
 print(ALPHABET);print(decode(rd(0x140073a9f,0x34),0xe9d44cb7113359bc,True))
